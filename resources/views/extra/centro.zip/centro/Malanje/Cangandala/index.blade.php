<option>Colégio N. 2- Palanca Negra - Cangandala </option>
<option>Complexo Escolar N. 5 - Ngola Kiluange - Cangandala </option>
<option>Escola Primária N. 1 - Hoji Ya Henda - Cangandala </option>
<option>Escola Primária N. 12 - Comandante Sacalavanca Do Bembo - Cangandala </option>
<option>Escola Primária N. 4 - Franciscana Bom Pastor - Cangandala </option>
<option>Escola Primária N. 8 - Sagrada Esperança - Cangandala </option>
<option>Escola Primária N. 9 - Comandante Capala - Cangandala </option>
<option>Liceu N. 3 - Njinga Mbandi - Cangandala</option>