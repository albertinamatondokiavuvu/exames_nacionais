<option>Colégio N. 8 - Hoji-Ya-Henda - Kiwaba Nzoji </option>
<option>Escola De Formação Técnicos De Saúde - Kiwaba Nzoji </option>
<option>Escola Primária N. 1 - Kilamba - Kiwaba Nzoji</option>
<option>Escola Primária N. 2 - Tunda-Dia-Mola - Kiwaba Nzoji </option>
<option>Escola Primária N. 3 - Quissua - Kiwaba Nzoji </option>
<option>Escola Primária N. 4 - Cambo Cafuxe - Kiwaba Nzoji </option>
<option>Escola Primária N. 5 - Quifucussa - Kiwaba Nzoji </option>
<option>Escola Primária N. 6 - Luthau - Kiwaba Nzoji </option>
<option>Escola Primária N. 7 - Mufuma - Kiwaba Nzoji </option>
