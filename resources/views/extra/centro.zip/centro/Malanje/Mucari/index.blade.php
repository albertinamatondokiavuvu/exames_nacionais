<option>Complexo Escolar N. 15 - Rei Ngola Kiluanje - Caculama </option>
<option>Escola Primária N. 1 - Major Kahangulo - Caculama</option>
<option>Escola Primária N. 10 - 1.  De Maio - Caculama </option>
<option>Escola Primária N. 11 - Comandante Muleka - Caculama </option>
<option>Escola Primária N. 12 - 28 De Agosto - Caculama </option>
<option>Escola Primária N. 13 - Deolinda Rodrigues - Caculama </option>
<option>Escola Primária N. 14 - Nzinga Mbandi - Caculama </option>
<option>Escola Primária N. 2 - José Do Telhado - Caculama </option>
<option>Escola Primária N. 3 - Comandante Bula Matade - Caculama </option>
<option>Escola Primária N. 4 - 17 De Setembro - Caculama </option>
<option>Escola Primária N. 5 - 11 De Novembro - Caculama </option>
<option>Escola Primária N. 6 - Hoji-Ya-Henda - Caculama </option>
<option>Escola Primária N. 7 - Santa Teresinha - Caculama </option>
<option>Escola Primária N. 8 - 4 De Fevereiro - Caculama </option>
<option>Escola Primária N. 9 - 1 De Junho - Caculama </option>

