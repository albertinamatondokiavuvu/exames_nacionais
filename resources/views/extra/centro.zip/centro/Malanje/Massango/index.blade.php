<option>Escola Do Ensino Primário, Nº 22 - Gonga - Massango</option>
<option>Escola Do Ensino Primário, Nº 9 - Kimbungo Thunda - Massango</option>
<option>Escola Do I Ciclo Do Ensnino Secundário, Nº 41 - Massango - Massango</option>
