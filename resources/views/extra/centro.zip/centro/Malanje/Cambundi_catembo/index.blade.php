<option>Colégio N. 2 - Comandante Dangereux - Cambundi Catembo </option>
<option>Escola Do Ensino Primário, Nº 14 - Nguje -  Cambundi Catembo</option>
<option>Escola Primária N. 1 - 11 De Novembro- Dumba Cabango </option>
<option>Escola Primária N. 10 - Quevo - Cambundi Catembo </option>
<option>Escola Primária N. 11 - Cambundi Catembo Sede - Cambundi Catembo </option>
<option>Escola Primária N. 11 - Teresinha - Cambundi Catembo</option>
<option>Escola Primária N. 12 - Cambundi Catembo Sede - Cambundi Catembo </option>
<option>Escola Primária N. 13 - Mucondo Cabanga - Cambundi Catembo </option>
<option>Escola Primária N. 16 - Cambundi Catembo </option>
<option>Escola Primária N. 17 - Hopa - Cambundi Catembo </option>
<option>Escola Primária N. 18- Siquel - Cambundi Catembo </option>
<option>Escola Primária N. 3 - Kitapa - Cambundi Catembo </option>
<option>Escola Primária N. 4 - Mulende - Cambundi Catembo </option>
<option>Escola Primária N. 5 - Mussolo - Cambundi Catembo </option>
<option>Escola Primária N. 6 - Muieba Tuto- Cambundi Catembo </option>
<option>Escola Primária N. 7 - Muate - Cambundi Catembo </option>
<option>Escola Primária N. 8 - Malengue - Cambundi Catembo </option>
<option>Escola Primária N. 9 - Siconha - Cambundi Catembo </option>
