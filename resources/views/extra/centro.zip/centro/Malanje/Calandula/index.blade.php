<option>Colégio N. 11 - 4 De Fevereiro - Calandula - Calandula </option>
<option>Complexo Escolar N. 13 - 11 De Novembro - Kateco Kangola - Calandula </option>
<option>Complexo Escolar N. 14 - 17 De Setembro - Caxito - Calandula </option>
<option>Complexo Escolar N. 15 - 17 De Setembro - Kinje - Calandula </option>
<option>Complexo Escolar N. 16 - 22 De Novembro - Kota - Calandula </option>
<option>Complexo Escolar N. 19- Ngola Kiluange - Santa Maria - Calandula </option>
<option>Complexo Escolar N. 20 - Missão Catolica De Kalandula - Calandula </option>
<option>Escola Primária N. 18- Hoji Ya Henda - Quintumbo - Calandula </option>
<option>Escola Primária N. 2 - 1.  De Maio - Calandula </option>
<option>Escola Primária N. 8- Gongo - Calandula </option>
<option>Escola Primária N. 9 - Tanque - Calandula </option>
<option>Liceu N. 12- 2 De Setembro - Calandula</option>