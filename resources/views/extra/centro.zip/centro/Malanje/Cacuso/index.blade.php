<option>Colégio N. 2 - 22 De Novembro - Cacuso</option>
<option>Colégio N. 24 - Lucrécia Paim - Lombe - Cacuso</option>
<option>Complexo Escolar N. 25 - Missionário - Maria Francisca Curtina - Cacuso</option>
<option>Escola Do Ensino Primário, Nº 9 - Cacuso -  Cacuso</option>
<option>Escola Primária N. 1 - 11 De Novembro - Do Zanga - Cacuso</option>
<option>Escola Primária N. 10 - Cambunze - Cacuso</option>
<option>Escola Primária N. 11 - Mucuixi - Cacuso</option>
<option>Escola Primária N. 12 - Maxinde - Cacuso</option>
<option>Escola Primária N. 13 - Nzinga Mbandi - Cacuso</option>
<option>Escola Primária N. 14 - Bananeira - Cacuso</option>
<option>Escola Primária N. 15 - 17 - Setembro - Matete - Cacuso</option>
<option>Escola Primária N. 16 - Kafundanga - Cacuso</option>
<option>Escola Primária N. 17 - Kipakassa - Cacuso</option>
<option>Escola Primária N. 18 - Soba Kabanga Kaketa - Cacuso</option>
<option>Escola Primária N. 20 - Suqueco - Cacuso</option>
<option>Escola Primária N. 21 - Hoji Ya Henda - Cacuso</option>
<option>Escola Primária N. 22 - Pungo Andongo - Cacuso</option>
<option>Escola Primária N. 3 - Quizenga - Cacuso</option>
<option>Escola Primária N. 4 - Kinglês - Cacuso</option>
<option>Escola Primária N. 5 - Gika - Cacuso</option>
<option>Escola Primária N. 7 - Brita - Cacuso</option>
<option>Escola Primária N. 8 - Missionária - Santo Agostinho - Cacuso</option>
<option>Liceu N. 6 - Ngola Kiluanje - Cacuso</option>
<option>Magistério Primário - Adpp - Cacuso</option>
