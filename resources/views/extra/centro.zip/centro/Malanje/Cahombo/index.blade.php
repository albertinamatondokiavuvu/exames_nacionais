<option>Escola Primária N. 2 - Cambo Sunginge - Kahombo</option>
<option>Escola Primária N. 3 - Micanda - Kahombo</option>
