<option>Colégio N. 1 - Amílcar Cabral - Malanje</option>
<option>Colégio N. 125 - Njinga Mbande - Malanje </option>
<option>Colégio N. 153 - Adventista Central - Malanje </option>
<option>Colégio N. 2 - Sagrada Esperança - Malanje </option>
<option>Colégio N. 28 - Santo Jerónimo Cosme - Malanje </option>
<option>Colégio N. 3 - Hoji Ya Henda - Malanje</option>
<option>Colégio N. 4 - Uanhenga Xitu - Malange </option>
<option>Colégio N. 5 - De Iniciação Desportiva Escolar Angola E Cuba - Malanje</option>
<option>Colégio N. 7 - Luzicango - Malanje</option>
<option>Colégio N. 70 - Bispo Ndosa - Malanje </option>
<option>Colégio N. 79 - Esperança De África - Malanje </option>
<option>Colégio N. 8 - 11 De Novembro - Malanje </option>
<option>Complexo Escolar N. 10 - 28 De Agosto - Malanje</option>
<option>Complexo Escolar N. 110 - Nossa Senhora De Fátima - Maxinde - Malanje </option>
<option>Complexo Escolar N. 114 - Nossa Senhora De Fátima - Catepa - Malanje </option>
<option>Complexo Escolar N. 115 - Dom Quixote - Malanje </option>
<option>Complexo Escolar N. 118 - Gaiato-Malanje</option>
<option>Complexo Escolar N. 12 - Alice - Malanje </option>
<option>Complexo Escolar N. 13 - Comandante Nzage - Malange </option>
<option>Complexo Escolar N. 130 - Kudielela - Malanje </option>
<option>Complexo Escolar N. 131 - Lar Nazaré - Malanje </option>
<option>Complexo Escolar N. 133 - São Francisco De Assis - Malanje </option>
<option>Complexo Escolar N. 135 - Ritondo - Malanje</option>
<option>Complexo Escolar N. 144 - Nossa Senhora De Guadalupe - Malanje </option>
<option>Complexo Escolar N. 148 - Quissol - Malanje </option>
<option>Complexo Escolar N. 15 - Crismanuel - Malanje</option>
<option>Complexo Escolar N. 150 - Cambondo De Malanje - Malanje </option>
<option>Complexo Escolar N. 151 - Fernando Muquixi - Malanje </option>
<option>Complexo Escolar N. 152 - V.C.C. - Malanje </option>
<option>Complexo Escolar N. 16 - D´Fátima Morais - Malange </option>
<option>Complexo Escolar N. 165 - Cambaxe - Malanje</option>
<option>Complexo Escolar N. 175 - Episcopal Africana - Imeias - Malanje </option>
<option>Complexo Escolar N. 18 - Lar De Esperança - Malanje</option>
<option>Complexo Escolar N. 19 - Paz E Amor - Malanje </option>
<option>Complexo Escolar N. 20 - Missão Do Quéssua - Malanje</option>
<option>Complexo Escolar N. 21 - Monte Carvario - Malanje </option>
<option>Complexo Escolar N. 22 - Monte Sinai - Malanje </option>
<option>Complexo Escolar N. 23 - Nelson Mandela - Malanje</option>
<option>Complexo Escolar N. 24 - Pascomarcos - Malange </option>
<option>Complexo Escolar N. 26 - Sagrado Coracão De Jesus</option>
<option>Complexo Escolar N. 27 - Samora Machel - Malanje </option>
<option>Complexo Escolar N. 29- Terra Prometida - Malanje</option>
<option>Complexo Escolar N. 30 - Thulo Nguma - Malanje </option>
<option>Complexo Escolar N. 31 - Ebenezer - Malanje</option>
<option>Complexo Escolar N. 32 -1261 - Elimabe I - Malanje </option>
<option>Complexo Escolar N. 33 - Fidel De Castro - Malanje</option>
<option>Complexo Escolar N. 34 - Esperança De Angola - Malanje </option>
<option>Complexo Escolar N. 35 - Mamã Muxima - Malanje </option>
<option>Complexo Escolar N. 36 - Kanongue - Malanje</option>
<option>Complexo Escolar N. 37 - Honga Fikisa - Malanje</option>
<option>Complexo Escolar N. 81 - São Pedro Da Iepa - Malanje </option>
<option>Complexo Escolar N. 91 - Bom Deus - Malanje </option>
<option>Complexo Escolar N. 95 - Reverendo Francisco Armando - Malanje Cood. Escolar Da Marimba</option>
<option>Coord. Escolar Do Lombe</option>
<option>Direcção Municipal Da Educação De Malanje - Malanje</option>
<option>Escola De Formacao De Tecnicos De Saude De Malange</option>
<option>Escola De Formação De Técnicos De Saúde De Malange/Colab</option>
<option>Escola Do Ensino Primário - Luz Do 7º Dia - Malanje</option>
<option>Escola Do Ensino Primário - Sardes Do 7º Dia - Malanje</option>
<option>Escola Do I E Ii Ciclo Do Ensino Secundário - Issenguele - Malanje</option>
<option>Escola Do Ii Ciclo Do Ensino Secundário - Vab - Colégio - Malanje</option>
<option>Escola Primária N. 100 - Rei Salomão - Malanje</option>
<option>Escola Primária N. 104 - Zua - Malanje</option>
<option>Escola Primária N. 106 - Maria Francisca - Lombe - Malanje </option>
<option>Escola Primária N. 108 - Comandante Gika  - Malanje </option>
<option>Escola Primária N. 109 - São José De Cluny - Malanje </option>
<option>Escola Primária N. 11 - Dori-Lombe - Malanje </option>
<option>Escola Primária N. 111 - Cambondo Cuiji</option>
<option>Escola Primária N. 112 - Madre Isabel Larrañaga - Malanje </option>
<option>Escola Primária N. 117 - São Pedro Da Quizanga - Malanje </option>
<option>Escola Primária N. 119 - 11 De Novembro - Malanje </option>
<option>Escola Primária N. 120 - Camoma - Malanje </option>
<option>Escola Primária N. 121 - Havemos De Voltar - Malanje </option>
<option>Escola Primária N. 122 - Ngola Kiluanje - Malanje </option>
<option>Escola Primária N. 123 - Cabuabuata - Malanje </option>
<option>Escola Primária N. 124 - Edith Almeida De Sousa - Malanje </option>
<option>Escola Primária N. 126 - Campo Da Victória - Malanje </option>
<option>Escola Primária N. 127 - Major Kanhangulo - Malanje </option>
<option>Escola Primária N. 128 - Comandante Gika 2 – Amizade China Angola - Malanje </option>
<option>Escola Primária N. 129 - Comandante Kuenha - Malanje </option>
<option>Escola Primária N. 132 - Maria Madalena - Malanje </option>
<option>Escola Primária N. 134 - Patrice Lumumba - Malanje </option>
<option>Escola Primária N. 136 - Caná Do 7.  Dia - Malanje </option>
<option>Escola Primária N. 137 - Do 7.  Dia Nazaré - Malanje </option>
<option>Escola Primária N. 138 - Nova Estrela - Malanje </option>
<option>Escola Primária N. 139 - Comissão Da Canâmbua - Malanje </option>
<option>Escola Primária N. 14 - Nossa Sra De Fátima – Malanje</option>
<option>Escola Primária N. 140 - Canzamba - Malanje </option>
<option>Escola Primária N. 141 - Cahala - Malanje </option>
<option>Escola Primária N. 142 - Mão Ajudadora - Malanje </option>
<option>Escola Primária N. 145 - Da Passagem - Malanje </option>
<option>Escola Primária N. 146 - Rev..  Nascimento David - Malanje </option>
<option>Escola Primária N. 147 - Quimbamba  - Malanje </option>
<option>Escola Primária N. 149 - Quizanga - Malanje </option>
<option>Escola Primária N. 154 - Amj - Malanje</option>
<option>Escola Primária N. 155 -Bumba - Malanje </option>
<option>Escola Primária N. 156 - Cazeta - Malanje </option>
<option>Escola Primária N. 157 - Quizanga Da Barraca - Malanje </option>
<option>Escola Primária N. 158 - Cambundi Do Cuiji - Malanje </option>
<option>Escola Primária N. 159 - Massaca - Malanje </option>
<option>Escola Primária N. 160 - Quibinda  - Malanje </option>
<option>Escola Primária N. 161 - Vulangombe - Malanje </option>
<option>Escola Primária N. 162 - Tumba Moisé E Isabel - Malanje </option>
<option>Escola Primária N. 163 - Ngola Luije - Malanje </option>
<option>Escola Primária N. 164 - Dimba Nessa - Malanje </option>
<option>Escola Primária N. 167 - Mandume - Malanje </option>
<option>Escola Primária N. 168 - Manuel Bravo Da Costa - Malanje </option>
<option>Escola Primária N. 169 - David Nambo - Malanje </option>
<option>Escola Primária N. 17 - Esquadrão Bomboko </option>
<option>Escola Primária N. 170 - Nova Galileia - Malanje </option>
<option>Escola Primária N. 172 - Terra Nova - Malanje </option>
<option>Escola Primária N. 173 - São Paulo - Malanje</option>
<option>Escola Primária N. 176 - Catepa Da Feira - Malenje </option>
<option>Escola Primária N. 177 - Suingue - Malanje </option>
<option>Escola Primária N. 29 - Dr. António Agostinho Neto - Malanje</option>
<option>Escola Primária N. 39 - Santa Teresinha - Malanje </option>
<option>Escola Primária N. 60 - Amiga Da Criança</option>
<option>Escola Primária N. 61 - Betel Do 7.  Dia - Malanje</option> 
<option>Escola Primária N. 62 - Cangando -Malanje</option>
<option>Escola Primária N. 66 - Cristo Rei Ambeky - Malanje</option>
<option>Escola Primária N. 67 - Do 7.  Dia Galilieia</option>
<option>Escola Primária N. 68 - Dom Alexandre Do Nascimento</option>
<option>Escola Primária N. 69 - Esmirna Do 7.  Dia - Malanje </option>
<option>Escola Primária N. 71 - Kulamuxito- Malange </option>
<option>Escola Primária N. 73 - Figueira Dodas - Malanje</option>
<option>Escola Primária N. 74 - Comandante Dangereux - Malanje</option> 
<option>Escola Primária N. 75 - Sambizanga - Malanje </option>
<option>Escola Primária N. 76 - Pioneiro Zeca - Malanje </option>
<option>Escola Primária N. 77 - Palmeira - Malanje </option>
<option>Escola Primária N. 78 - Filadélfia Do 7.  Dia - Malanje </option>
<option>Escola Primária N. 82 - I.E.I.A - Malanje </option>
<option>Escola Primária N. 83 - Comandante Valódia - Malanje </option>
<option>Escola Primária N. 85 - Calemba - Malanje </option>
<option>Escola Primária N. 86 - Galileia Do 7.  Dia - Malanje </option>
<option>Escola Primária N. 87 - Deolinda Rodrigues </option>
<option>Escola Primária N. 88 - Nova Jerusalém - Malanje </option>
<option>Escola Primária N. 89 - Havemos De Voltar-Lau - Malanje</option>
<option>Escola Primária N. 9 - Cambamba - Quela</option>
<option>Escola Primária N. 90 - Kilamba Kiaxe - Malanje </option>
<option>Escola Primária N. 93 - Luzia Ingles Van - Dunén - Malanje </option>
<option>Escola Primária N. 94 - Missionária Da Vila Matilde N. 113 - Malanje </option>
<option>Escola Primária N. 96 - Força Matola - Malanje </option>
<option>Escola Primária N. 97 - Nossa Senhora Da Graça - Malanje</option>
<option>Escola Primária N. 98 - Progresso Da Paz - Malanje </option>
<option>Escola Primária N. 99 - Quissaco - Malanje</option>
<option>Instituto Médio Agrário De Malanje</option>
<option>Liceu N. 40 - Nicolau Gomes Spencer - Malanje </option>
<option>Liceu N. 41 - 4 De Abril - Malanje </option>
<option>Liceu N. 42 - 4 De Janeiro - Malanje </option>
<option>Liceu N. 43 - Arquidiocesano São José</option>
<option>Liceu N. 44 - Eiffel - Malanje </option>
<option>Liceu N. 45 - Serra Van-Dúnem - Malanje </option>
<option>Magistério De Formação De Professores De Educação Física N. 48 - Malanje </option>
<option>Magistério De Formação De Professores N. 47 - Comandante Cuidado - Malanje</option>
<option>Magistério N. 50 - Malanje </option>
<option>Magistério Primário Das Irmãs De S. José De Cluny N. 49 - Malanje </option>
<option>Med - Centro Prov. De Superaçao /Malanje</option>
<option>Med - Del. Mun. Kambundi-Katembo /Malanje</option>
<option>Med - Del. Mun. Kawaba-N'Zogi /Malanje</option>
<option>Med - Del. Mun. Massango /Malanje</option>
<option>Med - Delegacao Municipal De Cacuso - Malange</option>
<option>Med - Delegacao Municipal De Calandula</option>
<option>Med - Delegacao Municipal De Cangandala - Mal</option>
<option>Med - Delegacao Municipal De Quela - Malange</option>
<option>Med - Delegacao Municipal De Quirima - Malang</option>
<option>Med - Departamento Prov. De Inspeccao</option>
<option>Med - Dir.Provincial E Pequena Brigada-Malanj</option>
<option>Med - Escola Do Ii,Iii Municipal Do Kessua</option>
<option>Med - Seccao Municipal De Mucari /Malanje</option>
<option>Med- Curso Basico De Formacao De Docentes</option>
<option>Med-Dept Prov.Educacao De Adultos De Malanje</option>
<option>Seccao Mun. De Kunda Dia Base</option>
<option>Seccao Mun. Educacao De Malanje</option>
<option>Seccao Mun. De Kahombo</option>
