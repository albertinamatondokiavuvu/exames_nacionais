<option>Administração Municipal De Luquembo / Contratado</option>
<option>Colégio N. 10 - Hoji-Ya-Henda - Luquembo </option>
<option>Escola Primária N. 1 - 11 De Novembro - Luquembo</option>
<option>Escola Primária N. 13 - Canjungo - Luquembo </option>
<option>Escola Primária N. 14 - Sicongo - Luquembo </option>
<option>Escola Primária N. 15 - Sacabeia - Luquembo </option>
<option>Escola Primária N. 2 - Cangila - Luquembo </option>
<option>Escola Primária N. 3 - Luquembo Soba - Luquembo </option>
<option>Escola Primária N. 4 - Sifundo - Luquembo </option>
<option>Escola Primária N. 5 - Nzinga Mbandi - Kapunda - Luquembo </option>
<option>Escola Primária N. 7 - 1 De Junho - Luquembo </option>
