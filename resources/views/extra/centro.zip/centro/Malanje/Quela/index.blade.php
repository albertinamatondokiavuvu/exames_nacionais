<option>Escola Primária N. 6 - Mufuma - Quela </option>
<option>Escola Primária N. 8 - Banda - Quela (Retirar)</option>
<option>Direcção Municipal De Educação De Cacuso</option>
<option>Direcção Municipal De Educação De Calandula</option>
<option>Direcção Municipal De Educação De Cambundi Catembo</option>
<option>Direcção Municipal De Educação De Cangandala</option>
<option>Direcção Municipal De Educação De Cunda Dia Base</option>
<option>Direcção Municipal De Educação De Kwaba Nzoji</option>
<option>Direcção Municipal De Educação De Luquembo</option>
<option>Direcção Municipal De Educação De Malanje</option>
<option>Direcção Municipal De Educação De Marimba</option>
<option>Direcção Municipal De Educação De Massango</option>
<option>Direcção Municipal De Educação De Quela</option>
<option>Direcção Municipal De Educação De Quirima</option>
<option>Direcção Municipal De Educação Mucari</option>
