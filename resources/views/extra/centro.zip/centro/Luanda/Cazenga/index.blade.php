<option>Colégio N. 3001 - Cazenga</option>
<option>Colégio N. 3012 - Cazenga</option>
<option>Colégio N. 3029 - Cazenga</option>
<option>Colégio N. 3036 - Cazenga</option>
<option>Colégio N. 3042 - Cazenga</option>
<option>Colégio N. 3045 - Cazenga</option>
<option>Colégio N. 3046 - Cazenga</option>
<option>Colégio N. 3049 - Cazenga</option>
<option>Colégio N. 3050 - Cazenga</option>
<option>Colégio N. 3053 - Cazenga</option>
<option>Colégio N. 3056 - Cazenga</option>
<option>Colégio N. 3061 - Cazenga</option>
<option>Colégio N. 3065 "Santa Marta" - Cazenga</option>
<option>Colégio N. 3074 Cazenga</option>
<option>Colégio N. 3078 Cazenga</option>
<option>Colégio N. 3079 Cazenga</option>
<option>Colégio N. 3081 Cazenga</option>
<option>Colégio N. 3086 "Santa Madalena"</option>
<option>Complexo Escolar N. 3098 - Cazenga</option>
<option>Complexo N. 3095-Cazenga</option>
<option>Complexo N. 3099-Cazenga</option>
<option>Complexo N. 3100-Cazenga</option>
<option>Complexo N. 3101 - Cazenga</option>
<option>Complexo N. 3103-Cazenga</option>
<option>Direcção Municipal Da Educação Do Cazenga</option>
<option>Direcção Municipal Da Educação Do Cazenga - Segurança</option>
<option>Escola Primária N. 3002 - Cazenga</option>
<option>Escola Primária N. 3003 - Cazenga</option>
<option>Escola Primária N. 3004 - Cazenga</option>
<option>Escola Primária N. 3005 - Cazenga</option>
<option>Escola Primária N. 3006 - Cazenga</option>
<option>Escola Primária N. 3008 - Cazenga</option>
<option>Escola Primária N. 3009 - Cazenga</option>
<option>Escola Primária N. 3010 - Cazenga</option>
<option>Escola Primária N. 3013 - Cazenga</option>
<option>Escola Primária N. 3014 - Cazenga</option>
<option>Escola Primária N. 3015 - Cazenga</option>
<option>Escola Primária N. 3016 - Cazenga</option>
<option>Escola Primária N. 3017 - Cazenga</option>
<option>Escola Primária N. 3018 - Cazenga</option>
<option>Escola Primária N. 3019 - Cazenga</option>
<option>Escola Primária N. 3020 - Cazenga</option>
<option>Escola Primária N. 3021 - Cazenga</option>
<option>Escola Primária N. 3022 - Cazenga</option>
<option>Escola Primária N. 3023 - Cazenga</option>
<option>Escola Primária N. 3024 - Cazenga</option>
<option>Escola Primária N. 3025 - Cazenga</option>
<option>Escola Primária N. 3026 - Cazenga</option>
<option>Escola Primária N. 3027 - Cazenga</option>
<option>Escola Primária N. 3028 - Cazenga</option>
<option>Escola Primária N. 3030 - Cazenga</option>
<option>Escola Primária N. 3032 - Cazenga</option>
<option>Escola Primária N. 3034 - Cazenga</option>
<option>Escola Primária N. 3035 - Cazenga</option>
<option>Escola Primária N. 3037 - Cazenga</option>
<option>Escola Primária N. 3038 - Cazenga</option>
<option>Escola Primária N. 3041 - Cazenga</option>
<option>Escola Primária N. 3044 - Cazenga</option>
<option>Escola Primária N. 3046 - Cazenga</option>
<option>Escola Primária N. 3047 - Cazenga</option>
<option>Escola Primária N. 3051 - Cazenga</option>
<option>Escola Primária N. 3052 - Cazenga</option>
<option>Escola Primária N. 3054 - Cazenga</option>
<option>Escola Primária N. 3057 - Cazenga</option>
<option>Escola Primária N. 3058 - Cazenga</option>
<option>Escola Primária N. 3059 Iera - Cazenga</option>
<option>Escola Primária N. 3062 - Cazenga</option>
<option>Escola Primária N. 3063 - Cazenga</option>
<option>Escola Primária N. 3064 - Cazenga</option>
<option>Escola Primária N. 3066 "Maria Mazarelo" - Cazenga</option>
<option>Escola Primária N. 3067 - Cazenga</option>
<option>Escola Primária N. 3068 - Cazenga</option>
<option>Escola Primária N. 3070 - Cazenga</option>
<option>Escola Primária N. 3071 - Cazenga</option>
<option>Escola Primária N. 3073 - Cazenga</option>
<option>Escola Primária N. 3075 - Cazenga</option>
<option>Escola Primária N. 3077 - Cazenga</option>
<option>Escola Primária N. 3080 - Cazenga</option>
<option>Escola Primária N. 3082 - Metodista Unida - Cazenga</option>
<option>Escola Primária N. 3083 - Metodista Moises - Cazenga</option>
<option>Escola Primária N. 3090 - Cazenga</option>
<option>Escola Primária N. 3091 - Cazenga</option>
<option>Escola Primária N. 3094 - Cazenga</option>
<option>Escola Primária N. 3097 - Cazenga</option>
<option>Escola Primária N. 3105 - Cazenga</option>
<option>Escola Primária N. 3108 - Cazenga</option>
<option>Escola Primária N. 3110 - Cazenga</option>
<option>Escola Primária N. 3111 - Cazenga</option>
<option>Escola Primária N. 3112 - Cazenga</option>
<option>Escola Primária N.º 3093-Cazenga</option>
<option>Escola Primária N.º 3115-Cazenga</option>
<option>Instituto Politecnico Do Cazenga N.3072</option>
<option>Lceu N. 3040 - Oscar Ribas</option>
<option>Liceu N. 3043 - Cazenga</option>
<option>Liceu N. 3055 - Cazenga</option>
<option>Liceu N. 3084 - Cazenga</option>
<option>Liceu N. 3085 - Dom Afonso V</option>
<option>Liceu N. 3087 - Cazenga</option>
<option>Liceu N. 3088 - Cazenga</option>
<option>Liceu N. 3096 - Cazenga</option>
<option>Liceu N. 3106 "Ebenezer" - Cazenga</option>
<option>Magistério Da "Marconi" N. 3118</option>
<option>Pessoal Controlado Pela Dpe - Cazenga</option>
<option>Escola Do Iiº Ciclo Magistério Primário Nº 1093</option>
