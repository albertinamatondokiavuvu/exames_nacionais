<option>Cólégio Público N. 9005 - Talatona</option>
<option>Colégio Público N. 9027 - Talatona</option>
<option>Colégio Público N. 9035 - Talatona</option>
<option>Complexo Escolar (I E Ii Ciclo) N. 9001 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) Dom Moisés Alves De Pinho N. 9022 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) General Pedalé N. 9047 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9002 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9007 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9009 - 4 De Abril - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9013 Santa Teresinha Do Menino Jesus - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9015 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9018 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9019 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9020 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9021 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9023 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9025 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9033 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9037 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9040 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9041 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9044 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) N. 9046 - Talatona</option>
<option>Complexo Escolar (Prim. E I Ciclo) São Domingos Sávio N. 9017 - Talatona</option>
<option>Complexo Escolar Bob Hoskins N. 9014 - Talatona</option>
<option>Complexo Escolar Filadelfia N. 9003 - Talatona</option>
<option>Complexo Escolar N. 9034 - São José - Talatona</option>
<option>Complexo Escolar N. 9039 - Nossa Senhora Sede Da Sabedoria - Talatona</option>
<option>Complexo Escolar N. 9042 - Talatona</option>
<option>Complexo Escolar Richard Allen N. 9030 - Talatona</option>
<option>Complexo Escolar São Pedro Nolasco N. 9008 - Talatona</option>
<option>EscolaDirecção Municipal De Educação Do Talatona</option>
<option>Escola Primária Evangélica De Sião N. 9004 - Talatona</option>
<option>Escola Primária Juliana De Almeida N. 9012 - Talatona</option>
<option>Escola Primária N. 9016 - Talatona</option>
<option>Escola Primária N. 9024 - Talatona</option>
<option>Escola Primária N. 9028 - Talatona</option>
<option>Escola Primária N. 9029 - Talatona</option>
<option>Escola Primária N. 9031 "Ruth" - Talatona</option>
<option>Escola Primária N. 9038 - Talatona</option>
<option>Escola Primária N. 9043 - Talatona</option>
<option>Escola Primária N. 9045 - Talatona</option>
<option>Liceu N. 9006 - Talatona</option>
<option>Liceu N. 9026 - Sapú - Talatona</option>
<option>Liceu N. 9036 - 28 De Agosto - Talatona</option>
