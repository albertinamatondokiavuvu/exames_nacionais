<option>Cuito</option>
<option>Colégio N. 4047</option>
Colégio N. 4078 - Padre Ernesto</option>
Colégio Pública N. 4010 - Cacuaco</option>
Colégio Público N. 4027 - Cacuaco</option>
Colégio Público N. 4082 - Cacuaco</option>
<option>Complexo Escolar N. 4001 - Cacuaco</option>
<option>Complexo Escolar N. 4005 - Cacuaco</option>
<option>Complexo Escolar N. 4006 - Cacuaco</option>
<option>Complexo Escolar N. 4011 - Cacuaco</option>
<option>Complexo Escolar N. 4015 - Cacuaco</option>
<option>Complexo Escolar N. 4032</option>
<option>Complexo Escolar N. 4041 - Cacuaco</option>
<option>Complexo Escolar N. 4045 - Cacuaco</option>
<option>Complexo Escolar N. 4053 - Cacuaco</option>
<option>Complexo Escolar N. 4055 - Cacuaco</option>
<option>Complexo Escolar N. 4060 - Cacuaco</option>
<option>Complexo Escolar N. 4066 - Cacuaco</option>
<option>Complexo Escolar N. 4073 - Cacuaco</option>
<option>Complexo Escolar N. 4073 Padre Inácio - Cacuaco</option>
<option>Complexo Escolar N. 4075 - Cacuaco</option>
<option>Complexo Escolar N. 4081 - Cacuaco</option>
<option>Complexo Escolar N. 4085 - Cacuaco</option>
<option>Complexo Escolar N. 4086 - Cacuaco</option>
<option>Complexo Escolar N. 4087 - Cacuaco</option>
<option>Complexo Escolar N. 4091 - Cacuaco</option>
<option>Complexo Escolar N. 4092 - Cacuaco</option>
<option>Complexo Escolar N. 4096 - Cacuaco</option>
<option>Direcção Municipal Da Educação De Cacuaco</option>
<option>Direcção Municipal Da Educação De Cacuaco - Segurança</option>
<option>Escola Do Iiº Ciclo Nº 4083</option>
<option>Escola I Ciclo Do Ensino Secundário Nº 4093 - Cacuaco</option>
<option>Escola Prim. E Iº Ciclo Nº 4061</option>
<option>Escola Prim. E Iº Ciclo Nº 4065</option>
<option>Escola Primária  Nº 4017 Cacuaco</option> 
<option>Escola Primária E Iº Ciclo Do Ensino Secundário Nº 4020- Cacuaco</option> 
<option>Escola Primária N. 4003 Cacuaco</option>
<option>Escola Primária N. 4004 Cacuaco</option>
<option>Escola Primária N. 4008 - Cacuaco</option>
<option>Escola Primária N. 4009 - Cacuaco</option>
<option>Escola Primária N. 4012 - Cacuaco</option>
<option>Escola Primária N. 4013 Cacuaco</option>
<option>Escola Primária N. 4014 Cacuaco</option>
<option>Escola Primária N. 4016 - Cacuaco</option>
<option>Escola Primária N. 4020 - Cacuaco</option>
<option>Escola Primária N. 4021 Cacuaco</option>
<option>Escola Primária N. 4022 Cacuaco</option>
<option>Escola Primária N. 4024 Cacuaco</option>
<option>Escola Primária N. 4025 Cacuaco</option>
<option>Escola Primária N. 4028 Cacuaco</option>
<option>Escola Primária N. 4029 - Cacuaco</option>
<option>Escola Primária N. 4030 - Cacuaco</option>
<option>Escola Primária N. 4034 - Cacuaco</option>
<option>Escola Primária N. 4036 - Cacuaco</option>
<option>Escola Primária N. 4037 - Cacuaco</option>
<option>Escola Primária N. 4038 - Cacuaco</option>
<option>Escola Primária N. 4039 - Cacuaco</option>
<option>Escola Primária N. 4040 - Cacuaco</option>
<option>Escola Primária N. 4042 - Cacuaco</option>
<option>Escola Primária N. 4044 - Cacuaco</option>
<option>Escola Primária N. 4051 - Cacuaco</option>
<option>Escola Primária N. 4052 - Cacuaco</option>
<option>Escola Primária N. 4059 - Cacuaco</option>
<option>Escola Primária N. 4062 - Cacuaco</option>
<option>Escola Primária N. 4064 - Cacuaco</option>
<option>Escola Primária N. 4065 Cacuaco</option>
<option>Escola Primária N. 4067 Cacuaco</option>
<option>Escola Primária N. 4068 Cacuaco</option>
<option>Escola Primária N. 4069 Cacuaco</option>
<option>Escola Primária N. 4076 Cacuaco</option>
<option>Escola Primária N. 4079 Cacuaco</option>
<option>Escola Primária N. 4080 Cacuaco</option>
<option>Escola Primária N. 4088 Cacuaco</option>
<option>Escola Primária N. 4089 Cacuaco</option>
<option>Escola Primária N. 4090 Cacuaco</option>
<option>Escola Primária N. 4095 Cacuaco</option>
<option>Escola Primária Nº 4043 - Cacuaco</option> 
<option>Escola Prrimária N. 4041 - Cacuaco</option>
<option>Instituto Politécnico N. 4072 - Cacuaco</option>
<option>Liceu N. 4007 - Cacuaco</option>
<option>Liceu N. 4054 - Cacuaco</option>
<option>Liceu N. 4070 - Cacuaco</option>
<option>Liceu Nr. 8071 - Cacuco</option>
<option>Liceu Público N. 4019 - Cacuaco</option>
<option>Liceu Público N. 4054 - Cacuaco</option>
<option>Liceu Público N. 4056 - Cacuaco</option>
<option>Liceu Público N. 4071 - Cacuaco</option>
<option>Liceu Público N. 4083 - Cacuaco</option>
<option>Sec.Mun. Educação Do Cacuaco Admitidos Out. - 05</option>
