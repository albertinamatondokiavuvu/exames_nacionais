<option>Colegío N. 7020 - Cafuxi - Ambari</option>
<option>Complexo Escola N. 7024 - Cabo Lêdo</option>
<option>Complexo Escolar N. 7027 - Demba Chio</option>
<option>Complexo Escolar N. 7030 - Ilha Dourada</option>
<option>Direcção Municipal Da Educação Da Quiçama</option>
<option>Direcção Municipal Da Educação Da Quiçama - Segurança</option>
<option>Escola Do Iº Ciclo Ensino Secundario Nº 7025 Mumbondo</option>
<option>Escola Do Iº Ciclo Ensino Secundario Nº 7028 Kixinge</option>
<option>Escola Primária N. 7001 - Muxima</option>
<option>Escola Primária N. 7005 - Demba Guila</option>
<option>Escola Primária N. 7006 - Cabo - Lêdo</option>
<option>Escola Primária N. 7008 - Kindembele</option>
<option>Escola Primária N. 7010 - Demba Chio</option>
<option>Escola Primária N. 7015 - Candange Kixinge</option>
<option>Escola Primária N. 7016 - Mumbondo</option>
<option>Escola Primária N. 7021 - Candimba</option>
<option>Escola Primária N. 7022 - Sangano</option>
<option>Escola Primária N. 7029 - Kudissanga</option>
<option>Escola Primária Nº 7002- Cahululo</option>
<option>Escola Primária Nº 7012 - Kixinge Sede</option>
<option>Escola Primária Nº 7017 Cambo Mumbondo</option>
<option>Escola Primária Nº 7018- Menumba Vunge/ Mumbondo</option>
<option>Liceu N. 7026 - Quiçama</option>
<option>Med-Deleg.Munic.Quissama</option>