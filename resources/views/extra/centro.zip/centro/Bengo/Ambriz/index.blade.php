<option>Colégio Público N. 110 Comandante Hoji Henda</option>
<option>Colégio Público N. 112 Mbanza Nsolela</option>
<option>Escola Do I Ciclo Nº 112/Tabi - Ambriz</option>
<option>Escola Do I Ciclo Nº 116/Ambriz Sede - Ambriz</option>
<option>Escola Do I Ciclo Nº123 Bela Vista - Ambriz</option>
<option>Escola Do Ii Ciclo Nº 113 Do Ambriz - Ambriz</option>
<option>Escola Prim. Nº 105 - Loge Grande - Ambriz</option>
<option>Escola Prim. Nº 119 Kapulo - Ambriz</option>
<option>Escola Prim. Nº 121 Ningue - Ambriz</option>
<option>Escola Primária N. 101 Ngola Mbandi - Ambriz</option>
<option>Escola Primária N. 102 Augusto Ngangukla - Ambriz</option>
<option>Escola Primária N. 103 - 11 De Novembro</option>
<option>Escola Primária N. 104 Ndongalacia Nkua Muala</option>
<option>Escola Primária N. 105 - Nzinga Nkuvu</option>
<option>Escola Primária N. 106 - António Luís</option>
<option>Escola Primária N. 106 Nkimpa Nvita</option>
<option>Escola Primária N. 107 - Dr. António Agostinho Neto</option>
<option>Escola Primária N. 109 Nimi Ya Lukeni</option>
<option>Repartição Da Educação, Ciencia E Tecnologia De Ambriz - Ambriz</option>
