<option>Centro De Formacao Profissional De Caxito</option>
<option>Colégio Público N. 300 Dembo Sala Mubemba</option>
<option>Colégio Público N. 324 Do Kitongola</option>
<option>Colégio Público N. 325 Dr. António Agostinho Neto</option>
<option>Colégio Público N. 330 - Ludi Ii</option>
<option>Colégio Público N. 348 - Quicabo - Sede</option>
<option>Colégio Público N. 349 Kipetelo Ii</option>
<option>Complexo Escolar N. 303 - Musseque Cabele</option>
<option>Complexo Escolar N. 304 - Terreiro</option>
<option>Complexo Escolar N. 305 - Cerâmica</option>
<option>Complexo Escolar N. 306 - Terra Nova</option>
<option>Complexo Escolar N. 307 - Missionária Santa Ana</option>
<option>Complexo Escolar N. 308 - Barra Do Dande</option>
<option>Complexo Escolar N. 309 - Vale Do Paraíso</option>
<option>Complexo Escolar N. 310 - Amiga Da Criança</option>
<option>Complexo Escolar N. 311 - Prado De Sousa Paim - Panguila</option>
<option>Complexo Escolar N. 312 - Francisco Xavier Dos Santos</option>
<option>Complexo Escolar N. 315 - 11 De Novembro - Açucareira</option>
<option>Complexo Escolar N. 320 - Caccusso - Panguila</option>
<option>Complexo Escolar N. 326 - Agostinho Mendes De Carvalho</option>
<option>Complexo Escolar N. 340 - Brasileiro</option>
<option>Complexo Escolar N. 341 - Cidadela Das Crianças</option>
<option>Complexo Escolar N. 357 - Úcua - Sede</option>
<option>Complexo Escolar N. 358 - Progresso</option>
<option>Complexo Escolar N. 359 - Kolokyé - Vida E Sacrifício</option>
<option>Deleg.Munic.Educ.Icolo-Bengo/Colaboradores</option>
<option>Dir. Prov. De Alfabetizacao Do Bengo</option>
<option>Dir.Prov.Educ.Bengo-Conc.Pub./07-Ins.Jul.2008</option>
<option>Escola De Formação De Professores - Kimamuenho - Dande</option>
<option>Escola De Formacao De Tecnicos De Saude Do Bengo</option>
<option>Escola Do Ensino Primário N. 343 - Kissari</option>
<option>Escola Iiº Ciclo Do Ensino Secundario Nº 382/Panguila - Dande</option>
<option>Escola Primára N. 302 - Kijoão Mendes</option>
<option>Escola Primária - Sassa Mbanza - Dande</option>
<option>Escola Primaria Ana Mário Nº 003-Ana Mario - Dande</option>
<option>Escola Primaria Jossuana Nº 002-Jossuana - Dande</option>
<option>Escola Primária Mussenga - Dande</option>
<option>Escola Primária N. 301 - Mamuel Lopes Maria (Ximuto)</option>
<option>Escola Primária N. 313 - Quissomeira</option>
<option>Escola Primária N. 314 - Defesa</option>
<option>Escola Primária N. 316 - Ibêndua</option>
<option>Escola Primária N. 317 - Calenguela</option>
<option>Escola Primária N. 318 - Musseque Capari - Dande</option>
<option>Escola Primária N. 319 - Changai - Panguila</option>
<option>Escola Primária N. 321 - Ludi I</option>
<option>Escola Primária N. 321 - Mbembua</option>
<option>Escola Primária N. 322 - Ludi Ii</option>
<option>Escola Primária N. 323 - Muzondo</option>
<option>Escola Primária N. 327 - Sungui</option>
<option>Escola Primária N. 331 - Kitongola</option>
<option>Escola Primária N. 332 - Kala Kizua</option>
<option>Escola Primária N. 333 - Kimaria</option>
<option>Escola Primária N. 334 - Kissoma</option>
<option>Escola Primária N. 335 - Sassa Cária</option>
<option>Escola Primária N. 336 - Mifuma</option>
<option>Escola Primária N. 337 - Paranho</option>
<option>Escola Primária N. 338 - Sassa Povoação</option>
<option>Escola Primária N. 342 - Quirindo</option>
<option>Escola Primária N. 344 - Mabubas - Sede</option>
<option>Escola Primária N. 345 - Lembeca</option>
<option>Escola Primária N. 346 - Santa Amboleia</option>
<option>Escola Primária N. 347 - Boa Esperança Ii</option>
<option>Escola Primária N. 350 - Balacende</option>
<option>Escola Primária N. 351 - Lifune Ana Passo</option>
<option>Escola Primária N. 352 - Mazando</option>
<option>Escola Primária N. 353 - Kipetelo I</option>
<option>Escola Primária N. 354 - Tomba</option>
<option>Escola Primária N. 356 - Fwesse</option>
<option>Escola Primária N. 361 Pica</option>
<option>Escola Primária N. 377 - Ensino Especial</option>
<option>Escola Primária Ndui - Dande</option>
<option>Escola Primária Nº 310-Capunga - Dande</option>
<option>Escola Primária Nº 316 - Kudimuena - Dande</option>
<option>Escola Primária Nº 324-Catumbo - Dande</option>
<option>Escola Primária Nº 326-Pambala - Dande</option>
<option>Escola Primária Nº 327-Úlua - Dande</option>
<option>Escola Primária Nº 330 - Sassa Caria - Dande</option>
<option>Escola Primária Nº 335-Jungo - Dande</option>
<option>Escola Primária Nº 337-Berila - Dande</option>
<option>Escola Primária Nº 338-Berila - Dande</option>
<option>Escola Primária Nº 342-Kipasso - Dande</option>
<option>Escola Primária Nº 346-Mbanza Zombo - Dande</option>
<option>Escola Primária Nº 358-Mus. Mafulo - Dande</option>
<option>Escola Primária Nº 359 - Cabungo - Dande</option>
<option>Escola Primária Nº 362-Musseque Capunga - Dande</option>
<option>Escola Primária Nº 363-Bondo - Dande</option>
<option>Escola Primaria Nº 366-Boa Esperança I - Dande</option>
<option>Escola Primária Nº 368 - Cawango - Dande</option>
<option>Escola Primária Nº 370-Quicabo/Sede - Dande</option>
<option>Escola Primária Nº 371-Fwesse - Dande</option>
<option>Escola Primaria Nº 392-Cabacaça - Dande</option>
<option>Escola Primaria Nº 397 Três Casas - Dande</option>
<option>Escola Primaria Polivalente Nº 001-Polivalente - Dande</option>
<option>Escola Tecnica Saúde Açucareira - Dande</option>
<option>Esola Primária Nº 364-Cambondo - Dande</option>
<option>Folha De Subsidios De Ferias Em Atrazo</option>
<option>Instituto Médio Politécnico Do Bengo</option>
<option>Instituto Médio Politécnico Quimamuenho Do Bengo (Escola De Magistério Kimamuenho Do Bengo)</option>
<option>Liceu N. 379 - 4 De Fevereiro</option>
<option>Liceu N. 394 - João De Carvalho - Ngumbe</option>
<option>Med.Deleg.Munic.Ambriz.Bengo</option>
<option>Med.Deleg.Munic.Bula.Atumba</option>
<option>Med-Deleg.Munic.Dembos</option>
<option>Med-Deleg.Munic.Do Dande</option>
<option>Med-Deleg.Munic.Nambuangongo</option>
<option>Med-Deleg.Munic.Pango-Aluquem</option>
<option>Med-Deleg.Prov.Do Bengo</option>
<option>Repartição Da Educação, Ciencia E Tecnologia Dande - Dande</option>
<option>Reparticao Municipal Da Educacao Do Dande</option>
