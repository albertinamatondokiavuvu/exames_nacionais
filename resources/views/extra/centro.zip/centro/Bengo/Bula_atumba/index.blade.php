<option>Colégio Público N. 200 - Aníbal De Melo</option>
<option>Complexo Escolar N. 203 - Mukiama Kakulo</option>
<option>Complexo Escolar N. 205 - Domingos André Maria</option>
<option>Complexo Escolar N. 207 - Domingos Kakulo</option>
<option>Complexo Escolar N. 209 - Tomás Tito</option>
<option>Escola Prim. Nº 204 Chexe - Bula Atumba</option>
<option>Escola Prim. Nº 207 Dala Malundo - Bula Atumba</option>
<option>Escola Prim. Nº 212 Kinzenza - Bula Atumba</option>
<option>Escola Prim. Nº 213 Kikionzo - Bula Atumba</option>
<option>Escola Prim. Nº 217 Kissenga - Bula Atumba</option>
<option>Escola Prim. Nº 219 Kindambo - Bula Atumba</option>
<option>Escola Primária N. 201 - Bula Atumba Sede</option>
<option>Escola Primária N. 202 - Luís Graciano</option>
<option>Escola Primária N. 206 - Abílio César Armando</option>
<option>Escola Primária N. 208 - Paulo Camesa</option>
<option>Liceu N. 243 Joaquim Paxe - Bula Atumba</option>
<option>Reparticao Municipal De Educacao De Bula Atumba</option>
