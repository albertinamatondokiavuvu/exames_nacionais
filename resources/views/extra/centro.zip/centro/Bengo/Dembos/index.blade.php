<option>Complexo Escolar N. 413 - Henriques Cassule Kianvo</option>
<option>Escola Do I Ciclo Nº 429 - Paredes - Dembos</option>
<option>Escola Do I Ciclo Nº 438 - Coxe Sede - Dembos</option>
<option>Escola Do Ii Ciclo Dos Dembos - Dembos</option>
<option>Escola Prim. Nº 401 - Sede - Dembos</option>
<option>Escola Prim. Nº 4012 - Quinzala - Dembos</option>
<option>Escola Prim. Nº 402 - Banza - Dembos</option>
<option>Escola Prim. Nº 403 - Aldeia De Missão - Dembos</option>
<option>Escola Prim. Nº 404 - Missão Católica - Dembos</option>
<option>Escola Prim. Nº 405 - Quipungo - Dembos</option>
<option>Escola Prim. Nº 406 - Quifulo - Dembos</option>
<option>Escola Prim. Nº 407 - Catende - Dembos</option>
<option>Escola Prim. Nº 408 - Gombe De Kibaxe - Dembos</option>
<option>Escola Prim. Nº 408 - Gombe De Kibaxe - Dembos</option>
<option>Escola Prim. Nº 409 - Maria De Fátima - Dembos</option>
<option>Escola Prim. Nº 411 - Quissaquila - Dembos</option>
<option>Escola Prim. Nº 413 - Quimuquiama - Dembos</option>
<option>Escola Prim. Nº 415 - Quimuenga - Dembos</option>
<option>Escola Prim. Nº 416 - Quipaulo - Dembos</option>
<option>Escola Prim. Nº 417 - Quingange - Dembos</option>
<option>Escola Prim. Nº 418 - Quibaxe Sede - Dembos</option>
<option>Escola Prim. Nº 421 - Piri Velho - Dembos</option>
<option>Escola Prim. Nº 423 - Muquiama Samba - Dembos</option>
<option>Escola Prim. Nº 427 - Padeiro - Dembos</option>
<option>Escola Prim. Nº 431 - Quiamuandi - Dembos</option>
<option>Escola Prim. Nº 436 - Caputo - Dembos</option>
<option>Escola Prim. Nº 440 - Mobil - Dembos</option>
<option>Escola Primária N. 410 - Bernardo Domingos Pascoal (Kapasso)</option>
<option>Escola Primária N. 411 - Rufino Gonga Paca</option>
<option>Escola Primária N. 412 - Mbombo Cassule</option>
<option>Escola Primária N. 415 - David Cassule</option>
<option>I Ciclo N. 414 - Henriques Vasco Paulo Pambalo</option>
<option>Instituto Medio Politecnico Do Piri-Dembos - Dembos</option>
<option>Reparticao Municipal Da Educacao Dos Dembos</option>
