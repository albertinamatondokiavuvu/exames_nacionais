<option>Colégio Nº 812 - Gombe</option>
<option>Escola Primária Nº 801 - Benza</option>
<option>Escola Primária Nº 803 - Catanda</option>
<option>Escola Primária Nº 804 - Quita</option>
<option>Escola Primária Nº 805 - Dungo</option>
<option>Escola Primária Nº 806 - Gombe</option>
<option>Escola Primária Nº 807 - Cazua</option>
<option>Instituto Médio Politécnico Do Bengo</option>
<option>Med-Delegação Municipal - Ambriz</option>
<option>Med-Delegação Municipal - Dande</option>
<option>Med-Delegação Municipal - Dembos Quibaxi</option>
<option>Med-Delegação Municipal - Nambuangongo</option>
<option>Med-Delegação Municipal - Pango Aluquém</option>
<option>Med-Delegação Municipal Bula Tumba</option>
