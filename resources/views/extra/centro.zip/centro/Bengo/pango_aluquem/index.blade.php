<option>Colégio Público N. 806 - 28 De Agosto</option>
<option>Escola Do I Ciclo Nº 813 - Cazua - Pango Aluquem</option>
<option>Escola Do Iiº Ciclo Do Ensino Secundario Nº 817/Pango Velho - Pango Aluquém</option>
<option>Escola Do Iº Ciclo Nº 814/Quita - Pango Aluquém</option>
<option>Escola Primária N. 800 - Carlos Escrivão Tavares</option>
<option>Escola Primaria Nº 801/Benza - Pango Aluquém</option>
<option>Reparticao Municipal De Educacao De Pango Aluquem/Bengo</option>
<option>Escola Do Ii Ciclo Do Ensino Secundario Da Eiffel</option>
