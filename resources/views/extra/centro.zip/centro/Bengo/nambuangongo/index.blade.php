<option>Complexo Escolar N. 731 Rodrigues C. Candido</option>
<option>Complexo Escolar N. 732 Cdte Staline</option>
<option>Complexo Escolar N. 733 Lopes Maria Ximuto</option>
<option>Complexo Escolar N. 734 António Adolfo Sacudido</option>
<option>Complexo Escolar N. 735 João Mario Da Costa</option>
<option>Complexo Escolar N. 735 João Mario Da Costa</option>
<option>Complexo Escolar N. 736 Kiwembo</option>
<option>Escola Do Lº Ciclo Nº 725 - Muxaluando Sede </option>
<option>Escola Primaria 751/Kilai </option>
<option>Escola Primaria N. 700 Cdte Dimbondua</option>
<option>Escola Primária N. 701 - Kissacala</option>
<option>Escola Primária N. 705 Kinguengo</option>
<option>Escola Primária N. 706 - Nobre Manuel Adão</option>
<option>Escola Primária N. 707 Vila - Mpipa</option>
<option>Escola Primária N. 708 Kilumbo</option>
<option>Escola Primária N. 709 Kimazangui</option>
<option>Escola Primária N. 712 Lopes Fernando</option>
<option>Escola Primária N. 713 Sebastião Bundo</option>
<option>Escola Primária N. 715 Raul Marques Mahinga</option>
<option>Escola Primária N. 716 - Zemba</option>
<option>Escola Primária N. 717 Kihinga Nzambi</option>
<option>Escola Primária N. 718 - Gonçalves G. Cauanga</option>
<option>Escola Primária N. 719 Kimbage</option>
<option>Escola Primária N. 720 Gomes João Neto</option>
<option>Escola Primária N. 722 Mutolo Muginga</option>
<option>Escola Primária N. 723 Kicangassala</option>
<option>Escola Primária N. 724 Pedro Mateus Congo</option>
<option>Escola Primária N. 725 João D. De Carvalho</option>
<option>Escola Primária N. 726 Tempo Muda</option>
<option>Escola Primária N. 727 - Teresa Afonso</option>
<option>Escola Primária N. 728 Kiniêngue</option>
<option>Escola Primária N. 729 Tongo Dyandua</option>
<option>Escola Primaria Nº 701 - Kicunzo Sede </option>
<option>Escola Primaria Nº 703 - Hala-Amor </option>
<option>Escola Primaria Nº 705 - Kimussanga </option>
<option>Escola Primaria Nº 706 - Muanda </option>
<option>Escola Primaria Nº 711 - Calunga-Samba </option>
<option>Escola Primaria Nº 712/Zambaxi </option>
<option>Escola Primaria Nº 716/Terra-Nova </option>
<option>Escola Primaria Nº 720 - Matanga </option>
<option>Escola Primaria Nº 721 - Kifula </option>
<option>Escola Primaria Nº 723 - Kissacala </option>
<option>Escola Primaria Nº 724 - Águas-Belas </option>
<option>Escola Primaria Nº 727 - Kigombe </option>
<option>Escola Primaria Nº 729 - Posse </option>
<option>Escola Primaria Nº 730 - Libanzo </option>
<option>Escola Primaria Nº 731 - Hungo </option>
<option>Escola Primaria Nº 736/Kinguimbi </option>
<option>Escola Primaria Nº 738/Kuto </option>
<option>Escola Primaria Nº 740/Kifuta </option>
<option>Escola Primaria Nº 742/Gombe Sede </option>
<option>Escola Primaria Nº 743/Kifama </option>
<option>Escola Primaria Nº 744/Hinda </option>
<option>Escola Primaria Nº 746/Kicanga Samba </option>
<option>Escola Primaria Nº 747/Kimuanassala </option>
<option>Escola Primaria Nº 750/Kimbamba </option>
<option>Escola Primaria Nº 754/Kinzeguete </option>
<option>Escola Primaria Nº 755/Kiba </option>
<option>Escola Primaria Nº 758/Kiembo </option>
<option>Escola Primaria Nº 767 - Muxaluando Sede </option>
<option>Escola Primaria Nº 769/Kicunzo </option>
<option>Escola Primaria Nº 771/Kiginga </option>
<option>Escola Primaria Nº 772/Kindembe </option>
<option>Liceu N. 774 - General Domingos Sks</option>
<option>Repartição De Educação, Ciencia E Tecnologia Nambuango </option>
<option>Reparticao Municipal De Educacao D/Bengo</option>
