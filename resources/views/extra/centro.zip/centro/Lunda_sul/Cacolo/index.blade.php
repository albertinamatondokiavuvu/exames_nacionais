<option>Escola Do Ensino Primario E Nucleo Do Primeiro Ciclo Do Alto</option>
<option>Escola Primaria Do Chicundo - Cacolo</option>
<option>Escola Primária N. 03 São José Freinadmetz </option>
<option>Escola Primária N. 04 Emídio Da Silva </option>
<option>Escola Primária N. 05 Minungo </option>
<option>Escola Primária N. 07 Muacatende </option>
<option>Escola Primária N. 12 28 De Agosto </option>
<option>Escola Primária N. 17 4 De Fevereiro </option>
<option>Escola Primária N. 39 4 De Abril </option>
<option>Magistério N. 02 Amado Issanzo </option>
<option>Repartição Municipal Da Educação Do Cacolo</option>