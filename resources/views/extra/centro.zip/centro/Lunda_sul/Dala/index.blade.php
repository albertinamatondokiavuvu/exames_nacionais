<option>Colégio N. 35 14 De Abril </option>
<option>Escola Primária  Comadante Nicolau G Specer  - Dala</option>
<option>Escola Primária Angola Cuba Nº111 - Dala</option>
<option>Escola Primária De Mungundja - Dala</option>
<option>Escola Primária Missão Católica Nº110 - Dala</option>
<option>Escola Primária Mucuamuilo - Dala</option>
<option>Escola Primária N. 1 Angola Cuba </option>
<option>Escola Primária N. 15 Cazoa </option>
<option>Escola Primária N. 18 11 De Novembro </option>
<option>Escola Primária N. 21 Biúla </option>
<option>Escola Primária N. 25 L. Cassai </option>
<option>Escola Primária N. 7 Luachimo </option>
<option>Escola Primária N. 9 Luele </option>
<option>Escola Primária Nº 112 Txigilege - Dala</option>
<option>Magistério N. 36 16 De Agosto </option>
<option>Repartição Municipal Da Educação Do Dala</option>