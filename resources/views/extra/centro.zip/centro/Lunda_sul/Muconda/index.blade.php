<option>Escola Primária 17 De Setembro - Muconda</option>
<option>Escola Primária 4 De Abril - Muconda</option>
<option>Escola Primária N. 1 4 De Abril </option>
<option>Escola Primária N. 10 Zango </option>
<option>Escola Primária N. 15 Agostinho Mendes Carvalho</option> 
<option>Escola Primária N. 17 Augusto Ngangula </option>
<option>Escola Primária N. 19 Liberdade </option>
<option>Escola Primária N. 22 Comandante Valódia </option>
<option>Escola Primária N. 28 1 De Maio </option>
<option>Escola Primária N. 3 Antigos Combatente </option>
<option>Escola Primária N. 30 Dr António Agostinho Neto </option>
<option>Escola Primária N. 32 Joaquim Cardoso Jaquinda </option>
<option>Escola Primária N. 34 Maria Eugenia Neto </option>
<option>Escola Primária N. 36 16 De Junho </option>
<option>Escola Primária N. 6 Astides Cadete Kima-Kenda</option> 
<option>Escola Primária N. 7 Deolinda Rodrigues </option>
<option>Escola Primária Nakatenga - Muconda</option>
<option>Escola Primária Txinguli - Muconda</option>
<option>Magistério N. 38 Certeza Muconda </option>
<option>Repartição Municipal Da Educação De Muconda</option>
