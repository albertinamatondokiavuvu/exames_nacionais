<option>Centro Materno Infantil Lunda-Sul / Contratado</option>
<option>Centro Pre-Universitario De Saurimo</option>
<option>Colégio N. 02 Ex Ii Nível </option>
<option>Colégio N. 03 28 De Maio </option>
<option>Colégio N. 04 4 De Abril </option>
<option>Colégio N. 05 22 De Novembro </option>
<option>Colégio N. 06 Candmbe Ii </option>
<option>Colégio N. 07 Camundambala </option>
<option>Complexo Escolar 1 De Junho N. 98 "Mona Quimbundo"</option>
<option>Complexo Escolar Do Ens. G. E T. Profissional N. 08 Luar </option>
<option>Complexo Escolar Ensino Especial N. 01</option>
<option>Complexo Escolar N. 04 17 De Setembro </option>
<option>Complexo Escolar N. 05 28 De Agosto Txicumina </option>
<option>Complexo Escolar N. 06 Mahatma Gandhi Regedoria Cazembe</option>
<option>Complexo Escolar N. 10 Comandante Txizainga</option>
<option>Complexo Escolar N. 11 Ilda Calupeteca </option>
<option>Complexo Escolar N. 12 Mwono Waha</option>
<option>Complexo Escolar N. 13 Do Sueja</option>
<option>Complexo Escolar N. 2 Missão Masculino</option>
<option>Complexo Escolar N. 27 General Txizainga</option>
<option>Complexo Escolar N. 3 Missão Feminina</option>
<option>Complexo Escolar N. 05 José Manuel Luembe </option>
<option>Dir.Prov.Educ.-Conc.Pub./07-Ins.Mai./08</option>
<option>Dir.Prov.Educ.Lunda Sul-Conc.Pub./06-Ins.Jul.</option>
<option>Escola De Formação De Técnicos De Saúde Da Lunda Sul / Contratado</option>
<option>Escola Do Iº Ciclo Do Ensino Secundario Muatxissengue Wa-Tembo - Saurimo</option>
<option>Escola Primária Caiaza - Saurimo</option>
<option>Escola Primária Do Sacombe - Saurimo</option>
<option>Escola Primária N. 04 Jonate Mário Pinto</option>
<option>Escola Primária N. 06 Txizainga-1</option>
<option>Escola Primária N. 08 Do Bairro Luavur Zona C</option>
<option>Escola Primária N. 09 António Coimbra Da Silva</option>
<option>Escola Primária N. 1 Dr. Raúl Fernades Júnior</option>
<option>Escola Primária N. 101 Do Bairro Peso Velho</option>
<option>Escola Primária N. 105 Do Bairro Txipamba</option>
<option>Escola Primária N. 11 4 De Fevereiro - Curva </option>
<option>Escola Primária N. 111 Do Sombo Sede</option>
<option>Escola Primária N. 12 14 De Abril Do Manauto 1</option>
<option>Escola Primária N. 13 Do Manauto 2</option>
<option>Escola Primária N. 14 Ruth Hadly Missão Camundambala</option>
<option>Escola Primária N. 16 São João Calábria</option>
<option>Escola Primária N. 17 Paróquia Santo António</option>
<option>Escola Primária N. 18 Do Bairro Luavur Zona B</option>
<option>Escola Primária N. 19 Santa Ana Aldeia Da Missão</option>
<option>Escola Primária N. 20 Do Bairro Camitundo</option>
<option>Escola Primária N. 23 Do Bairro Candembe 2</option>
<option>Escola Primária N. 24 Do Bairro Luavur Zona A</option>
<option>Escola Primária N. 25 Do Bairro Muandonji-Caxita</option>
<option>Escola Primária N. 26 Do Bairro Candembe 1</option>
<option>Escola Primária N. 32 José Txiessuetxipi</option>
<option>Escola Primária N. 33 Beato Carlo Steeb</option>
<option>Escola Primária N. 34 Do Bairro Luar</option>
<option>Escola Primária N. 35 Do Bairro Muangueji</option>
<option>Escola Primária N. 36 1 De Junho Mulombe </option>
<option>Escola Primária N. 39 Do Bairro Conduril</option>
<option>Escola Primária N. 40 Do Bairro Kawazanga</option>
<option>Escola Primária N. 41 1 De Dezembro</option>
<option>Escola Primária N. 48 Samupafo</option>
<option>Escola Primária N. 70 Do Bairro Sacambundji</option>
<option>Escola Primária N. 91 Do Bairro Caliwe</option>
<option>Escola Primária Sacaxima - Saurimo</option>
<option>Instituto Agrário Mona-Quimbundo N. 9 - Saurimo</option>
<option>Instituto Médio Politécnico Da Lunda Sul N. 01</option>
<option>Instituto Tecnico De Saude N. 01</option>
<option>Lar Da Assistência A Pessoa Idosa Do Saurimo/Lunda Sul / Contratado</option>
<option>Liceu N. 01 José Manuel Salucombo</option> 
<option>Liceu N. 02 São Kizito </option>
<option>Magistério N. 01 Amor Do Povo De Saurimo </option>
<option>Med-Deleg.Prov.(Colaborad.I,Ii,Iii Niveis L.S</option>
<option>Med-Delegaçao Municipal De Saurimo - L. Sul</option>
<option>Med-Delegaçao Municipal Do Cacolo - L. Sul</option>
<option>Med-Delegaçao Municipal Do Dala - L. Sul</option>
<option>Med-Delegaçao Municipal Do Muconda - L. Sul</option>
<option>Med-Delegaçao Provincial Da Lunda-Sul</option>
<option>Med-Direccao Do Instituto Med.Nor.Educacao</option>
<option>Med-Escola Anexa - L. Sul</option>
<option>Med-Inst. Med. N. Ed.(Colaboradores) - L.Sul</option>
<option>Repartição Municipal Da Educação De Saurimo</option>
<option>Sec.Mun. Educação Do Cacuaco - Admitidos Out. - 05</option>
