<option>Escola Do Ensino Primário  Nº 155 - Chicomba</option>
<option>Escola Do Ensino Primário 17 De Setembro Nº 880 - Chicomba</option>
<option>Escola Do Ensino Primário Babayela-Utupo Nº 1584 - Chicomba</option>
<option>Escola Do Ensino Primário Banga Bisseque Nº 574 - Chicomba</option>
<option>Escola Do Ensino Primário Banga-Cavincia Nº 579 - Chicomba</option>
<option>Escola Do Ensino Primário Banga-Nguenje Nº 583 - Chicomba</option>
<option>Escola Do Ensino Primário Banga-Vatemba Nº 582 - Chicomba</option>
<option>Escola Do Ensino Primário Banga-Yela Nº 677 - Chicomba</option>
<option>Escola Do Ensino Primário Banje Nº 1409 - Chicomba</option>
<option>Escola Do Ensino Primário Bisseque  Nº 652 - Chicomba</option>
<option>Escola Do Ensino Primário Cachiculo Nº 673 - Chicomba</option>
<option>Escola Do Ensino Primário Cainholi Nº 586 - Chicomba</option>
<option>Escola Do Ensino Primário Caissamba Missão Nº 659 - Chicomba</option>
<option>Escola Do Ensino Primário Caliongo Ii Nº 1215 - Chicomba</option>
<option>Escola Do Ensino Primário Calohombe Nº 680 - Chicomba</option>
<option>Escola Do Ensino Primário Calussumba Nº 618 - Chicomba</option>
<option>Escola Do Ensino Primário Caluvi Nº 596 - Chicomba</option>
<option>Escola Do Ensino Primário Cambanje Nº 637 - Chicomba</option>
<option>Escola Do Ensino Primário Cambunlunga - Barraca Nº 647 - Chicomba</option>
<option>Escola Do Ensino Primário Camupa Chipiquita Nº 640 - Chicomba</option>
<option>Escola Do Ensino Primário Candunda Nº 1725 - Chicomba</option>
<option>Escola Do Ensino Primário Canequela-Canjovi Nº 578 - Chicomba</option>
<option>Escola Do Ensino Primário Cangoma Nº 1822 - Chicomba</option>
<option>Escola Do Ensino Primário Cangundo Londau Nº 1823 - Chicomba</option>
<option>Escola Do Ensino Primário Caputo Nº 1585 - Chicomba</option>
<option>Escola Do Ensino Primário Cassenge-Chindululo Nº 654 - Chicomba</option>
<option>Escola Do Ensino Primário Catonga Nº 653 - Chicomba</option>
<option>Escola Do Ensino Primário Central Cawele Nº 669 - Chicomba</option>
<option>Escola Do Ensino Primário Chananga Nº 666 - Chicomba</option>
<option>Escola Do Ensino Primário Chandamba Nº 671 - Chicomba</option>
<option>Escola Do Ensino Primário Chimbalandongo Nº 658 - Chicomba</option>
<option>Escola Do Ensino Primário Chipupa Nº 1673 - Chicomba</option>
<option>Escola Do Ensino Primário Chissandua Nº 1406 - Chicomba</option>
<option>Escola Do Ensino Primário Chitapua Nº 1187 - Chicomba</option>
<option>Escola Do Ensino Primário Chivimbi Nº 577 - Chicomba</option>
<option>Escola Do Ensino Primário Chivinda  Nº 1644 - Chicomba</option>
<option>Escola Do Ensino Primário Cotele-Bambi Nº 1119 - Chicomba</option>
<option>Escola Do Ensino Primário Covongo Nº 888 - Chicomba</option>
<option>Escola Do Ensino Primário Cutenda Nº 675 - Chicomba</option>
<option>Escola Do Ensino Primário Dongui Catapa Nº 591 - Chicomba</option>
<option>Escola Do Ensino Primário Etala Nº 607 - Chicomba</option>
<option>Escola Do Ensino Primário Fazenda Tomba Nº 1389 - Chicomba</option>
<option>Escola Do Ensino Primário Hanguenga Nº 1555 - Chicomba</option>
<option>Escola Do Ensino Primário Holo Caita Nº 1819 - Chicomba</option>
<option>Escola Do Ensino Primário Holo-Miranda Nº 576 - Chicomba</option>
<option>Escola Do Ensino Primário Hulo- Manico Nº 650 - Chicomba</option>
<option>Escola Do Ensino Primário Km 42  Nº 678 - Chicomba</option>
<option>Escola Do Ensino Primário Lonale  Nº 703 - Chicomba</option>
<option>Escola Do Ensino Primário Longongo Nº 516 - Chicomba</option>
<option>Escola Do Ensino Primário Luapanda Nº 626 - Chicomba</option>
<option>Escola Do Ensino Primário Lueyo Nº 590 - Chicomba</option>
<option>Escola Do Ensino Primário Luhimba Nº 656 - Chicomba</option>
<option>Escola Do Ensino Primário Lusseque Nº 643 - Chicomba</option>
<option>Escola Do Ensino Primário Luvinja Nº 651 - Chicomba</option>
<option>Escola Do Ensino Primário Muhiquila Nº 657 - Chicomba</option>
<option>Escola Do Ensino Primário Muhona Nº 575 - Chicomba</option>
<option>Escola Do Ensino Primário Mupalala Nº 634 - Chicomba</option>
<option>Escola Do Ensino Primário Mussungo Nº 1564 - Chicomba</option>
<option>Escola Do Ensino Primário Ngalo Nº 587 - Chicomba</option>
<option>Escola Do Ensino Primário Ngoti  Nº 1559 - Chicomba</option>
<option>Escola Do Ensino Primário Pau-Seco Nº 1126 - Chicomba</option>
<option>Escola Do Ensino Primário Pilimbimbi Nº 663 - Chicomba</option>
<option>Escola Do Ensino Primário Puku-Puku Nº 298 - Chicomba</option>
<option>Escola Do Ensino Primário Sapumbula Nº 642 - Chicomba</option>
<option>Escola Do Ensino Primário Talama I Nº 911 - Chicomba</option>
<option>Escola Do Ensino Primário Tchicala Cangolo Nº 1820 - Chicomba</option>
<option>Escola Do Ensino Primário Ucuala Canjongonjongo Nº 588 - Chicomba</option>
<option>Escola Do Ensino Primário Upindi -Alto Nº 1422 - Chicomba</option>
<option>Escola Do Ensino Primário Usselem Nº 1014 - Chicomba</option>
<option>Escola Do Ensino Primário Vicuyo Nº 1821 - Chicomba</option>
<option>Escola Do Ensino Primário Vila- Real Nº 624 - Chicomba</option>
<option>Escola Do Ensino Primário Vingueve Nº 878 - Chicomba</option>
<option>Escola Do Ensino Primário Wissingui Nº 632 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário Cabir Regedoria Nº 570 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário Cacongo-Cafoia Nº 1156 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário Cherequela Nº 1213 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário De Cutenda Sede Nº 1643 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário Missão Catolica 649 Nº 649 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário Nondumbo Nº 635 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Primário Qué Nº 1209 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Secundário Chicomba- Sede Nº 684 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Secundário Do Vihopio Nº 1328 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Secundário Libongue Nº 1641 - Chicomba</option>
<option>Escola Do I Ciclo Do Ensino Secundário Sec. Fazenda Tomba Nº 648 - Chicomba</option>
<option>Escola Primária Bulo - Sede N. 605 </option>
<option>Escola Primária Bumba N. 679 </option>
<option>Escola Primária Cabir Comercial N. 118 </option>
<option>Escola Primária Caliongo I N. 589 </option>
<option>Escola Primária Capunga N. 662 </option>
<option>Escola Primária Chavindilica N. 1405 </option>
<option>Escola Primária Chicambi N. 636 </option>
<option>Escola Primária Chicomba - Velha N. 674 </option>
<option>Escola Primária Chilueio Capamba N. 644</option> 
<option>Escola Primária Cucala N. 619 </option>
<option>Escola Primária Cututo - Baixo N. 1240 </option>
<option>Escola Primária <option>Escola N. 676 N. 676 </option>
<option>Escola Primária I De Junho Dilindinda N. 258</option> 
<option>Escola Primária Libongue N. 1640 </option>
<option>Escola Primária Muholo Hangalo N. 1188 </option>
<option>Escola Primária Munquete N. 815 </option>
<option>Escola Primária Ndala N. 672 </option>
<option>Escola Primária Ngolo N. 621 </option>
<option>Escola Primária Nunce N. 601 </option>
<option>Escola Primária Santana N. 1201 </option>
<option>Escola Primária Ulola - Wongunga N. 1062</option> 
<option>Escola Primária Vihopio N. 660 </option>
<option>Escola Primária Wayola N. 664 </option>
<option>Liceu N. 1642 - Chicomba</option>

