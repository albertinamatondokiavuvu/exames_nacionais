<option>Colégio 22 De Novembro N. 1437 <option>
<option>Escola Do Ensino Primário Bowe Nº 1367 - Chipindo<option>
<option>Escola Do Ensino Primário Canjanja Nº 1369 - Chipindo<option>
<option>Escola Do Ensino Primário Catápua Nº 1373 - Chipindo<option>
<option>Escola Do Ensino Primário Chiconguele Samacaca Nº 1457 - Chipindo<option>
<option>Escola Do Ensino Primário Chipalanga Nº 1380 - Chipindo<option>
<option>Escola Do Ensino Primário Ngangula  Nº 1444 - Chipindo<option>
<option>Escola Do Ensino Primário Ngongo Nº 1446 - Chipindo<option>
<option>Escola Primária 19 De Março N. 1430 <option>
<option>Escola Primária 4 De Abril N. 1782 <option>
<option>Escola Primária Bambi N. 1365 <option>
<option>Escola Primária Belécua N. 1366 <option>
<option>Escola Primária Buloteque N. 1424 <option>
<option>Escola Primária Bunjei N. 1438 <option>
<option>Escola Primária Camassissa N. 1808 <option>
<option>Escola Primária Candungo N. 1591 <option>
<option>Escola Primária Canhawenga N. 1431 <option>
<option>Escola Primária Capembe N. 1425 <option>
<option>Escola Primária Capuka N. 1426 <option>
<option>Escola Primária Caquela N. 419 <option>
<option>Escola Primária Cassema N. 1371 <option>
<option>Escola Primária Centro Catchuco N. 1427 <option>
<option>Escola Primária Centro Escolar Lino N. 1375 <option>
<option>Escola Primária Centro Kawanga N. 1439 <option>
<option>Escola Primária Chilanda N. 1448 <option>
<option>Escola Primária Chiliva N. 1436 <option>
<option>Escola Primária Chitata N. 1428 <option>
<option>Escola Primária Chuvica N. 1440 <option>
<option>Escola Primária Dingo N. 1429 <option>
<option>Escola Primária Dovala N. 421 <option>
<option>Escola Primária Guelengue N. 1432 <option>
<option>Escola Primária Katchawa N. 1381 <option>
<option>Escola Primária Macongue N. 1382 <option>
<option>Escola Primária Missão Da Ieca N. 1445 <option>
<option>Escola Primária N. 153 <option>
<option>Escola Primária Ngala N. 406 <option>
<option>Escola Primária Nguvulo N. 1259 <option>
<option>Escola Primária Sacalombo N. 1442 <option>
<option>Escola Primária Sangueve N. 420 <option>
<option>Escola Primária Sapato N. 1443 <option>
<option>Escola Primária Sapi N. 1434 <option>
<option>Escola Primária Songa N. 1385  <option>
<option>Escola Primária Uyamba N. 1435 <option>
<option>EscolaLiceu N. 1832 - Chipindo<option>