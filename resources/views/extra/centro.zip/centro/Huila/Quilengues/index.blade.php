<option>Colégio N. 908</option> 
<option>Escola Do Ensino Primário  Nº 185 - Quilengues</option>
<option>Escola Do Ensino Primário 1º De Junho  Nº 429 - Quilengues</option>
<option>Escola Do Ensino Primário 1º De Maio  Nº 203 - Quilengues</option> 
<option>Escola Do Ensino Primário Babaera - Kassapola Nº 834 - Quilengues</option>
<option>Escola Do Ensino Primário Babaera - Tchississi  Nº 835 - Quilengues</option>
<option>Escola Do Ensino Primário Bandi-Kahanga  Nº 836 - Quilengues</option>
<option>Escola Do Ensino Primário Bocoio Nº 244 - Quilengues</option>
<option>Escola Do Ensino Primário Bonga - Mapumbo  Nº 837 - Quilengues</option>
<option>Escola Do Ensino Primário Bonga - Tchinhimue  Nº 838 - Quilengues</option>
<option>Escola Do Ensino Primário Camuhamba  Nº 869 - Quilengues</option>
<option>Escola Do Ensino Primário Camulemba Baixo Nº 1596 - Quilengues</option>
<option>Escola Do Ensino Primário Candombe  Nº 718 - Quilengues</option>
<option>Escola Do Ensino Primário Cassombo  Nº 817 - Quilengues</option>
<option>Escola Do Ensino Primário Cavimbovo  Nº 665 - Quilengues</option>
<option>Escola Do Ensino Primário Cutembo Fazenda  Nº 206 - Quilengues</option>
<option>Escola Do Ensino Primário Cutembo Tchipaquela  Nº 731 - Quilengues</option>
<option>Escola Do Ensino Primário Cutembo Yango Nº 857 - Quilengues</option>
<option>Escola Do Ensino Primário Doroma Canhama  Nº 218 - Quilengues</option>
<option>Escola Do Ensino Primário Hecuque  Nº 246 - Quilengues</option>
<option>Escola Do Ensino Primário Húpia  Nº 248 - Quilengues</option>
<option>Escola Do Ensino Primário Kalengue Nº 214 - Quilengues</option>
<option>Escola Do Ensino Primário Kambongue  Nº 884 - Quilengues</option>
<option>Escola Do Ensino Primário Kumbambi  Nº 1024 - Quilengues</option>
<option>Escola Do Ensino Primário Kuyo Nº 661 - Quilengues</option>
<option>Escola Do Ensino Primário Lucondo Missão Nº 249 - Quilengues</option>
<option>Escola Do Ensino Primário Lusseque  Nº 843 - Quilengues</option>
<option>Escola Do Ensino Primário Maneno Nº 1815 - Quilengues</option>
<option>Escola Do Ensino Primário Massondjo - Kandenga Nº 186 - Quilengues</option>
<option>Escola Do Ensino Primário Mavele Nº 1816 - Quilengues</option>
<option>Escola Do Ensino Primário Mílua  Nº 174 - Quilengues</option>
<option>Escola Do Ensino Primário Missão Da Catala Nº 238 - Quilengues</option>
<option>Escola Do Ensino Primário Muiva  Nº 251 - Quilengues</option>
<option>Escola Do Ensino Primário Munengolo  Nº 711 - Quilengues</option>
<option>Escola Do Ensino Primário Mutepila  Nº 182 - Quilengues</option>
<option>Escola Do Ensino Primário Muxaca Nº 179 - Quilengues</option>
<option>Escola Do Ensino Primário Nkhuvi  Nº 180 - Quilengues</option>
<option>Escola Do Ensino Primário Nthiengue  Nº 846 - Quilengues</option>
<option>Escola Do Ensino Primário Pira  Nº 207 - Quilengues</option>
<option>Escola Do Ensino Primário Poto-Catchimano  Nº 81 - Quilengues</option>
<option>Escola Do Ensino Primário Tchalawa  Nº 254 - Quilengues</option>
<option>Escola Do Ensino Primário Tchimbungo Nº 1814 - Quilengues</option>
<option>Escola Do Ensino Primário Tchindiolo  Nº 1733 - Quilengues</option>
<option>Escola Do Ensino Primário Tchissamba  Nº 746 - Quilengues</option>
<option>Escola Do Ensino Primário Tchitalambala Nº 714 - Quilengues</option>
<option>Escola Do Ensino Primário Tchitaqui - Cima  Nº 239 - Quilengues</option>
<option>Escola Do Ensino Primário Tchitata  Nº 865 - Quilengues</option>
<option>Escola Do Ensino Primário Tchituli Nº 734 - Quilengues</option>
<option>Escola Do Ensino Primário Tchiyavula  Nº 854 - Quilengues</option>
<option>Escola Do Ensino Primário Twei - Amelia  Nº 978 - Quilengues</option>
<option>Escola Do Ensino Primário Twei-Calunga Nº 288 - Quilengues</option>
<option>Escola Do Ensino Primário Ukali Ndambo Nº 198 - Quilengues</option>
<option>Escola Do Ensino Primário Ukali Nhõha  Nº 189 - Quilengues</option>
<option>Escola Do Ensino Primário Ukali-Vimboto  Nº 209 - Quilengues</option>
<option>Escola Do Ensino Primário Utalala Nº 855 - Quilengues</option>
<option>Escola Do Ensino Primário Uvoli - Mandele  Nº 868 - Quilengues</option>
<option>Escola Do Ensino Primário Vaile  Nº 856 - Quilengues</option>
<option>Escola Do Ensino Primário Vipembe  Nº 202 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Primário  Nº 245 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Primário Bonga-Quilengues  Nº 205 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Primário Camucua Nº 236 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Primário Camulemba Sede Nº 225 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Primário Kalohanda Nº 1214 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Primário Muloi I Nº 172 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Secundário Catala Missão Nº 875 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Secundário Nº 1123 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Secundário Ukali Povoação Nº 822 - Quilengues</option>
<option>Escola Do I Ciclo Do Ensino Secundáriode Quicuco Nº 1482 - Quilengues</option>
<option>Escola Primária Bonga Mayulo N. 825 </option>
<option>Escola Primária Candjindji N. 713 </option>
<option>Escola Primária Catchissanda N. 1813 </option>
<option>Escola Primária Catumba N. 870 </option>
<option>Escola Primária Cavissombo N. 242 </option>
<option>Escola Primária Cutembo Tchimbeu N. 190 </option>
<option>Escola Primária Doroma - Tchicundjo N. 217 </option>
<option>Escola Primária Doroma Mapumumo N. 470 </option>
<option>Escola Primária Doroma Mphawe N. 840 </option>
<option>Escola Primária Fazenda Mumba N. 1595 </option>
<option>Escola Primária Heco N. 1025 </option>
<option>Escola Primária Hole N. 247 </option>
<option>Escola Primária Luhengue N. 204 </option>
<option>Escola Primária Manhingue N. 177 </option>
<option>Escola Primária Maquende N. 250 </option>
<option>Escola Primária Massondjo Hepe N. 178 </option>
<option>Escola Primária Maviuco N. 845 </option>
<option>Escola Primária Mayala N. 175</option>
<option>Escola Primária Muloi Ii N. 173 </option>
<option>Escola Primária Mumba N. 770 </option>
<option>Escola Primária Mundjalandjala N. 1028 </option>
<option>Escola Primária Mussandji N. 191 </option>
<option>Escola Primária Mussindja N. 212 </option>
<option>Escola Primária N. 100 </option>
<option>Escola Primária N. 237 </option>
<option>Escola Primária Quicuco N. 253 </option>
<option>Escola Primária Socobal Nende N. 999 </option>
<option>Escola Primária Tchipangula N. 213 </option>
<option>Escola Primária Tchipupa N. 851 </option>
<option>Escola Primária Tchitanda N. 211 </option>
<option>Escola Primária Tchitaqui Baixo N. 794 </option>
<option>Escola Primária Tchivulo Jongo N. 853 </option>
<option>Escola Primária Tembelo N. 887 </option>
<option>Escola Primária Ukali Kumbambi N. 188 </option>
<option>Escola Primária Ukali Mandjatata N. 226 </option>
<option>Escola Primária Vicala N. 910 </option>
<option>Escola Primária Vinama N. 201 </option>
<option>Escola Primária Vombo N. 240 </option>
<option>Escola Primária Yala Cussesse N. 1533 </option>
<option>Escola Primária Yendje N. 259 </option>
<option>Escola Primária Yundi N. 866 </option>
<option>Instituto Técnico De Pecuária De Quilengues N. 1678</option>
<option>Liceu N. 859 - Quilengues</option>
