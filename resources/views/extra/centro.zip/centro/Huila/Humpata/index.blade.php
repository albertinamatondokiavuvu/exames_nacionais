<option>Colégio Da Humpata N. 698</option>
<option>Complexo Escolar Ao Campo N º 184</option>
<option>Escola - Ao Campo Ensino Primário - Humpata</option>
<option>Escola - Associação 11 De Novembro - Humpata</option>
<option>Escola - Augusto Ngangula N. 65 </option>
<option>Escola - Bata-Bata - Humpata</option>
<option>Escola - Calumue - Humpata</option>
<option>Escola - Heva - Humpata</option>
<option>Escola - Hombo - Humpata</option>
<option>Escola - I Ciclo Caholo - Humpata</option>
<option>Escola - Jamba Ii - Humpata</option>
<option>Escola - Kaholo Ensino Primário - Humpata</option>
<option>Escola - Kandja - Humpata</option>
<option>Escola - Mulenga - Humpata</option>
<option>Escola - Mundindi - Humpata</option>
<option>Escola - Mungolo - Humpata</option>
<option>Escola - Ndjambi - Humpata</option>
<option>Escola - Ndola - Humpata</option>
<option>Escola - Ndundualumbe - Humpata</option>
<option>Escola - Onthite - Humpata</option>
<option>Escola - Palanca I - Humpata</option>
<option>Escola - Palanca Ii - Humpata</option>
<option>Escola - Tchalawa - Humpata</option>
<option>Escola - Tchihingui - Humpata</option>
<option>Escola - Tchihonguelo - Humpata</option>
<option>Escola - Tchindingui - Humpata</option>
<option>Escola Primária Alto Bimbi N. 27</option>
<option>Escola Primária Comandante Cow Boy N. 221 </option>
<option>Escola Primária Estação Esperimental Agricola N. 351 </option>
<option>Escola Primária Estação Zootecnicas N. 222</option>
<option>Escola Primária Hanga Anexa N. 1787</option>
<option>Escola Primária Hongo - Américo Boa Vida - N. 1110</option>
<option>Escola Primária Kangolo N. 1102</option>
<option>Escola Primária Kapandeio N. 229</option>
<option>Escola Primária Leba N. 21</option>
<option>Escola Primária Mbuto N. 1111</option>
<option>Escola Primária Ntamana N. 697</option>
<option>Escola Primária Onkuluvala N. 466</option>
<option>Escola Primária Projecto Nossa Terra N. 691</option>
<option>Escola Primária Ruival N. 692</option>
<option>Escola Primária Taca N. 1161</option>
<option>Escola Primária Tchangalala N. 693</option>
<option>Escola Primária Tchihanhina N. 695</option>
<option>Escola Primária Tchimbandi N. 465</option>
<option>Escola Primária Tchimbulo N. 777</option>
<option>Escola Primária Zeca N. 95</option>
<option>Instituto Politécnico Da Humpata</option>
<option>Liceu N. 700 - Humpata</option>

