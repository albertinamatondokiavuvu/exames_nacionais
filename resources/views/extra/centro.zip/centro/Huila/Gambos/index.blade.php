<option>Colégio - Dr.Antonio A. Neto N. 1783 </option>
<option>Escola Do Ensino Primário - Chiange Velho Nº 890 - Gambos</option>
<option>Escola Do Ensino Primário - Eongo Nº 573 - Gambos</option>
<option>Escola Do Ensino Primário - Fazenda Tyibolelo Nº 1785 - Gambos</option>
<option>Escola Do Ensino Primário - Kaila Nº 192 - Gambos</option>
<option>Escola Do Ensino Primário - Kambanguvo Nº 902 - Gambos</option>
<option>Escola Do Ensino Primário - Kamphanda Nº 920 - Gambos</option>
<option>Escola Do Ensino Primário - Kapeleti Nº 896 - Gambos</option>
<option>Escola Do Ensino Primário - Katoho Nº 1020 - Gambos</option>
<option>Escola Do Ensino Primário - Kauvi Nº 1704 - Gambos</option>
<option>Escola Do Ensino Primário - Liamulola Nº 1727 - Gambos</option>
<option>Escola Do Ensino Primário - Luheke Nº 1134 - Gambos</option>
<option>Escola Do Ensino Primário - Luvota Nº 826 - Gambos</option>
<option>Escola Do Ensino Primário - Lwongo Nº 900 - Gambos</option>
<option>Escola Do Ensino Primário - Makaka Nº 912 - Gambos</option>
<option>Escola Do Ensino Primário - Maova Nº 1128  - Gambos</option>
<option>Escola Do Ensino Primário - Mapupu Nº 450 - Gambos</option>
<option>Escola Do Ensino Primário - Mulutuvo Nº 1107 - Gambos</option>
<option>Escola Do Ensino Primário - Munailogo Nº 1133 - Gambos</option>
<option>Escola Do Ensino Primário - Mutwe Wonbungo Nº 36 - Gambos</option>
<option>Escola Do Ensino Primário - Ndjehi Nº 894 - Gambos</option>
<option>Escola Do Ensino Primário - Nkhanbuka Nº 1195 - Gambos</option>
<option>Escola Do Ensino Primário - Panguelo Nº 1023 - Gambos</option>
<option>Escola Do Ensino Primário - Rei Katyituka Nº 916 - Gambos</option>
<option>Escola Do Ensino Primário - Taka Nº 874 - Gambos</option>
<option>Escola Do Ensino Primário - Tchibolelo Vale Nº 39 - Gambos</option>
<option>Escola Do Ensino Primário - Tyatena Nº 1789 - Gambos</option>
<option>Escola Do Ensino Primário - Tyicalanhana Nº 1131 - Gambos</option>
<option>Escola Do Ensino Primário - Tyikonkho - Yandja Nº 1136 - Gambos</option>
<option>Escola Do Ensino Primário - Tyikuli Nº 891 - Gambos</option>
<option>Escola Do Ensino Primário - Tyindjangui Nº 37 - Gambos</option>
<option>Escola Do Ensino Primário - Tyipunbwandyjila Nº 917 - Gambos</option>
<option>Escola Do Ensino Primário - Vangula Nº 899 - Gambos</option>
<option>Escola Do Ensino Primário - Vihaendwa Nº 1130 - Gambos</option>
<option>Escola Do Ensino Primário - Viriambundo Nº 312 - Gambos</option>
<option>Escola Do Ensino Primário - Vitengua Nº 901 - Gambos</option>
<option>Escola Do I Ciclo Da Chibemba - Nº 925  - Gambos</option>
<option>Escola Primária - Dongue N. 311 </option>
<option>Escola Primária - Embala N. 1137 </option>
<option>Escola Primária - Enphangui N. 1139 - Gambos</option>
<option>Escola Primária - Kafela N. 1108 - Gambos</option>
<option>Escola Primária - Kaku N. 1198 </option>
<option>Escola Primária - Kamussissi N. 1127 - Gambos</option>
<option>Escola Primária - Lwano N. 1196 - Gambos</option>
<option>Escola Primária - Maria Mambo Café N. 195 </option>
<option>Escola Primária - Mimbonde N. 1197 </option>
<option>Escola Primária - Muntyiaulwa N. 1129 </option>
<option>Escola Primária - Muti Wovakai N. 906 - Gambos</option>
<option>Escola Primária - Nguelengue N. 897 - Gambos</option>
<option>Escola Primária - Nhamphala N. 904 - Gambos</option>
<option>Escola Primária - Nomphawe N. 1193 - Gambos</option>
<option>Escola Primária - Nondjelo N. 1022 - Gambos</option>
<option>Escola Primária - Nonkhonkho N. 1191 - Gambos</option>
<option>Escola Primária - Omphapa N. 1021 - Gambos </option>
<option>Escola Primária - Pokolo N. 196 - Gambos</option>
<option>Escola Primária - Rio D´Areia N. 707 </option>
<option>Escola Primária - Tapu N. 1138 - Gambos</option>
<option>Escola Primária - Tumba N. 895 - Gambos</option>
<option>Escola Primária - Tunda N. 1784 - Gambos</option>
<option>Escola Primária - Tyiku N. 1026 - Gambos</option>
<option>Escola Primária - Tyipumbulo N. 1105 - Gambos</option>
<option>Escola Primária - Viheke N. 893 - Gambos</option>
<option>Escola Primária N. 152 </option>
<option>Liceu N. 918 - Gambos</option>
