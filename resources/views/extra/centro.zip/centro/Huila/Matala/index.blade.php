<option>Colégio 14 De Abril N. 1272 </option>
<option>Colégio 17 De Setembro N. 326 </option>
<option>Colégio 27 De Agosto N. 959 </option>
<option>Colégio 4 De Abril N. 964 </option>
<option>Colégio Do Mulondo N. 1329 </option>
<option>Colégio Imaculada Conceição N. 623 </option>
<option>Colégio Joaquim Kauvi N. 960 </option>
<option>Colégio Mukula Mphingue N. 76</option> 
<option>Colégio N. 915 </option>
<option>Complexo Escolar Escola 17 De Dezembro N. 871</option> 
<option>Complexo Escolar Muvale N. 872 </option>
<option>Escola Do Ensino Primário Bembele Camucuio Nº 1103 - Matala</option>
<option>Escola Do Ensino Primário Bember Katchope  Nº 275 - Matala</option>
<option>Escola Do Ensino Primário Calumbo Nº 861 - Matala</option>
<option>Escola Do Ensino Primário Chela  Nº 1080 - Matala</option>
<option>Escola Do Ensino Primário Chitumba  Nº 302 - Matala</option>
<option>Escola Do Ensino Primário Fufu Ii Nº 1271 - Matala</option>
<option>Escola Do Ensino Primário Kancondja Nº 892 - Matala</option>
<option>Escola Do Ensino Primário Kandjanguiti I Nº 1090 - Matala</option>
<option>Escola Do Ensino Primário Kandjanguiti Ii Nº 1537 - Matala</option>
<option>Escola Do Ensino Primário Kanongundo Nº 274 - Matala</option>
<option>Escola Do Ensino Primário Kapunda Nº 436 - Matala</option>
<option>Escola Do Ensino Primário Katchuku Nº 1087 - Matala</option>
<option>Escola Do Ensino Primário Londjili  Nº 1084 - Matala</option>
<option>Escola Do Ensino Primário Muholo Nº 169 - Matala</option>
<option>Escola Do Ensino Primário Mundjamba Nº 1363 - Matala</option>
<option>Escola Do Ensino Primário Ndjandjo Nº 1094 - Matala</option>
<option>Escola Do Ensino Primário Ndjevei Nº 1724 - Matala</option>
<option>Escola Do Ensino Primário Nkhalapeke Nº 162 - Matala</option>
<option>Escola Do Ensino Primário Nondau Nº 862 - Matala</option>
<option>Escola Do Ensino Primário Nonkhuvi Nº 1086 - Matala</option>
<option>Escola Do Ensino Primário Tchicuele Nº 157 - Matala</option>
<option>Escola Do Ensino Primário Tchimbango Tchiwe Nº 139 - Matala</option>
<option>Escola Do Ensino Primário Tchiquelo  Nº 290 - Matala</option>
<option>Escola Do Ensino Primário Tchivava  Nº 1091 - Matala</option>
<option>Escola Do Ensino Primário Tchiwe Munhandi Nº 281 - Matala</option>
<option>Escola Do Ensino Primário Viteta  Nº 171 - Matala</option>
<option>Escola Primária 1º De Maio N. 435 </option>
<option>Escola Primária Alssa N. 1327 </option>
<option>Escola Primária Alto Muquequete - Km 7 N. 1262 </option>
<option>Escola Primária Bembele Grande N. 168 </option>
<option>Escola Primária Benber Ngala N. 163 </option>
<option>Escola Primária Cahululu N. 1077 </option>
<option>Escola Primária Calheta Nova N. 1266 </option>
<option>Escola Primária Calombinga Ii N. 1267 </option>
<option>Escola Primária Chipeio N. 681 </option>
<option>Escola Primária Cte Cow - Boy N. 1268 </option>
<option>Escola Primária Cuvelai Sede N. 164 </option>
<option>Escola Primária Escola N. 210 N. 210 </option>
<option>Escola Primária Escola N. 430 N. 430 </option>
<option>Escola Primária Freixiel N. 133 </option>
<option>Escola Primária Fufu I N. 1075 </option>
<option>Escola Primária Kahongo Ii N. 319 </option>
<option>Escola Primária Kalombinga N. 150 </option>
<option>Escola Primária Kamucua N. 1079 </option>
<option>Escola Primária Kamulemba N. 144 </option>
<option>Escola Primária Kamunhandi N. 462 </option>
<option>Escola Primária Kandjanguiti Iii N. 1280 </option>
<option>Escola Primária Kanguengue N. 1092 </option>
<option>Escola Primária Kapessela I N. 145 </option>
<option>Escola Primária Kassoco N. 1181 </option>
<option>Escola Primária Kavava N. 1818 </option>
<option>Escola Primária Kilamba N. 1076 </option>
<option>Escola Primária Lumanha N. 322 </option>
<option>Escola Primária Maculungungo N. 142 </option>
<option>Escola Primária Meva - Yela N. 1089 </option>
<option>Escola Primária Micosse Sede N. 136 </option>
<option>Escola Primária Mucolo N. 140 </option>
<option>Escola Primária Mukua N. 165 </option>
<option>Escola Primária Muquequete I N. 138 </option>
<option>Escola Primária Muquequete Iii N. 1263</option> 
<option>Escola Primária N. 120 </option>
<option>Escola Primária N. 1205 </option>
<option>Escola Primária N. 94 </option>
<option>Escola Primária Ndjevei Ii N. 320 </option>
<option>Escola Primária Nguendje Sede N. 154 </option>
<option>Escola Primária Produção E Luta N. 282 </option>
<option>Escola Primária Projeto Melica N. 1563 </option>
<option>Escola Primária Quiteve N. 1082 </option>
<option>Escola Primária Somafel N. 1078 </option>
<option>Escola Primária Tchinhanha N. 141 </option>
<option>Escola Primária Tchipalanguela N. 148 </option>
<option>Escola Primária Tchipopia N. 151 </option>
<option>Escola Primária Tchiwacusse N. 143 </option>
<option>Escola Primária Vindondi N. 736 </option>
<option>Escola Primária Vissaca N. 860 </option>
<option>Liceu N. 1068 - Matala</option>
<option>Magistério N. 1843 Da Matala </option>





