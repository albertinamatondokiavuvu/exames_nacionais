<option>Colégio 22 De Novembro N. 1149</option> 
<option>Colégio Waba N. 1185</option>
<option>Complexo Escolar 4 De Janeiro N. 1220</option> 
<option>Complexo Escolar Antonio Isaias N. 1027</option>
<option>Complexo Escolar Canassi N. 1281</option>
<option>Complexo Escolar Canduco N. 1632 </option>
<option>Complexo Escolar Canduco N. 1632 </option>
<option>Complexo Escolar Mussica N. 1344 </option>
<option>Complexo Escolar N. 183 </option>
<option>Complexo Escolar N. 935 </option>
<option>Complexo Escolar Padre Ernesto Leconth N. 1290</option> 
<option>Complexo Escolar Talamangolo N. 1050 </option>
<option>Escola Do Ensino Primário  Nº 433 - Caconda</option>
<option>Escola Do Ensino Primário  Nº 9 - Caconda</option>
<option>Escola Do Ensino Primário 11 De Novembro Nº 876 - Caconda</option>
<option>Escola Do Ensino Primário Boa Vista Nº 1232 - Caconda</option>
<option>Escola Do Ensino Primário Calei Nº 1243 - Caconda</option>
<option>Escola Do Ensino Primário Calonamba Nº 1034 - Caconda</option>
<option>Escola Do Ensino Primário Calunga  Nº 923 - Caconda</option>
<option>Escola Do Ensino Primário Cambungue  Nº 1282 - Caconda</option>
<option>Escola Do Ensino Primário Canassi Embala Nº 1210 - Caconda</option>
<option>Escola Do Ensino Primário Canata Nº 1042 - Caconda</option>
<option>Escola Do Ensino Primário Catombela Nº 930 - Caconda</option>
<option>Escola Do Ensino Primário Chilanda Nº 1200 - Caconda</option>
<option>Escola Do Ensino Primário Chinhama Nº 1114 - Caconda</option>
<option>Escola Do Ensino Primário Chipembe  Nº 937 - Caconda</option>
<option>Escola Do Ensino Primário Chitupia Nº 1354 - Caconda</option>
<option>Escola Do Ensino Primário Gunga Nº 1225 - Caconda</option>
<option>Escola Do Ensino Primário Sahando  Nº 15 - Caconda</option>
<option>Escola Do Ensino Primário Tapala Nº 1358 - Caconda</option>
<option>Escola Do I Ciclo Do Ensino Primário Nova Moção  Nº 947 - Caconda</option>
<option>Escola Primária 14 De Abril N. 1790 </option>
<option>Escola Primária Alto Kuinavo N. 1135 </option>
<option>Escola Primária Alto Rural N. 957</option>
<option>Escola Primária Baixo Vionga N. 1178</option>
<option>Escola Primária Bandeira N. 1300 </option>
<option>Escola Primária Bange N. 952</option>
<option>Escola Primária Bembua N. 1806 </option>
<option>Escola Primária Bissapa N. 1183 </option>
<option>Escola Primária Cacalo N. 1055 </option>
<option>Escola Primária Caissome N. 1115 </option>
<option>Escola Primária Calete N. 1153 </option>
<option>Escola Primária Calombo N. 1346 </option>
<option>Escola Primária Calossuva N. 1631</option>
<option>Escola Primária Calovombolo N. 1221</option>
<option>Escola Primária Calunganga N. 1234 </option>
<option>Escola Primária Calungo N. 1211 </option>
<option>Escola Primária Camassa N. 1157</option>
<option>Escola Primária Camungondo N. 1179 </option>
<option>Escola Primária Canjoão N. 1208</option>
<option>Escola Primária Caringo N. 1625 </option>
<option>Escola Primária Cassenje I N. 1341 </option>
<option>Escola Primária Casseque Dondi N. 1166 </option>
<option>Escola Primária Cassoco N. 1143</option>
<option>Escola Primária Cavava N. 1047 </option>
<option>Escola Primária Chicambi N. 1151 </option>
<option>Escola Primária Chinjenje N. 965 </option>
<option>Escola Primária Chissende N. 1351 </option>
<option>Escola Primária Comandante Dangereux N. 885</option> 
<option>Escola Primária Cue Ii N. 1160 </option>
<option>Escola Primária Cupacassa N. 1176 </option>
<option>Escola Primária Cupepela N. 1175</option>
<option>Escola Primária Dr. Antonio A. Neto N. 881</option> 
<option>Escola Primária Dumbo N. 1173 </option>
<option>Escola Primária Elias Luciano N. 1109 </option>
<option>Escola Primária Hila N. 1204</option>
<option>Escola Primária Holongui N. 1162 </option>
<option>Escola Primária Jamba - Ya - Mina N. 1237 </option>
<option>Escola Primária Kaluna N. 1158</option>
<option>Escola Primária Longuri N. 1287 </option>
<option>Escola Primária Lossili N. 1144 </option>
<option>Escola Primária Lossolo N. 233</option>
<option>Escola Primária Mis.Católica S. Pedro N. 1235</option>
<option>Escola Primária Mundinda N. 1218 </option>
<option>Escola Primária Munguila N. 1194 </option>
<option>Escola Primária N. 38 </option>
<option>Escola Primária Nacandumbo N. 1229</option> 
<option>Escola Primária Palanca I N. 1348</option>
<option>Escola Primária Palanga Ii N. 1356 </option>
<option>Escola Primária Santiago Ii N. 1167</option>
<option>Escola Primária São José De Clunhi N. 1357 </option>
<option>Escola Primária São Paulo N. 1145 </option>
<option>Escola Primária São Pedro N. 1148 </option>
<option>Escola Primária Tchiweca N. 945 </option>
<option>Escola Primária Yumbi N. 1177 </option>
<option>Liceu N. 1152 - Caconda</option>


