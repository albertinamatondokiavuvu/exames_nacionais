<option>Colégio 1º De Dezembro N. 871</option>
<option>Colégio 27 De <option>Colégio N. 110</option>
<option>Colégio Cfm N. 124</option>
<option>Colégio Hotelaria E Turismo N. 121</option>
<option>Colégio Mandume N. 1298</option>
<option>Colégio N. 1689 - Nossa Sra De F. Nanguluve</option>
<option>Colégio N. 1701 - Bakita</option>
<option>Colégio N. 1730 - Sede</option>
<option>Colégio N. 1732 - Namphanda</option>
<option>Colégio N. 176 - 10 De Dezembro</option>
<option>Colégio N. 1771 - Nossa Sra F.Lalula</option>
<option>Colégio N. 1773 - Iesa</option>
<option>Colégio N. 1774 - Iepa</option>
<option>Colégio N. 1775 - Ieca</option>
<option>Colégio N. 1777 - Est.Da Alva</option>
<option>Colégio N. 1778 - 7º Dia</option>
<option>Colégio N. 1830 - Estrela - Huila</option>
<option>Colégio N. 256</option>
<option>Colégio N. 712 - Artes E Oficio</option>
<option>Colégio N. 75</option>
<option>Colégio N. 805 Vila Paula</option>
<option>Colégio N. 811 - 1º De Maio</option>
<option>Colégio N. 852 - 11 De Novembro</option>
<option>Colégio N. 88 - 16 De Junho</option>
<option>Colégio N. 90 Da Missão Católica </option>
<option>Colégio N. 990 - Anxa 2</option>
<option>Colégio Núcleo De D. Fisicos N. 1772</option>
<option>Complexo Esc. Agrario Do Tchivinguiro</option>
<option>Complexo Escolar Baptista N. 458</option>
<option>Complexo Escolar Do Ensino Especial N. 797</option>
<option>Complexo Escolar N. 1359 - Nazario Vital</option>
<option>Complexo Escolar N. 16</option>
<option>Complexo Escolar N. 1728 - 4 De Abril</option>
<option>Complexo Escolar N. 1776 - Dom Samuel</option>
<option>Complexo Escolar N. 1828 - Eyva</option>
<option>Complexo Escolar N. 187</option>
<option>Complexo Escolar N. 458 - Cba2</option>
<option>Complexo Escolar N. 48 Ida</option>
<option>Complexo Escolar N. 706 - 1 De Junho - Adra</option>
<option>Complexo Escolar Sos N. 18</option>
<option>Delegacao Prov.Educ./Inpeccao Escolar-Huila</option>
<option>Dir. Prov. Alfabetizacao Da Huila</option>
<option>Dir.Prov.Educ.Huila-Conc.Pub.2007-Ins.Jan08</option>
<option>Dir.Prov.Educacao Huila-Conc.Pub./06-Ins.2007</option>
<option>Direc. P. Da Educação, C. T. Da Huila</option>
<option>Escola Do Ii Ciclo Do Ensino Secundário Do Lubango</option>
<option>Escola Nº 1012, Nongiwe</option>
<option>Escola Nº 1060, Tchitunda</option>
<option>Escola Nº 1261, Tchombulo</option>
<option>Escola Nº 1325, Mankipa</option>
<option>Escola Nº 1722, Tete</option>
<option>Escola Nº 261, Canhongolo</option>
<option>Escola Nº 31,Tunda</option>
<option>Escola Nº 32 , Luyovo</option>
<option>Escola Nº 33 , Rio Nangombe</option>
<option>Escola Nº 914, Nompaka Ii</option>
<option>Escola Nº1003,Hinhinhiki</option>
<option>Escola Nº103,Mateta</option>
<option>Escola Nº106, Lagoa</option>
<option>Escola Nº1102, Cangolo Mankipa</option>
<option>Escola Nº111, Chacala</option>
<option>Escola Nº1116, Bio</option>
<option>Escola Nº1117, Camihombo</option>
<option>Escola Nº1118,Tete</option>
<option>Escola Nº112 ,Hima</option>
<option>Escola Nº1252, Ngolo</option>
<option>Escola Nº1253, Namphaka</option>
<option>Escola Nº1254, Kewa</option>
<option>Escola Nº126, Nohenda</option>
<option>Escola Nº1321,Ndimba</option>
<option>Escola Nº146, Mbahe</option>
<option>Escola Nº149, Kamongua</option>
<option>Escola Nº156, Sede</option>
<option>Escola Nº159, Tungue</option>
<option>Escola Nº161, Honguelo</option>
<option>Escola Nº17</option>
<option>Escola Nº170, Unene</option>
<option>Escola Nº1779, Mbango</option>
<option>Escola Nº1780, Embala</option>
<option>Escola Nº1781, Maquelo</option>
<option>Escola Nº1787, Hanga Ii</option>
<option>Escola Nº1829, Nothe</option>
<option>Escola Nº187</option>
<option>Escola Nº197, Kwahamba</option>
<option>Escola Nº216, Camuenha</option>
<option>Escola Nº230, Tchicanda</option>
<option>Escola Nº262, Kate</option>
<option>Escola Nº268 , Sede</option>
<option>Escola Nº34 , Maputo</option>
<option>Escola Nº35 , Sede</option>
<option>Escola Nº43, Chengue</option>
<option>Escola Nº50</option>
<option>Escola Nº504</option>
<option>Escola Nº52, Hanga I</option>
<option>Escola Nº66, Toco</option>
<option>Escola Nº720, Haya</option>
<option>Escola Nº753, Tchilambo</option>
<option>Escola Nº764 , Mupanda</option>
<option>Escola Nº769,Bandua</option>
<option>Escola Nº802,Mayala</option>
<option>Escola Nº803, Mumue</option>
<option>Escola Nº809,Tchimbunda</option>
<option>Escola Nº829, Tchikala</option>
<option>Escola Nº873, Tchaliponda</option>
<option>Escola Nº89, Chanja</option>
<option>Escola Nº903,Bundu</option>
<option>Escola Nº905, Nambungula</option>
<option>Escola Nº919, Cambalombo</option>
<option>Escola Primária Centro Chimoma N. 1447</option> 
<option>Escola Primária N. 01 - Cangolo</option>
<option>Escola Primária N. 04 - Missao Femenina</option>
<option>Escola Primária N. 08</option>
<option>Escola Primária N. 10</option>
<option>Escola Primária N. 1002 - Capeque</option>
<option>Escola Primária N. 1007 </option>
<option>Escola Primária N. 1009 - Mavanda</option>
<option>Escola Primária N. 1013 - Muquilengue</option>
<option>Escola Primária N. 105 - Vikendji</option>
<option>Escola Primária N. 107 - Namphanda</option>
<option>Escola Primária N. 108 - Muala</option>
<option>Escola Primária N. 109 - Conjenje</option>
<option>Escola Primária N. 11</option>
<option>Escola Primária N. 113 </option>
<option>Escola Primária N. 114 - 14 De Abril</option>
<option>Escola Primária N. 115 - Ché - Chém</option>
<option>Escola Primária N. 116 - Imaculada Conceição</option>
<option>Escola Primária N. 117 - Mucuio</option>
<option>Escola Primária N. 1199</option>
<option>Escola Primária N. 127 - Munhino</option>
<option>Escola Primária N. 13</option>
<option>Escola Primária N. 1308 - La Salette</option>
<option>Escola Primária N. 14 - Mbanda</option>
<option>Escola Primária N. 147 - Tapi</option>
<option>Escola Primária N. 158 - Mamboto</option>
<option>Escola Primária N. 1599 - 371 B</option>
<option>Escola Primária N. 160 - Tchimucua</option>
<option>Escola Primária N. 166 - Tchikindo</option>
<option>Escola Primária N. 1723 - Muhaha</option>
<option>Escola Primária N. 1731 - Nossa Sra Assunção</option>
<option>Escola Primária N. 1792 - Mama Muxima</option>
<option>Escola Primária N. 200</option>
<option>Escola Primária N. 208 - Tchimpaka</option>
<option>Escola Primária N. 215</option>
<option>Escola Primária N. 219 - Muticula</option>
<option>Escola Primária N. 220 - Caputo</option>
<option>Escola Primária N. 24 - 2 De Março</option>
<option>Escola Primária N. 255 - Midjambi</option>
<option>Escola Primária N. 26 Tchavola</option>
<option>Escola Primária N. 29</option>
<option>Escola Primária N. 292</option>
<option>Escola Primária N. 3 - Padre C. Esterman </option> 
<option>Escola Primária N. 340 </option>
<option>Escola Primária N. 369 </option>
<option>Escola Primária N. 371</option>
<option>Escola Primária N. 400 </option>
<option>Escola Primária N. 41 - Figueira - Arimba</option>
<option>Escola Primária N. 418 </option>
<option>Escola Primária N. 428 </option>
<option>Escola Primária N. 505</option>
<option>Escola Primária N. 51</option>
<option>Escola Primária N. 520 - Ntuvili</option>
<option>Escola Primária N. 53</option>
<option>Escola Primária N. 55</option>
<option>Escola Primária N. 59</option>
<option>Escola Primária N. 60</option>
<option>Escola Primária N. 61</option>
<option>Escola Primária N. 62</option>
<option>Escola Primária N. 63</option>
<option>Escola Primária N. 638 - Tchipalakasssa</option>
<option>Escola Primária N. 64 - Tchilevo</option>
<option>Escola Primária N. 670 - 19 De Janeiro</option>
<option>Escola Primária N. 705 8 De Março</option>
<option>Escola Primária N. 717 - Nombongo</option>
<option>Escola Primária N. 742 - Mukanka</option>
<option>Escola Primária N. 752</option>
<option>Escola Primária N. 771 - Hoje - Ya - Henda</option>
<option>Escola Primária N. 782 - Katala</option>
<option>Escola Primária N. 787 - Vihango</option>
<option>Escola Primária N. 792 - Km 14</option>
<option>Escola Primária N. 798 - Caculuvale</option>
<option>Escola Primária N. 801 - Ntenda</option>
<option>Escola Primária N. 806 - Muholi</option>
<option>Escola Primária N. 814 - Cacua</option>
<option>Escola Primária N. 877 - Mitchole</option>
<option>Escola Primária N. 879 - Poliares</option>
<option>Escola Primária N. 98</option>
<option>Instituto Politecnico N. 131 - Lubango</option>
<option>Instituto Técnico De Formação De Saúde N. 1831 - Lubango</option>
<option>Liceu De Antena Da 5 Região</option>
<option>Liceu N. 134 - Nambambi</option>
<option>Liceu N. 257 Da Arimba - Lubango</option>
<option>Liceu N. 792 - Lubango</option>
<option>Magistério N. 1099 De Ciências Religiosas De Angola - Lubango</option>
<option>Magistério N. 135 Comandante Liberdade - Lubango</option>
<option>Magistério N. 137 Do Nambambi - Lubango</option>
<option>Magistério N. 181 Da Huíla - Lubango</option>
<option>Med /Deleg.Municipal De Chibia /Huila</option>
<option>Med Deeleg.Municipal De Quipungo /Huila</option>
<option>Med Deleg.Munic.Da Humpata</option>
<option>Med Deleg.Munic.Da Jamba /Huila</option>
<option>Med Deleg.Munic.Da Matala/Huila</option>
<option>Med Deleg.Munic.De Caconda/Huila</option>
<option>Med Deleg.Municipal De Cacula /Huila</option>
<option>Med Deleg.Municipal De Chicomba /Huila</option>
<option>Med Deleg.Municipal De Gambos/Huila</option>
<option>Med Deleg.Municipal De Quilengues /Huila</option>
<option>Med.-Complexo Escolar 14 De Abril (Lubango)</option>
<option>Med.-D.P.E. Centro Prov. De Formac. Permanent</option>
<option>Med.-Deleg. Prov. Da Educacao Da Huila</option>
<option>Med.-Dmel(Escola Do 1 Nivel Ns 16) Huila</option>
<option>Med.-Dmel(Escola Do 1 Nivel Ns 187) Huila</option>
<option>Med.-Dmel(Escola Do 1 Nivel Ns 50) Huila</option>
<option>Med.-Dmel(Escola Do 1 Nivel Ns 99) Huila</option>
<option>Med.-Secc. Mun. De Educ. Do Kuvango</option>
<option>Med.-Seccao Municipal Do Lubango/Huila</option>
<option>Med/Deleg.Munic.De Chipindo</option>
<option>Med/Deleg.Munic.De Kaluquembe Da Huila</option>
<option>Med-Coord. Esc. Com. Da Arimba - Huila</option>
<option>Med-Coord. Escolar Da Com. Da Huila</option>
<option>Med-Coord. Escolar Da Quilemba</option>
<option>Med-Coord. Escolar Do Hoque</option>
<option>Med-D.M.E.L(Centro Arquidiocesano De P. Huila)</option>
<option>Med-Dmel(Escola Do 1 Nivel Ns 12) Huila</option>
<option>Med-Dmel(Escola Do 1 Nivel Ns 2) Huila</option>
<option>Med-Dmel(Escola Do 1 Nivel Ns 5) Huila</option>
<option>Med-Escola Do I Nivel Nr. 193 - Huila</option>
<option>Med-Escola Do I Nivel Nr. 194 - Huila</option>
<option>Med-Escola Do I Nivel Nr. 370</option>
<option>Repartição Municipal De Educação Do Lubango</option>
<option>Seccao Mun. Alfabetizacao Da Chicomba</option>
<option>Seccao Mun. Alfabetizacao Da Humpata</option>
<option>Seccao Mun. Alfabetizacao Da Jamba</option>
<option>Seccao Mun. Alfabetizacao Da Kakula</option>
<option>Seccao Mun. Alfabetizacao Da Matala</option>
<option>Seccao Mun. Alfabetizacao De Chipindo</option>
<option>Seccao Mun. Alfabetizacao Do Kalukembe</option>
<option>Seccao Mun. Alfabetizacao Do Kilengues</option>
<option>Seccao Mun. Alfabetizacao Dos Gambos</option>
<option>Seccao Mun. De Alfabetizacao Da Chibia</option>
<option>Seccao Mun. De Alfabetizacao Do Kipungo</option>
<option>Seccao Mun. De Alfabetizacao Do Kuvango</option>
