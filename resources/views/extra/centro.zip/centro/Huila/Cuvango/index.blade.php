<option>Colégio Lar N. 1485 </option>
<option>Escola Do Ensino Primário  Nº 1019 - Cuvango</option>
<option>Escola Do Ensino Primário Boaventura Nº 1488 - Cuvango</option>
<option>Escola Do Ensino Primário Capengo Nº 1539 - Cuvango</option>
<option>Escola Do Ensino Primário Hungulo Nº 1523 - Cuvango</option>
<option>Escola Do Ensino Primário Indungo Kanangue Nº 1743 - Cuvango</option>
<option>Escola Do Ensino Primário Kalemba Nº 1492 - Cuvango</option>
<option>Escola Do Ensino Primário Kalundungo-Mapamba Nº 1524 - Cuvango</option>
<option>Escola Do Ensino Primário Kandumba Nº 1759 - Cuvango</option>
<option>Escola Do Ensino Primário Kandumbo Nº 1468 - Cuvango</option>
<option>Escola Do Ensino Primário Kangombe Nº 1490 - Cuvango</option>
<option>Escola Do Ensino Primário Kassangui Nº 1489 - Cuvango</option>
<option>Escola Do Ensino Primário Kassesse Nº 1606 - Cuvango</option>
<option>Escola Do Ensino Primário Katoco Nº 763 - Cuvango</option>
<option>Escola Do Ensino Primário Kavongue - I Nº 1496 - Cuvango</option>
<option>Escola Do Ensino Primário Kavongue - Ii Nº 1497 - Cuvango</option>
<option>Escola Do Ensino Primário Kayangula Nº 1560 - Cuvango</option>
<option>Escola Do Ensino Primário Kayoco  Nº 767 - Cuvango</option>
<option>Escola Do Ensino Primário Konkwe Nº 1745 - Cuvango</option>
<option>Escola Do Ensino Primário Liapeka-I Nº 1515 - Cuvango</option>
<option>Escola Do Ensino Primário Liapeka-Ii Nº 1516 - Cuvango</option>
<option>Escola Do Ensino Primário Linduva Nº 1592 - Cuvango</option>
<option>Escola Do Ensino Primário Linhemo Nº 1544 - Cuvango</option>
<option>Escola Do Ensino Primário Macoco Nº 1588 - Cuvango</option>
<option>Escola Do Ensino Primário Macova Nº 1535 - Cuvango</option>
<option>Escola Do Ensino Primário Malova Nº 1604 - Cuvango</option>
<option>Escola Do Ensino Primário Massali Nº 1518 - Cuvango</option>
<option>Escola Do Ensino Primário Mgunda-Vundjanga Nº 1521 - Cuvango</option>
<option>Escola Do Ensino Primário Mihimpo Nº 1618 - Cuvango</option>
<option>Escola Do Ensino Primário Mingomba Nº 1520 - Cuvango</option>
<option>Escola Do Ensino Primário Missão  Nº 132 - Cuvango</option>
<option>Escola Do Ensino Primário Mundjindo Nº 1547 - Cuvango</option>
<option>Escola Do Ensino Primário Ndumba-Ya-Ngonga Nº 1612 - Cuvango</option>
<option>Escola Do Ensino Primário Nginga-Mbandi  Nº 119 - Cuvango</option>
<option>Escola Do Ensino Primário Ngueve-Tyivuluila Nº 1522 - Cuvango</option>
<option>Escola Do Ensino Primário Ngumbe-Kazeta Nº 1504 - Cuvango</option>
<option>Escola Do Ensino Primário Senga Nº 1744 - Cuvango</option>
<option>Escola Do Ensino Primário Tchitundo Nº 1480 - Cuvango</option>
<option>Escola Do Ensino Primário Tyihongo - Kativa Nº 1587 - Cuvango</option>
<option>Escola Do Ensino Primário Tyihungo I Nº 1478 - Cuvango</option>
<option>Escola Do Ensino Primário Tyimbundo-Grande Nº 1505 - Cuvango</option>
<option>Escola Do Ensino Primário Tyimbundo-Pequeno Nº 1506 - Cuvango</option>
<option>Escola Do Ensino Primário Tyimue Nº 1602 - Cuvango</option>
<option>Escola Do Ensino Primário Tyingandji Nº 1572 - Cuvango</option>
<option>Escola Do Ensino Primário Tyiqueyeye Nº 1548 - Cuvango</option>
<option>Escola Do Ensino Primário Tyitunda Nº 1511 - Cuvango</option>
<option>Escola Do Ensino Primário Tyivango Nº 1621 - Cuvango</option>
<option>Escola Do Ensino Primário Utombe Nº 1529 - Cuvango</option>
<option>Escola Do Ensino Primário Zimbambi Nº 1526 - Cuvango</option>
<option>Escola Do Ensino Primário Zona Nº 3 Nº 1531 - Cuvango</option>
<option>Escola Do I Ciclo Do Ensino Secundário  Nº 1554 - Cuvango</option>
<option>Escola Do I Ciclo Do Ensino Secundário Nº 1608 - Cuvango</option>
<option>Escola Do I Ciclo Do Ensino Secundário Sede Nº 1484 - Cuvango</option>
<option>Escola Do Ii Ciclo Do Ensino Secundário Sede Nº 1483 - Cuvango</option>
<option>Escola Primária 4 De Abril N. 1583 </option>
<option>Escola Primária Anhara N. 1551 </option>
<option>Escola Primária Aunje N. 1543 </option>
<option>Escola Primária Calundungo N. 1498 </option>
<option>Escola Primária Colui N. 1500 </option>
<option>Escola Primária Embala Yandumba N. 1553</option> 
<option>Escola Primária Epomba N. 1601 </option>
<option>Escola Primária Fé Apostolica N. 772 </option>
<option>Escola Primária Indungo N. 1532 </option>
<option>Escola Primária Kalindi N. 1015 </option>
<option>Escola Primária Kambole N. 1603 </option>
<option>Escola Primária Kanhana N. 1491 </option>
<option>Escola Primária Kapoco N. 1567 </option>
<option>Escola Primária Katala N. 1807 </option>
<option>Escola Primária Katenda N. 1597 </option>
<option>Escola Primária Kauando Kativa N. 1476 </option>
<option>Escola Primária Kavandje N. 1469 </option>
<option>Escola Primária Kavinga N. 1493 </option>
<option>Escola Primária Lingombe N. 1517 </option>
<option>Escola Primária Macoco N. 1472</option>
<option>Escola Primária Mpalanga N. 926 </option>
<option>Escola Primária Muene Tyihuaku N. 1538 </option>
<option>Escola Primária Mumba Aldeia N. 1804 </option>
<option>Escola Primária Ngumbe - Tyivimba N. 1503</option> 
<option>Escola Primária Popular N. 1528 </option>
<option>Escola Primária Sete Casas - Missombo N. 1525</option> 
<option>Escola Primária Tchindovi N. 1757   </option>
<option>Escola Primária Tchissito N. 1542 </option>
<option>Escola Primária Tchissoy N. 1545 </option>
<option>Escola Primária Tuvula N. 1600 </option>
<option>Escola Primária Tyicunho N. 1550 </option>
<option>Escola Primária Tyihongo - Kapembe N. 1508</option> 
<option>Escola Primária Tyihuaku N. 1510 </option>
<option>Escola Primária Tyihungo Ii N. 1473 </option>
<option>Escola Primária Tyimpemba N. 1509 </option>
<option>Escola Primária Tyindjandjangui N. 1589 </option>
<option>Escola Primária Tyumba - Ngombe N. 1614 </option>
<option>Escola Primária Vicungo Sede N. 1609 </option>
<option>Escola Primária Zona N. 2 N. 1530 </option>




