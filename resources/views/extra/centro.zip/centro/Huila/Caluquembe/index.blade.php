<option>Colégio Aurélio F. Dos Santos N. 1628 </option>
<option>Colégio Fadario Faustino Muteca N. 1299 </option>
<option>Escola Do Ensino Primário Alto Catambi Nº 1048 - Caluquembe</option>
<option>Escola Do Ensino Primário Assupo Nº 293 - Caluquembe</option>
<option>Escola Do Ensino Primário Assute Ponte Ya Suco Nº 1051 - Caluquembe</option>
<option>Escola Do Ensino Primário Buandangue Nº 1251 - Caluquembe</option>
<option>Escola Do Ensino Primário Cachiombo Nº 1421 - Caluquembe</option>
<option>Escola Do Ensino Primário Cachissome Ii Nº 535 - Caluquembe</option>
<option>Escola Do Ensino Primário Cacovo Nº 355 - Caluquembe</option>
<option>Escola Do Ensino Primário Cahãla Nº 475 - Caluquembe</option>
<option>Escola Do Ensino Primário Caia Nº 476 - Caluquembe</option>
<option>Escola Do Ensino Primário Caingulungulu Nº 518 - Caluquembe</option>
<option>Escola Do Ensino Primário Caissombo Nº 511 - Caluquembe</option>
<option>Escola Do Ensino Primário Calilongue Cussuca Nº 739 - Caluquembe</option>
<option>Escola Do Ensino Primário Calilongue Nº 1257 - Caluquembe</option>
<option>Escola Do Ensino Primário Calohuita Nº 267 - Caluquembe</option>
<option>Escola Do Ensino Primário Calomalanga Nº 1304 - Caluquembe</option>
<option>Escola Do Ensino Primário Calomalanga Nº 1390 - Caluquembe</option>
<option>Escola Do Ensino Primário Calombambi Nº 283 - Caluquembe</option>
<option>Escola Do Ensino Primário Calonali Nº 309 - Caluquembe</option>
<option>Escola Do Ensino Primário Calondueio Nº 1355 - Caluquembe</option>
<option>Escola Do Ensino Primário Caloneva - Bissapa Nº 1711 - Caluquembe</option>
<option>Escola Do Ensino Primário Caloningui Nº 263 - Caluquembe</option>
<option>Escola Do Ensino Primário Calonjawe Nº 515 - Caluquembe</option>
<option>Escola Do Ensino Primário Caloqui Nº 266 - Caluquembe</option>
<option>Escola Do Ensino Primário Calumbamba Nº 1307 - Caluquembe</option>
<option>Escola Do Ensino Primário Calumue Nº 354 - Caluquembe</option>
<option>Escola Do Ensino Primário Calunga Nº 509 - Caluquembe</option>
<option>Escola Do Ensino Primário Camanha Nº 538 - Caluquembe</option>
<option>Escola Do Ensino Primário Cambulungo Ii Nº 1796 - Caluquembe</option>
<option>Escola Do Ensino Primário Cambundi Nº 1309 - Caluquembe</option>
<option>Escola Do Ensino Primário Camongua Nº 514 - Caluquembe</option>
<option>Escola Do Ensino Primário Camucuio Sede Nº 1433 - Caluquembe</option>
<option>Escola Do Ensino Primário Camunda - Nombowi Nº 287 - Caluquembe</option>
<option>Escola Do Ensino Primário Candimba Nº 1395 - Caluquembe</option>
<option>Escola Do Ensino Primário Candondo Nº 1310 - Caluquembe</option>
<option>Escola Do Ensino Primário Cangala Nº 394 - Caluquembe</option>
<option>Escola Do Ensino Primário Cangolo Nº 330 - Caluquembe</option>
<option>Escola Do Ensino Primário Canjongo Nº 348 - Caluquembe</option>
<option>Escola Do Ensino Primário Canongongue Nº 453 - Caluquembe</option>
<option>Escola Do Ensino Primário Capangue Nº 376 - Caluquembe</option>
<option>Escola Do Ensino Primário Capele Nº 1269 - Caluquembe</option>
<option>Escola Do Ensino Primário Caquengue Nº 478 - Caluquembe</option>
<option>Escola Do Ensino Primário Cavaco Nº 284 - Caluquembe</option>
<option>Escola Do Ensino Primário Cavava I Nº 540 - Caluquembe</option>
<option>Escola Do Ensino Primário Cavincia Nº 1313 - Caluquembe</option>
<option>Escola Do Ensino Primário Chacapa Nº 276 - Caluquembe</option>
<option>Escola Do Ensino Primário Chicole - Camucua Nº 386 - Caluquembe</option>
<option>Escola Do Ensino Primário Chilala Nº 1275 - Caluquembe</option>
<option>Escola Do Ensino Primário Chiluandi Nº 1340 - Caluquembe</option>
<option>Escola Do Ensino Primário Chindendema I Nº 1362 - Caluquembe</option>
<option>Escola Do Ensino Primário Chinuangolo Nº 384 - Caluquembe</option>
<option>Escola Do Ensino Primário Chinussi I Nº 271 - Caluquembe</option>
<option>Escola Do Ensino Primário Chipalacassa Nº 762 - Caluquembe</option>
<option>Escola Do Ensino Primário Chipulo Nº 655 - Caluquembe</option>
<option>Escola Do Ensino Primário Chissua I Nº 531 - Caluquembe</option>
<option>Escola Do Ensino Primário Chitape Nº 300 - Caluquembe</option>
<option>Escola Do Ensino Primário Chitupi I Nº 285 - Caluquembe</option>
<option>Escola Do Ensino Primário Chivulo Sanda Nº 381 - Caluquembe</option>
<option>Escola Do Ensino Primário Cubal Chiva Nº 526 - Caluquembe</option>
<option>Escola Do Ensino Primário Cundjo Nº 750 - Caluquembe</option>
<option>Escola Do Ensino Primário Cussesse Bupo Nº 501 - Caluquembe</option>
<option>Escola Do Ensino Primário Dimba Nº 545 - Caluquembe</option>
<option>Escola Do Ensino Primário Dongo Nº 389 - Caluquembe</option>
<option>Escola Do Ensino Primário Ecolocolo I Nº 1368 - Caluquembe</option>
<option>Escola Do Ensino Primário Eliva Nº 1289 - Caluquembe</option>
<option>Escola Do Ensino Primário Embondo Nº 1797 - Caluquembe</option>
<option>Escola Do Ensino Primário Enkhulo Nº 315 - Caluquembe</option>
<option>Escola Do Ensino Primário Epalanga Nº 1291 - Caluquembe</option>
<option>Escola Do Ensino Primário Epipa I Nº 391 - Caluquembe</option>
<option>Escola Do Ensino Primário Etamba Nº 443 - Caluquembe</option>
<option>Escola Do Ensino Primário Etonga Nº 1296 - Caluquembe</option>
<option>Escola Do Ensino Primário Etumala Nº 321 - Caluquembe</option>
<option>Escola Do Ensino Primário Etutu Nº 336 - Caluquembe</option>
<option>Escola Do Ensino Primário Fazenda Cussesse Nº 378 - Caluquembe</option>
<option>Escola Do Ensino Primário Gangawe Nº 532 - Caluquembe</option>
<option>Escola Do Ensino Primário Gombe Yenda Nº 820 - Caluquembe</option>
<option>Escola Do Ensino Primário Hachicuala Nº 744 - Caluquembe</option>
<option>Escola Do Ensino Primário Hengue Nº 1326 - Caluquembe</option>
<option>Escola Do Ensino Primário Kalohanda Nº 1693 - Caluquembe</option>
<option>Escola Do Ensino Primário Kaloñeñe Nº721 - Caluquembe</option>
<option>Escola Do Ensino Primário Kaluhimba Nº 1249 - Caluquembe</option>
<option>Escola Do Ensino Primário Lomba Baixo Nº 1314 - Caluquembe</option>
<option>Escola Do Ensino Primário Lombamba Nº 395 - Caluquembe</option>
<option>Escola Do Ensino Primário Lombanja Nº 396 - Caluquembe</option>
<option>Escola Do Ensino Primário Masseta - Cussesse Nº 1410 - Caluquembe</option>
<option>Escola Do Ensino Primário Mucungo Nº 1800 - Caluquembe</option>
<option>Escola Do Ensino Primário Munda Nº 1378 - Caluquembe</option>
<option>Escola Do Ensino Primário Nazara Nº 301 - Caluquembe</option>
<option>Escola Do Ensino Primário Ngombengua Nº 444 - Caluquembe</option>
<option>Escola Do Ensino Primário Nhumula Nº 1324 - Caluquembe</option>
<option>Escola Do Ensino Primário Nº 1059 - Caluquembe</option>
<option>Escola Do Ensino Primário Noca Nº 1414 - Caluquembe</option>
<option>Escola Do Ensino Primário Nombowi Nº 1791 - Caluquembe</option>
<option>Escola Do Ensino Primário Nondua Nº 503 - Caluquembe</option>
<option>Escola Do Ensino Primário Quela Camunda Ii Nº 472 - Caluquembe</option>
<option>Escola Do Ensino Primário Quela Daundo Nº 403 - Caluquembe</option>
<option>Escola Do Ensino Primário Sacalesso Ii Nº 1794 - Caluquembe</option>
<option>Escola Do Ensino Primário Santo António Nº 521 - Caluquembe</option>
<option>Escola Do Ensino Primário Suali Nº 1338 - Caluquembe</option>
<option>Escola Do Ensino Primário Sucula Nº 566 - Caluquembe</option>
<option>Escola Do Ensino Primário Talamangolo Nº 316 - Caluquembe</option>
<option>Escola Do Ensino Primário Tchatende Nº 1033 - Caluquembe</option>
<option>Escola Do Ensino Primário Tchilombo I Nº 345 - Caluquembe</option>
<option>Escola Do Ensino Primário Tchivavulo Nº 1332 - Caluquembe</option>
<option>Escola Do Ensino Primário Ussila Nº 1323 - Caluquembe</option>
<option>Escola Do Ensino Primário Valengue Nº 338 - Caluquembe</option>
<option>Escola Do Ensino Primário Vipembe Nº 278 - Caluquembe</option>
<option>Escola Do Ensino Primário Volutue Nº 329 - Caluquembe</option>
<option>Escola Do Ensino Primário Waliheia Nº 448 - Caluquembe</option>
<option>Escola Do Ensino Primário Yela Bissapa Nº 1295 - Caluquembe</option>
<option>Escola Do Ii Ciclo Nº 1202 - Caluquembe</option>
<option>Escola Primária 4 De Fevereiro N. 1292 </option>
<option>Escola Primária Alto Chiva N. 411 </option>
<option>Escola Primária Amilcar Cabral N. 365 </option>
<option>Escola Primária Babayela Ii N. 1387 </option>
<option>Escola Primária Bomba N. 1795 </option>
<option>Escola Primária Bupo Vialavi N. 366 </option>
<option>Escola Primária Cachilala N. 1392 </option>
<option>Escola Primária Cachimano N. 1049 </option>
<option>Escola Primária Cachiniengue N. 353 </option>
<option>Escola Primária Cachipipa N. 456 </option>
<option>Escola Primária Cacomba N. 295 </option>
<option>Escola Primária Cafifi - Cola N. 323 </option>
<option>Escola Primária Cafula N. 334 </option>
<option>Escola Primária Caissaca N. 299 </option>
<option>Escola Primária Calanda Sede N. 1303 </option>
<option>Escola Primária Calepi - Sede N. 502 </option>
<option>Escola Primária Calepi Ii N. 1256 </option>
<option>Escola Primária Calofiufiu N. 387 </option>
<option>Escola Primária Calohombo N. 507 </option>
<option>Escola Primária Calomanda Chavola N. 524 </option>
<option>Escola Primária Caloneva N. 1306 </option>
<option>Escola Primária Caloneva Negola N. 567 </option>
<option>Escola Primária Calonguluve N. 463 </option>
<option>Escola Primária Calupele N. 773 </option>
<option>Escola Primária Cambala N. 1801 </option>
<option>Escola Primária Cambulungu N. 374 </option>
<option>Escola Primária Campo De Aviação N. 1264 </option>
<option>Escola Primária Campuena N. 1393 </option>
<option>Escola Primária Camuholo I N. 375 </option>
<option>Escola Primária Camunda - Ex. Leprosaria N. 1265 </option>
<option>Escola Primária Camunda - Vionga N. 279 </option>
<option>Escola Primária Canelungo N. 517 </option>
<option>Escola Primária Capica I N. 368 </option>
<option>Escola Primária Casas Novas - Hospital N. 1270</option> 
<option>Escola Primária Catala Capele N. 437 </option>
<option>Escola Primária Catala Vatuco N. 347 </option>
<option>Escola Primária Catchissome Iii N. 1312</option> 
<option>Escola Primária Cateia N. 519 </option>
<option>Escola Primária Cavinga I N. 488 </option>
<option>Escola Primária Chaunje I N. 1360 </option>
<option>Escola Primária Chavola N. 522 </option>
<option>Escola Primária Chicatula Camota N. 363 </option>
<option>Escola Primária Chicatula Ii N. 460 </option>
<option>Escola Primária Chicole Camunda N. 379 </option>
<option>Escola Primária Chilunda I N. 1276 </option>
<option>Escola Primária Chilunda Lupale N. 1277</option> 
<option>Escola Primária Chissua Ii N. 528 </option>
<option>Escola Primária Chitongo N. 924 </option>
<option>Escola Primária Chitula N. 339 </option>
<option>Escola Primária Chivulo N. 1401 </option>
<option>Escola Primária Chivulu - Alto N. 461</option> 
<option>Escola Primária Cola N. 513 </option>
<option>Escola Primária Comandante Cassanje N. 342 </option>
<option>Escola Primária Comandante Ngonga N. 737</option> 
<option>Escola Primária Cucala N. 297 </option>
<option>Escola Primária Cue I N. 331 </option>
<option>Escola Primária Cue Iii N. 1657 </option>
<option>Escola Primária Cuilo N. 264 </option>
<option>Escola Primária Cussesse Ponte N. 388 </option>
<option>Escola Primária Cussuca N. 304 </option>
<option>Escola Primária Dende N. 317 </option>
<option>Escola Primária Embala Tchiveio N. 482 </option>
<option>Escola Primária Engolonga N. 199 </option>
<option>Escola Primária Etunda N. 1297 </option>
<option>Escola Primária Gando N. 498 </option>
<option>Escola Primária Giraul N. 286 </option>
<option>Escola Primária Havemos De Voltar N. 1301</option> 
<option>Escola Primária Hondeque N. 270 </option>
<option>Escola Primária Jamba N. 1407 </option>
<option>Escola Primária Jole N. 506 </option>
<option>Escola Primária Lomba Alto N. 280 </option>
<option>Escola Primária Luepanda N. 542 </option>
<option>Escola Primária Lupale N. 1802 </option>
<option>Escola Primária Massolali N. 1377 </option>
<option>Escola Primária Missão Católica N. 399</option> 
<option>Escola Primária N. 401 </option>
<option>Escola Primária Peniel N. 382 </option>
<option>Escola Primária Quela Ponte N. 405 </option>
<option>Escola Primária Sacalesso I N. 265 </option>
<option>Escola Primária Sambongo N. 508 </option>
<option>Escola Primária São José N. 260 </option>
<option>Escola Primária São Pedro N. 289 </option>
<option>Escola Primária São Tiago N. 296 </option>
<option>Escola Primária Simo N. 1799 </option>
<option>Escola Primária Tchaunje N. 724 </option>
<option>Escola Primária Tchiteculo N. 1331 </option>
<option>Escola Primária Tchitupi Ii N. 1305 </option>
<option>Escola Primária Tiãi - Tiãi N. 446 </option>
<option>Escola Primária Úkua N. 408 </option>
<option>Escola Primária Vandongo N. 1334 </option>
<option>Escola Primária Vato Vato N. 1486 </option>
<option>Escola Primária Vatuco Sede N. 325 </option>
<option>Escola Primária Vila Branca N. 447 </option>
<option>Escola Primária Vilemba N. 485 </option>
<option>Escola Primária Vingalipi N. 1384 </option>
<option>Escola Primária Vionga N. 1337 </option>
<option>Escola Primária Vissassa N. 409 </option>
<option>Escola Primária Waia Sede N. 269 </option>
<option>Escola Primária Wamboa N. 307 </option>
<option>Escola Primária Yuvo - Sede N. 536 </option>
<option>Instituto Politécnico N. 1825 - Caluquembe</option>
<option>Instituto Técnico De Formação De Saúde N. 1283 - Caluquembe</option>
<option>Magistério N. 1279 São Tiago - Caluquembe</option>
<option>Magistério N. 1842 Abel Pedro - Caluquembe</option>