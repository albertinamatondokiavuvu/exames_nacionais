<option>Colégio N. 1710 </option>
<option>Complexo Escolar Hamavoko Do Sêndi N. 6</option> 
<option>Escola Do  I Ciclo  Do Ensino Secundário Nº 414 - Quipungo</option>
<option>Escola Do Ensino Primário Banda Cateta Nº 426 - Quipungo</option>
<option>Escola Do Ensino Primário Banda Tchimanhiqui Nº 424 - Quipungo</option>
<option>Escola Do Ensino Primário Banda-Catchila Nº 1770 - Quipungo</option>
<option>Escola Do Ensino Primário Bango Nº 1072 - Quipungo</option>
<option>Escola Do Ensino Primário Bember Tchingãngã Nº 557 - Quipungo</option>
<option>Escola Do Ensino Primário Bember-Cambango Nº 1768 - Quipungo</option>
<option>Escola Do Ensino Primário Bembo Nº 553 - Quipungo</option>
<option>Escola Do Ensino Primário Caila Nº 1682 - Quipungo</option>
<option>Escola Do Ensino Primário Calongoiva Nº 864 - Quipungo</option>
<option>Escola Do Ensino Primário Camulemba Nº 1396 - Quipungo</option>
<option>Escola Do Ensino Primário Canal Do Sêndi Nº 1686 - Quipungo</option>
<option>Escola Do Ensino Primário Candjongombua Nº 949 - Quipungo</option>
<option>Escola Do Ensino Primário Capato Nº 1450 - Quipungo</option>
<option>Escola Do Ensino Primário Catutula Nº 393 - Quipungo</option>
<option>Escola Do Ensino Primário Cavimue Nº 1339 - Quipungo</option>
<option>Escola Do Ensino Primário Cavindja Nº 1688 - Quipungo</option>
<option>Escola Do Ensino Primário Chimo Nº 1718 - Quipungo</option>
<option>Escola Do Ensino Primário Chingoli Nº 554 - Quipungo</option>
<option>Escola Do Ensino Primário Chivota Nº 1056 - Quipungo</option>
<option>Escola Do Ensino Primário Condo - Calola Nº 848 - Quipungo</option>
<option>Escola Do Ensino Primário Condo - Catewa  - Quipungo</option>
<option>Escola Do Ensino Primário Condo Da Handa Nº 385 - Quipungo</option>
<option>Escola Do Ensino Primário Derruba Nº 1691 - Quipungo</option>
<option>Escola Do Ensino Primário Dongui Da Handa Nº 1605 - Quipungo</option>
<option>Escola Do Ensino Primário Dongui Do Ngungo Nº 1394 - Quipungo</option>
<option>Escola Do Ensino Primário Dongui Malenga Nº 560 - Quipungo</option>
<option>Escola Do Ensino Primário Dongui Tchacamba Nº 1452 - Quipungo</option>
<option>Escola Do Ensino Primário Embala - Quipungo Nº 593 - Quipungo</option>
<option>Escola Do Ensino Primário Embala Da Handa Nº 686 - Quipungo</option>
<option>Escola Do Ensino Primário Embandy Nº 344 - Quipungo</option>
<option>Escola Do Ensino Primário Enkhondo Nº 1461 - Quipungo</option>
<option>Escola Do Ensino Primário Eyó Nº 1692 - Quipungo</option>
<option>Escola Do Ensino Primário Grade Tchicopo Nº 349 - Quipungo</option>
<option>Escola Do Ensino Primário Hombo Nº 555 - Quipungo</option>
<option>Escola Do Ensino Primário Kamaquipa Nº 1463 - Quipungo</option>
<option>Escola Do Ensino Primário Lupangue Nº 1694 - Quipungo</option>
<option>Escola Do Ensino Primário Macocomena Nº 410 - Quipungo</option>
<option>Escola Do Ensino Primário Maleva Nº 1695 - Quipungo</option>
<option>Escola Do Ensino Primário Malipi Iii Nº 689 - Quipungo</option>
<option>Escola Do Ensino Primário Mangueiras Do Bembo Nº 241 - Quipungo</option>
<option>Escola Do Ensino Primário Manungo Nº 1720 - Quipungo</option>
<option>Escola Do Ensino Primário Matende Nº 950 - Quipungo</option>
<option>Escola Do Ensino Primário Matito B Nº 841 - Quipungo</option>
<option>Escola Do Ensino Primário Mayandja  Nº 352 - Quipungo</option>
<option>Escola Do Ensino Primário Mphundo Nº 585 - Quipungo</option>
<option>Escola Do Ensino Primário Mucua Tchankhala Nº 402 - Quipungo</option>
<option>Escola Do Ensino Primário Mucuio Nº 1698 - Quipungo</option>
<option>Escola Do Ensino Primário Muheque Nº 1132 - Quipungo</option>
<option>Escola Do Ensino Primário Muholo Nº 1212 - Quipungo</option>
<option>Escola Do Ensino Primário Mulhengue B Nº 1404 - Quipungo</option>
<option>Escola Do Ensino Primário Mulhengue Nº 359 - Quipungo</option>
<option>Escola Do Ensino Primário Mulola - Sassi Nº 1620 - Quipungo</option>
<option>Escola Do Ensino Primário Mupembati Nº 1615 - Quipungo</option>
<option>Escola Do Ensino Primário Muquequete Nº 1634 - Quipungo</option>
<option>Escola Do Ensino Primário Murindi Nº 1699 - Quipungo</option>
<option>Escola Do Ensino Primário Mutonthola Nº 1399 - Quipungo</option>
<option>Escola Do Ensino Primário Muyanangombe Nº 1700 - Quipungo</option>
<option>Escola Do Ensino Primário Muyela Nº 459 - Quipungo</option>
<option>Escola Do Ensino Primário Ndjandjo Nº 364 - Quipungo</option>
<option>Escola Do Ensino Primário Nkholo Do Ngungo Nº 1650 - Quipungo</option>
<option>Escola Do Ensino Primário Noholongo Nº 1703 - Quipungo</option>
<option>Escola Do Ensino Primário Nohote Nº 373 - Quipungo</option>
<option>Escola Do Ensino Primário Nombunda Nº 1649 - Quipungo</option>
<option>Escola Do Ensino Primário Nongalafa B Nº 1652 - Quipungo</option>
<option>Escola Do Ensino Primário Nongoia Nº 597 - Quipungo</option>
<option>Escola Do Ensino Primário Nongongue Nº 1400 - Quipungo</option>
<option>Escola Do Ensino Primário Nonguelengue Nº 1449 - Quipungo</option>
<option>Escola Do Ensino Primário Sapumbula Nº 611 - Quipungo</option>
<option>Escola Do Ensino Primário Sassa Do Hombo Nº 1655 - Quipungo</option>
<option>Escola Do Ensino Primário Tchankhala Nº 595 - Quipungo</option>
<option>Escola Do Ensino Primário Tchapanga Nº 413 - Quipungo</option>
<option>Escola Do Ensino Primário Tchicacala Nº 380 - Quipungo</option>
<option>Escola Do Ensino Primário Tchihandji Nº 612 - Quipungo</option>
<option>Escola Do Ensino Primário Tchileuca Nº 709 - Quipungo</option>
<option>Escola Do Ensino Primário Tchilima Nº 1637 - Quipungo</option>
<option>Escola Do Ensino Primário Tchimuholo Nº 383 - Quipungo</option>
<option>Escola Do Ensino Primário Tchindumbili Nº 1454 - Quipungo</option>
<option>Escola Do Ensino Primário Tchitalavala Nº 1648 - Quipungo</option>
<option>Escola Do Ensino Primário Tchitemba Nº 1662 - Quipungo</option>
<option>Escola Do Ensino Primário Tchitembo Nº 1658 - Quipungo</option>
<option>Escola Do Ensino Primário Tchitunguila B Nº 606 - Quipungo</option>
<option>Escola Do Ensino Primário Tunda Nº 842 - Quipungo</option>
<option>Escola Do Ensino Primário Tyihali Nº 1534 - Quipungo</option>
<option>Escola Do Ensino Primário Vimbundo Nº 407 - Quipungo</option>
<option>Escola Do Ensino Primário Vinkhwenha Nº 581 - Quipungo</option>
<option>Escola Do Ensino Primário Viteta Da Handa Nº 864 - Quipungo</option>
<option>Escola Do Ensino Primário Vivai Nº 1458 - Quipungo</option>
<option>Escola Do Ensino Primário Vivo Nº 559 - Quipungo</option>
<option>Escola Do Ensino Primário Volela Nº 1456 - Quipungo</option>
<option>Escola Primária Bember Camumamão</option>
<option>Escola Primária Bember Tchimbango N. 1713</option> 
<option>Escola Primária Calemba</option>
<option>Escola Primária Calumbilo N. 1683</option> 
<option>Escola Primária Cambandi N. 1715 </option>
<option>Escola Primária Camunhandi</option>
<option>Escola Primária Camutonthola N. 592</option>
<option>Escola Primária Catolotolo N. 1717 </option>
<option>Escola Primária Chiconco N. 599 </option>
<option>Escola Primária Chicungo N. 569 </option>
<option>Escola Primária Chivanda N. 335 </option>
<option>Escola Primária Dondo N. 598 </option>
<option>Escola Primária Ducuta N. 685 </option>
<option>Escola Primária Embala Do Ngungo N. 594</option> 
<option>Escola Primária Iesa N. 687 </option>
<option>Escola Primária Kahokola N. 1667 </option>
<option>Escola Primária Kankhovo</option>
<option>Escola Primária Kawe N. 1669 </option>
<option>Escola Primária Kundungala N. 1671 </option>
<option>Escola Primária Leonardo Sicufinde</option>
<option>Escola Primária Lyumba N. 1459 </option>
<option>Escola Primária Mãe - Mãe N. 549 </option>
<option>Escola Primária Massango N. 1635 </option>
<option>Escola Primária Massumba N. 1810 </option>
<option>Escola Primária Matunda N. 1811 </option>
<option>Escola Primária Mavinda I N. 357 </option>
<option>Escola Primária Mavinda Ii N. 629 </option>
<option>Escola Primária Mucua N. 1141 </option>
<option>Escola Primária Mucuio N. 1786 </option>
<option>Escola Primária Mucusso N. 362 </option>
<option>Escola Primária Mulhengue</option>
<option>Escola Primária Munphanda Do Ombo N. 1619 </option>
<option>Escola Primária Mupalala N. 1070 </option>
<option>Escola Primária Muquewa N. 1610 </option>
<option>Escola Primária Muvonde N. 556 </option>
<option>Escola Primária N. 341 </option>
<option>Escola Primária N. 97 </option>
<option>Escola Primária Ngungo N. 1053 </option>
<option>Escola Primária Nkhanda N. 425 </option>
<option>Escola Primária Nkhanga Nohamba N. 558 </option>
<option>Escola Primária Nombindji N. 907 </option>
<option>Escola Primária Nompheto N. 1653 </option>
<option>Escola Primária Nongole N. 1674 </option>
<option>Escola Primária Nossassa</option>
<option>Escola Primária Pedreira N. 580 </option>
<option>Escola Primária Sagrada Esperança N. 1081</option> 
<option>Escola Primária São José Do Ngungo N. 358 </option>
<option>Escola Primária Tapi</option>
<option>Escola Primária Tchiheio N. 565 </option>
<option>Escola Primária Tchindjelo N. 1058 </option>
<option>Escola Primária Tchisselalelo N. 813 </option>
<option>Escola Primária Tchissonde N. 416 </option>
<option>Escola Primária Tchitunguila A N. 1670 </option>
<option>Escola Primária Tchitunguila Kuanza N. 1057</option> 
<option>Escola Primária Tchonga</option>
<option>Escola Primária Tuntum</option>
<option>Escola Primária Tyia N. 1680 </option>
<option>Escola Primária Vindangala N. 1660 </option>
<option>Escola Primária Vinthiava - Pioneiro Zeca N. 1709</option> 
<option>Escola Primária Vipuata N. 550 </option>
<option>Liceu N. 412 Dr. António Agostinho Neto - Quipungo</option>
<option>Direcção Municipal De Educação Da Caconda</option>
<option>Direcção Municipal De Educação Da Chibia</option>
<option>Direcção Municipal De Educação Da Humpata</option>
<option>Direcção Municipal De Educação Da Matala</option>
<option>Direcção Municipal De Educação De Cacula</option>
<option>Direcção Municipal De Educação De Caluquembe</option>
<option>Direcção Municipal De Educação De Chicomba</option>
<option>Direcção Municipal De Educação De Chipindo</option>
<option>Direcção Municipal De Educação De Quilengues</option>
<option>Direcção Municipal De Educação De Quipungo</option>
<option>Direcção Municipal De Educação Do Cuvango</option>
<option>Direcção Municipal De Educação Do Lubango</option>
<option>Direcção Municipal De Educação Dos Gambos</option>
