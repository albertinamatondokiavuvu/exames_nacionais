<option>Colégio Cacula N. 963 </option>
<option>Complexo Escolar Da Viamba N. 68</option>
<option>Escola Do Ensino Primário Caheia Nº 668 - Cacula</option>
<option>Escola Do Ensino Primário Calihengua Nº 931 - Cacula</option>
<option>Escola Do Ensino Primário Calombambi Nº 932 - Cacula</option>
<option>Escola Do Ensino Primário Calondau Nº 979 - Cacula</option>
<option>Escola Do Ensino Primário Camongua Nº 981 - Cacula</option>
<option>Escola Do Ensino Primário Capai Capalala Nº 1004 - Cacula</option>
<option>Escola Do Ensino Primário Cavissi  Ii Nº 1230 - Cacula</option>
<option>Escola Do Ensino Primário Hambia Nº 985 - Cacula</option>
<option>Escola Do Ensino Primário Mambondue Nº 228 - Cacula</option>
<option>Escola Do Ensino Primário Mapile Nº 948 - Cacula</option>
<option>Escola Do Ensino Primário Mbulo Nº 789 - Cacula</option>
<option>Escola Do Ensino Primário Mucumbe Nº 1006 - Cacula</option>
<option>Escola Do Ensino Primário Muhamba Nº 961 - Cacula</option>
<option>Escola Do Ensino Primário Mungongo-A Nº 971 - Cacula</option>
<option>Escola Do Ensino Primário Nhundo Nº 975 - Cacula</option>
<option>Escola Do Ensino Primário Nº 25 - Cacula</option>
<option>Escola Do Ensino Primário Nossite I Nº 988 - Cacula</option>
<option>Escola Do Ensino Primário Tchivucusso Nº 1008 - Cacula</option>
<option>Escola Do Ensino Primário Vicala Nº 122 - Cacula</option>
<option>Escola Do Ensino Primário Vilola Nº 994 - Cacula</option>
<option>Escola Do Ensino Primário Vissassa Nº 20  - Cacula</option>
<option>Escola Do I Ciclo Do Ensino Secundário Nº 1659 - Cacula</option>
<option>Escola Do I Ciclo Do Ensino Secundário Tchicuaqueia Nº 967 - Cacula</option>
<option>Escola Primária 16 De Agosto N. 1684</option>
<option>Escola Primária Alto Chiva N. 929 </option>
<option>Escola Primária Cacua N. 977</option>
<option>Escola Primária Calomalanga Rainha Nangombe N. 571</option>
<option>Escola Primária Camphaca N. 962</option>
<option>Escola Primária Camucuio I N. 934</option>
<option>Escola Primária Camucuio Ii N. 1664 </option>
<option>Escola Primária Camucuio Ii N. 995</option>
<option>Escola Primária Camucuio Vite Vivali N. 1018</option>
<option>Escola Primária Camunda N. 306 </option>
<option>Escola Primária Capewa N. 998 </option>
<option>Escola Primária Cassimo N. 1286 </option>
<option>Escola Primária Catanha Mawelequesse N. 938</option>
<option>Escola Primária Catanha Mbandi N. 1046 </option>
<option>Escola Primária Catanha Ponte N. 939</option>
<option>Escola Primária Catepe N. 940</option>
<option>Escola Primária Caúle N. 333 </option>
<option>Escola Primária Cavi Povoação N. 390 </option>
<option>Escola Primária Cavinga N. 983 </option>
<option>Escola Primária Cavingolo N. 966</option>
<option>Escola Primária Cavissi I N. 129 </option>
<option>Escola Primária Cavitchapi N. 123 </option>
<option>Escola Primária Chiva Baixo N. 1376 </option>
<option>Escola Primária Ecamba N. 942 </option>
<option>Escola Primária Hupa N. 968 </option>
<option>Escola Primária Hupanda N. 986</option>
<option>Escola Primária Km 100 N. 44</option>
<option>Escola Primária Lucondo Nomphalanga N. 235</option> 
<option>Escola Primária Macalango N. 944 </option>
<option>Escola Primária Macuco N. 1379</option>
<option>Escola Primária Maholeco N. 970 </option>
<option>Escola Primária Mambandi N. 1788 </option>
<option>Escola Primária Matome Ii N. 1805 </option>
<option>Escola Primária Mawengue N. 128 </option>
<option>Escola Primária Mphombo N. 130</option>
<option>Escola Primária Mucamba I N. 1255 </option>
<option>Escola Primária Mucondo I N. 1005 </option>
<option>Escola Primária Muesse N. 976 </option>
<option>Escola Primária Munkhumbi N. 969</option>
<option>Escola Primária Muquete N. 955</option>
<option>Escola Primária N. 1000 </option>
<option>Escola Primária N. 227 </option>
<option>Escola Primária N. 7 </option>
<option>Escola Primária Nangolo N. 987</option> 
<option>Escola Primária Nongongue N. 989 </option>
<option>Escola Primária Nonjava N. 1721</option>
<option>Escola Primária Simo Yombia N. 755</option>
<option>Escola Primária Tchainda N. 992 </option>
<option>Escola Primária Tchicocoti N. 991 </option>
<option>Escola Primária Tchicuaqueia Sede N. 1696 </option>
<option>Escola Primária Tcholo N. 1285</option>
<option>Escola Primária Tunda N. 231</option>
<option>Escola Primária Ussamba N. 958</option>
<option>Escola Primária Vimbamba N. 1010</option>
<option>Escola Primária Vimpuaquita N. 973</option>
<option>Escola Primária Vissassa N. 1418</option>
<option>Escola Primária Viti Vivali Sede N. 882 </option>
<option>Escola Primária Vitingã N. 1705 </option>
<option>Escola Primária Yavula N. 1184 </option>
<option>Escola Primária Yela N. 1016 </option>
<option>Liceu Da Cacula N. 1706</option>