<option>Colégio De Kassinga N. 1737 </option>
<option>Colégio N. 943 </option>
<option>Escola Do Ensino Primário Cambundo Nº 600 - Jamba</option>
<option>Escola Do Ensino Primário Chilumbo Nº 740 - Jamba</option>
<option>Escola Do Ensino Primário Cussava - Katali Nº 1293 - Jamba</option>
<option>Escola Do Ensino Primário Dingombe Nº 1465 - Jamba</option>
<option>Escola Do Ensino Primário Hungo Nº 760 - Jamba</option>
<option>Escola Do Ensino Primário Kangamba Nº 726 - Jamba</option>
<option>Escola Do Ensino Primário Kanhandi Ii Nº 933 - Jamba</option>
<option>Escola Do Ensino Primário Kantiava Nº 786 - Jamba</option>
<option>Escola Do Ensino Primário Katoco Nº 748 - Jamba</option>
<option>Escola Do Ensino Primário Kuandja B Nº 778 - Jamba</option>
<option>Escola Do Ensino Primário Liapeca Ii Nº 1742 - Jamba</option>
<option>Escola Do Ensino Primário Liapupa Ii Nº 1735 - Jamba</option>
<option>Escola Do Ensino Primário Lilemba Nº 628 - Jamba</option>
<option>Escola Do Ensino Primário Lucunga-B  Nº 19 - Jamba</option>
<option>Escola Do Ensino Primário Maculungungo Nº 758 - Jamba</option>
<option>Escola Do Ensino Primário Malengue Nº 790 - Jamba</option>
<option>Escola Do Ensino Primário Massundjo Nº 946 - Jamba</option>
<option>Escola Do Ensino Primário Mbandje Lilunga Nº 725 - Jamba</option>
<option>Escola Do Ensino Primário Mbua -Mavolovolo Nº 757 - Jamba</option>
<option>Escola Do Ensino Primário Mineira  Nº 346 - Jamba</option>
<option>Escola Do Ensino Primário Mitcha Nº 807 - Jamba</option>
<option>Escola Do Ensino Primário Morro Ii Nº 604 - Jamba</option>
<option>Escola Do Ensino Primário Mucuio Nº 818 - Jamba</option>
<option>Escola Do Ensino Primário Sendje Nº 766 - Jamba</option>
<option>Escola Do Ensino Primário Tchacaia  Nº 645 - Jamba</option>
<option>Escola Do Ensino Primário Tchatonda Nº 774 - Jamba</option>
<option>Escola Do Ensino Primário Tchimbandi Nº 741 - Jamba</option>
<option>Escola Do Ensino Primário Tchimpemba Nº 733 - Jamba</option>
<option>Escola Do Ensino Primário Thihongo Nº 615 - Jamba</option>
<option>Escola Do Ensino Primário Yambo Nº 1294 - Jamba</option>
<option>Escola Do Ii Ciclo Do Ensino Secundário Politécnico Da Jamba Nº 1826 - Jamba</option>
<option>Escola Primária 11 De Novembro N. 751 </option>
<option>Escola Primária 1º De Maio N. 749 </option>
<option>Escola Primária 21 De Janeiro N. 953 </option>
<option>Escola Primária 4 De Abril N. 821 </option>
<option>Escola Primária Boa Esperanca N. 722 </option>
<option>Escola Primária Cacola N. 432 </option>
<option>Escola Primária Cacungo N. 823 </option>
<option>Escola Primária Calilila N. 625 </option>
<option>Escola Primária Cambissa N. 1740 </option>
<option>Escola Primária Campulo N. 609 </option>
<option>Escola Primária Canhangue Grande N. 743 </option>
<option>Escola Primária Canhangue Pequeno N. 728 </option>
<option>Escola Primária Cantinas N. 816 </option>
<option>Escola Primária Capunda N. 831 </option>
<option>Escola Primária Centro Academico N. 732 </option>
<option>Escola Primária Colui N. 486 </option>
<option>Escola Primária Cussava N. 832 </option>
<option>Escola Primária Deolinda Rodrigues N. 610</option> 
<option>Escola Nova N. 1738 </option>
<option>Escola Primária Ex. Medico N. 756 </option>
<option>Escola Primária Eyela N. 613</option>
<option>Escola Primária Hoji Ya Henda N. 633 </option>
<option>Escola Primária Irene Kangumbe N. 622 </option>
<option>Escola Primária Kabanas N. 827 </option>
<option>Escola Primária Kahuica N. 631 </option>
<option>Escola Primária Kanhandi I N. 759 </option>
<option>Escola Primária Kassinga N. 630 </option>
<option>Escola Primária Kassongue N. 735 </option>
<option>Escola Primária Kilamba N. 775 </option>
<option>Escola Primária Kuandja - A N. 738 </option>
<option>Escola Primária Liapeca I N. 1741 </option>
<option>Escola Primária Liapupa N. 1475 </option>
<option>Escola Primária Lucunga - A N. 28 </option>
<option>Escola Primária Lucunga - C N. 602 </option>
<option>Escola Primária Luquene N. 810 </option>
<option>Escola Primária Malavi N. 614 </option>
<option>Escola Primária Matome N. 829 </option>
<option>Escola Primária Matoti N. 627 </option>
<option>Escola Primária Mbeu N. 1466 </option>
<option>Escola Primária Morro I N. 603 </option>
<option>Escola Primária Mupopo N. 1474 </option>
<option>Escola Primária Mutiapulo N. 1096 </option>
<option>Escola Primária N. 343 </option>
<option>Escola Primária N. 417 </option>
<option>Escola Primária Ndumba N. 729 </option>
<option>Escola Primária Ngangula N. 727 </option>
<option>Escola Primária Ngossi N. 1736 </option>
<option>Escola Primária Operario N. 745 </option>
<option>Escola Primária Popular N. 765 </option>
<option>Escola Primária Sassi - A N. 561 </option>
<option>Escola Primária Valodia N. 616 </option>
<option>Escola Primária Vihongue N. 608 </option>
<option>Escola Primária Vincava N. 761 </option>
<option>Escola Primária Yambo N. 719 </option>
<option>Liceu N. 1477 - Jamba</option>

