<option>Colégio Cdte Gika N. 457 </option>
<option>Colégio Kapunda Kavilongo</option>
<option>Colégio N. 1423 </option>
<option>Complexo Escolar Da Nolata N. 440</option>
<option>Coordenação Escolar Comunal Jau - Chibia</option>
<option>Coordenação Escolar Comunal K. Kavilongo - Chibia</option>
<option>Coordenação Escolar Comunal Quihita - Chibia</option>
<option>Direcção Municipal Da Educação, Ciência E Tecnologia Da Chibia  - Chibia</option>
<option>Escola 1º De Maio Nº 1374 - Chibia</option>
<option>Escola Do E. Secundário Nº 529 - Chibia</option>
<option>Escola Kakwa 886 - Chibia</option>
<option>Escola Primaria 11 De Novembro Nº 439 - Chibia</option>
<option>Escola Primaria 22 De Novembro Nº 1017 - Chibia</option>
<option>Escola Primaria A.A.Holanda N. 42 </option>
<option>Escola Primaria A.Ngangula Nº489 - Chibia</option>
<option>Escola Primaria Ass. Kakuluvar Nº 234 - Chibia</option>
<option>Escola Primaria Ass. Lufinda N. 909 </option>
<option>Escola Primaria Balela Nº 56 - Chibia</option>
<option>Escola Primaria Baptista Nº 1032 - Chibia</option>
<option>Escola Primaria Bongo Nº 568 - Chibia</option>
<option>Escola Primaria Chaungo Nº 84 - Chibia</option>
<option>Escola Primária Cinzento N. 449</option>
<option>Escola Primária Da Tyakaka N. 294</option>
<option>Escola Primaria Embala Nº 708 - Chibia</option>
<option>Escola Primaria <option>Escola N. 58 </option>
<option>Escola Primaria Hale-Mukuma Nº 494 - Chibia</option>
<option>Escola Primaria Hango I Nº 495 - Chibia</option>
<option>Escola Primaria Hango Ii Nº 496 - Chibia</option>
<option>Escola Primaria Havailo Nº 46 - Chibia</option>
<option>Escola Primaria Kahima Nº 484 - Chibia</option>
<option>Escola Primaria Kahoka Nº 799 - Chibia</option>
<option>Escola Primaria Kakuluvar I Nº 82 - Chibia</option>
<option>Escola Primaria Kakuluvar Ii Nº 1453 - Chibia</option>
<option>Escola Primaria Kalambona Nº 483 - Chibia</option>
<option>Escola Primaria Kalili Nº 552 - Chibia</option>
<option>Escola Primaria Kalumbilo N. 833 </option>
<option>Escola Primária Kamana N. 704</option>
<option>Escola Primaria Kamulemba Nº 839 - Chibia</option>
<option>Escola Primaria Kangalongue I Nº 72 - Chibia</option>
<option>Escola Primaria Kangalongue Ii Nº 800 - Chibia</option>
<option>Escola Primaria Kangolo Nº 96 - Chibia</option>
<option>Escola Primaria Kanguele N. 641 </option>
<option>Escola Primaria Kapangui Nº 1451 - Chibia</option>
<option>Escola Primaria Leu Nº 539 - Chibia</option>
<option>Escola Primaria Lumbalambamba N. 85 </option>
<option>Escola Primaria Lumbi Nº 537 - Chibia</option>
<option>Escola Primária Mandume N. 1298</option>
<option>Escola Primaria Maputo Nº 639 - Chibia</option>
<option>Escola Primaria Milondo Nº 1403 - Chibia</option>
<option>Escola Primaria Mingue N. 776 </option>
<option>Escola Primária Minhandi Kamphulo N. 667</option>
<option>Escola Primária Missão Da Quihita</option>
<option>Escola Primaria Mphanga Nº 462 - Chibia</option>
<option>Escola Primaria Mphapa Nº 452 - Chibia</option>
<option>Escola Primaria Mphiti N. 863 </option>
<option>Escola Primaria Muama Nº 883 - Chibia</option>
<option>Escola Primaria Muelwa Nº 828 - Chibia</option>
<option>Escola Primaria Muhandji Nº 473 - Chibia</option>
<option>Escola Primaria Mukua A Nº 78 - Chibia</option>
<option>Escola Primaria Mukua B Nº 491 - Chibia</option>
<option>Escola Primaria Mukua N. 785 </option>
<option>Escola Primária Mukuandimba N. 43</option>
<option>Escola Primaria Mukuma Nº 73 - Chibia</option>
<option>Escola Primaria Mulemba Tyiliata N. 858 </option>
<option>Escola Primaria Mume Nº 867 - Chibia</option>
<option>Escola Primaria Munhandi Nº 500 - Chibia</option>
<option>Escola Primaria Mupaka B Nº 422 - Chibia</option>
<option>Escola Primária N. 167</option>
<option>Escola Primária N. 70</option>
<option>Escola Primaria N. 83 </option>
<option>Escola Primária N. 91</option>
<option>Escola Primaria N. 92 </option>
<option>Escola Primaria Ndjondjo Nº1140 - Chibia</option>
<option>Escola Primaria Ngunga Nº 54 - Chibia</option>
<option>Escola Primaria Nkhulimbua Nº441 - Chibia</option>
<option>Escola Primaria Nombo Ii Nº 102 - Chibia</option>
<option>Escola Primária Nombuaneno N. 779</option>
<option>Escola Primaria Nongalafa Nº 104 - Chibia</option>
<option>Escola Primaria Nongolo N. 512 </option>
<option>Escola Primaria Nontyima  - Chibia</option>
<option>Escola Primaria Nonyi Nº 1206 - Chibia</option>
<option>Escola Primaria Rio Da Huíla N. 442 </option>
<option>Escola Primaria Santa Filomena Nº 479 - Chibia</option>
<option>Escola Primaria Tchikuatiti Nº 86 - Chibia</option>
<option>Escola Primaria Tchingoluena Nº 510 - Chibia</option>
<option>Escola Primária Tua -B N. 951</option>
<option>Escola Primaria Tua-A Nº 445 - Chibia</option>
<option>Escola Primaria Tyakaka Nº 294 - Chibia</option>
<option>Escola Primaria Tyela N. 451 </option>
<option>Escola Primaria Tyifuko Nº 850 - Chibia</option>
<option>Escola Primaria Tyikova Nº 101 - Chibia</option>
<option>Escola Primaria Tyima Nº 1471 - Chibia</option>
<option>Escola Primaria Tyinkhelele Nº 480 - Chibia</option>
<option>Escola Primaria Tyipa N. 232 </option>
<option>Escola Primaria Tyitaka N. 80</option>
<option>Escola Primaria Tyivengueva Nº 701 - Chibia</option>
<option>Escola Primaria Yalo Nº 533 - Chibia</option>
<option>Escola Primária Yoba N. 40</option>
<option>Escola Secundária Do Ii Ciclo E.Secundario Nº454 - Chibia</option>
