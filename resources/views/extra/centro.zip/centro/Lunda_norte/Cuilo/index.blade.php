<option>Direcção Municipal Da Educação Do Cuilo</option>
<option>Escola Do Ensino Primário E Do I Ciclo Do Cuilo - Cuilo</option>
<option>Escola Primária N. 106 - Sede Municipal</option>