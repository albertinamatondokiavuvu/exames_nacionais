<option>Colégio (Comparticipado) Do Bom Deus</option>
<option>Colégio Do Santo António Do Chitato</option>
<option>Colégio Eli-Formar</option>
<option>Colégio N. 13 Do Dundo</option>
<option>Complexo Escola Do Samacaca</option>
<option>Complexo Escolar Delegado Eusébio Nelsem</option>
<option>Complexo Escolar Do Carinhenga</option>
<option>Complexo Escolar Do Caxinde</option>
<option>Complexo Escolar Do Muanguvo </option>
<option>Complexo Escolar N. 1 Do Chitato</option>
<option>Complexo Escolar N. 8 Do Sachindongo</option>
<option>Escola  Do Ensino Primário Nº 3 - Chitato</option>
<option>Escola Do En. Prim E I Cíclo Do Ensino Secundário - Chitato</option>
<option>Escola Do Ens. Prim. Nº  22 - 4 De Abril - Chitato</option>
<option>Escola Do Ens. Secundário Nº 6 - Chitato</option>
<option>Escola Do Ens. Secundário Nº 7 - Chitato</option>
<option>Escola Do Ensino Primário Nº  4 - Chitato</option>
<option>Escola Do Ensino Primário Nº  5 - Chitato</option>
<option>Escola Do Ensino Primário Nº  9 - Chitato</option>
<option>Escola Do Ensino Primário Nº 11 - Chitato</option>
<option>Escola Do Ensino Primário Nº 12 - Chitato</option>
<option>Escola Do Iº Cíclo  Osvaldo Serra Van-Dúnem  - Chitato</option>
<option>Escola Primária Claúdio Francisco Poullar Place (Católica)</option>
<option>Escola Primária Do Ensino Especial Do Dundo</option>
<option>Gabiente Provincial Da Educação Da Lunda Norte</option>
<option>Instituto Médio Polictécnico Do Dundo </option>
<option>Instituto Técnico De Saúde Do Dundo </option>
<option>Liceu Do Dundo</option>
<option>Repartiçãao Municipal Da Educação - Chitato</option>
