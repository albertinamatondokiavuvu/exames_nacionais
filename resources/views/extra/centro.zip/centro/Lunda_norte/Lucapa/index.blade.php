<option>Biblioteca Provincial Da L. Norte</option>
<option>Colaboradores E Contratados Dme.Chitato</option>
<option>Complexo Escolar Do Rock</option>
<option>Complexo Escolar Do Veiga</option>
<option>Complexo Escolar N. 54 Centro Urbano</option>
<option>Dir.Prov.Educ.L.Norte-Conc.Pub./06-Ins.Mai07</option>
<option>Direcção Municipal Da Educação Do Lucapa</option>
<option>Escola Primária Do Camutue</option>
<option>Escola Primária Do Capaia</option>
<option>Escola Primária Do Luenda</option>
<option>Escola Primária Do Sambaia</option>
<option>Escola Primária Dr. António Angostinho Neto</option>
<option>Escola Primária N. 51 - Calonda</option>
<option>Escola Primária Santa Isabel</option>
<option>Instituto Politec- Contratados</option>
<option>Med - Instituto Politecnico Do Nordeste</option>
<option>Med - Municipal Do Chitato</option>
<option>Med - Municipal Do Xa-Muteba</option>
<option>Mincult - Direççao Provincial Da Lunda Norte</option>
<option>Professores   Adpp Do Chitato</option>

