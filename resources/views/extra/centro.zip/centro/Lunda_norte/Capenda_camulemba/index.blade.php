<option>Complexo Escolar N. 143 - 4 De Fevereiro</option>
<option>Direcção Municipal Da Educação Do Capenda-Camulemba</option>
<option>Escola Do Ensino Primário  E Iº Ciclo 22 De Nov. - Capenda Camulemba</option>
<option>Escola Do Ensino Primário Ngola Kiluangue - Capenda Camulemba</option>
<option>Escola Primária N. 136 - 11 De Novembro</option>






