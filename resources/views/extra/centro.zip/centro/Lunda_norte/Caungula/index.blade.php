<option>Direcção Municipal Da Educação Do Caungula</option>
<option>Escola Do Ensino Primário  Do Txipanda - Caungula</option>
<option>Escola Do Ensino Primário 4 De Abril - Caungula</option>
<option>Escola Do Ensino Primário Nº 112 - Caungula</option>
<option>Escola Do Ensino Primário Nº 215 - Caungula</option>
<option>Escola Do Ensino Primário Nº 46 Uhamba - Caungula</option>
<option>Escola Do Ensino Primário Nº 49/4 De Fev. - Caungula</option>
<option>Escola Do Ensino Primário Nº 60 - Caungula</option>
<option>Escola Do Ensino Primário Nº 64/Aeroporto - Caungula</option>
<option>Escola Do Ensino Primário Nº 67 Cuengo - Caungula</option>
<option>Escola Do Ensino Primário Nº 72 - Caungula</option>
<option>Escola Do Ensino Primário Nº48 Txotxo Wianze - Caungula</option>
<option>Escola Do I Ciclo Do Ensino Sec. Do Caungula - Caungula</option>
