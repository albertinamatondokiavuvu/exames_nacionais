<option>Complexo Escolar N. 113 - 4 De Abril</option>
<option>Complexo Escolar N. 128 Arco-Íris</option>
<option>Complexo Escolar N. 129 Rainha Muana Cafunfo</option>
<option>Complexo Escolar N. 9 Orgulho De Ser</option>
<option>Escola Do E. Prim. E Do Iº Ciclo Nº 117 - Cuango</option>
<option>Escola Do Ensino Primário  Madre Alphonso-Cuango - Cuango</option>
<option>Escola Do Ensino Primário Do Bº Fernando   - Cuango</option>
<option>Escola Do Ensino Primário E Do I Ciclo Nº 114 - Cuango</option>
<option>Escola Do Ensino Primário E Do I Ciclo Nº 118 - Cuango</option>
<option>Escola Do I Ciclo Do Samuamba - Cuango</option>
<option>Escola Primária N. 11 Das Antenas</option>
<option>Escola Primária N. 116 Do Luremo</option>
<option>Escola Primária N. 119 Da Elevação - Nossa</option>
<option>Escola Primária N. 120 Do Mussuco</option>
<option>Escola Primária N. 122 Do Quinguri - Luzamba</option>
<option>Escola Primária N. 123 Hoji-Ya-Henda Do Camarianga</option>
<option>Escola Primária N. 13 - Ebenezer</option>
<option>Escola Primária N. 15 Brilhante Do Amanhã</option>
<option>Escola Primária N. 16 Do Gika</option>