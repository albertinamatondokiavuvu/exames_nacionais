<option>Colégio 1º Agosto</option>
<option>Colégio Comanadante Dangreurex</option>
<option>Colégio Do Sapanguele</option>
<option>Complexo Escolar Mutu-Ya-Kevela</option>
<option>Complexo Escolar Comandante Cow-Boy</option>
<option>Complexo Escolar Da Kalohanga</option>
<option>Complexo Escolar Da Kassanji B</option>
<option>Complexo Escolar Do Chamume</option>
<option>Complexo Escolar Do Saco</option>
<option>Complexo Escolar Juju Da Costa Valério</option>
<option>Complexo Escolar Urbanização Pima</option>
<option>Escola Primária António De Carvalho Bettencourt</option>
<option>Escola De Formação De Professores Bg Nº 3016 Dombe-Grande Baía-Farta</option>
<option>Escola Primária Do Senje Bg Nº 3045 Dombe-Grande Baía-Farta</option>
<option>Escola Primária Da Macaca Bg Nº 3034 -Baía-Farta</option>
<option>Escola Primária Da Tenda Pequena Bg Nº 3036-Baía-Farta</option>
<option>Escola Primária 11 De Novembro</option>
<option>Escola Primária 14 De Abril</option>
<option>Escola Primária 16 De Junho</option>
<option>Escola Primária 22 De Novembro</option>
<option>Escola Primaria 383</option>
<option>Escola Primária 4 De Abril</option>
<option>Escola Primaria 4 De Fevereiro</option>
<option>Escola Primária Boa Lembrança</option>
<option>Escola Primária Comandante Kassanji</option>
<option>Escola Primária Comante Kassanji-A</option>
<option>Escola Primária Da Bandeira</option>
<option>Escola Primária Da Igreja Tocoista</option>
<option>Escola Primária Da Salina</option>
<option>Escola Primária De Chiome</option>
<option>Escola Primária Do Acinde</option>
<option>Escola Primária Do Alto Liro</option>
<option>Escola Primária Do Chicuhum</option>
<option>Escola Primária Do Chiumbua Bg Nº 3042 Dombe-Grande-Baía-Farta</option>
<option>Escola Primária Do Forno</option>
<option>Escola Primária Do Hengue</option>
<option>Escola Primária Do Muhaningo</option>
<option>Escola Primária Do Ndoloma</option>
<option>Escola Primária Dr. António Agostinho Neto</option>
<option>Escola Primária José Marty</option>
<option>Escola Primária Povo Unido</option>
<option>Escola Primaria Urbanização Pima</option>
<option>Escola Prrimária Do Cambongue Inglês Bg Nº 3027 Dombe-Grande Baía-Farta</option>
<option>Instituto Politécnico Da Baía-Farta</option>
<option>Instituto Politécnico Marítimo Pesqueiro</option>
<option>Magistério Primário Santa Ana</option>
<option>Primária 10 De Dezembro</option>
<option>Primária Da Boa Esperança</option>
<option>Primária Do Canto</option>
