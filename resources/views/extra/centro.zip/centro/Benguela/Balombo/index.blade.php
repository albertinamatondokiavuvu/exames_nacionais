<option>Lobito</option>
<option>Bocoio</option>
<option>Balombo</option>
<option>Ganda</option>
<option>Cubal</option>
<option>Caiambambo</option>
<option>Benguela</option>
<option>Baía Farta</option>
<option>Chongoroi</option>
<option>Catumbela</option>












