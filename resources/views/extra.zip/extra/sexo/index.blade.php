<option>Masculino</option>
<option>Femenino</option>