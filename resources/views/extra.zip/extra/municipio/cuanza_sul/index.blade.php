<option>Sumbe</option>
<option>Porto Amboim</option>
<option>Quibala</option>
<option>Libolo</option>
<option>Mussende</option>
<option>Amboim</option>
<option>Ebo</option>
<option>Quilenda</option>
<option>Conda</option>
<option>Seles</option>
<option>Cela</option>
<option>Cassongue</option>
