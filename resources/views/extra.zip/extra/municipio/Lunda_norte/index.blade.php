<option>Cambulo</option>
<option>Chitato</option>
<option>Cuilo</option>
<option>Caungula</option>
<option>Cuango</option>
<option>Lubalo</option>
<option>Capenda Camulemba</option>
<option>Lóvua</option>
<option>Lucapa</option>
<option>Xá Muteba</option>
