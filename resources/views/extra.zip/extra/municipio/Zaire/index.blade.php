<option>Mbanza Kongo</option>
<option>Soyo</option>
<option>Nzeto</option>
<option>Cuimba</option>
<option>Nóqui</option>
<option>Tomboco</option>

