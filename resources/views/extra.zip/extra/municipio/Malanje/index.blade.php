<option>Massango</option>
<option>Marimba</option>
<option>Calandula</option>
<option>Cahombo</option>
<option>Kiwaba Nzoji</option>
<option>Cacuso</option>
<option>Quela</option>
<option>Malanje</option>
<option>Mucari</option>
<option>Cangandala</option>
<option>Cambundi-Catembo</option>
<option>Luquembo</option>
<option>Kunda Dya Baze</option>
<option>Quirima</option>
