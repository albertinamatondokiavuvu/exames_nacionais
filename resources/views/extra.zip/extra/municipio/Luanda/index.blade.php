<option>Belas</option>
<option>Cacuaco</option>
<option>Cazenga</option>
<option>Estrutura Central</option>
<option>Icolo e Bengo</option>
<option>Kilamba Kiaxi</option>
<option>Luanda</option>
<option>Quiçama</option>
<option>Rangel (old)</option>
<option>Talatona</option>
<option>Viana</option>
