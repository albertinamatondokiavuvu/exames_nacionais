<option>Moxico</option>
<option>Camanongue</option>
<option>Léua</option>
<option>Cameia</option>
<option>Luau</option>
<option>Luacano</option>
<option>Alto Zambeze</option>
<option>Luchazes</option>
<option>Bundas</option>

