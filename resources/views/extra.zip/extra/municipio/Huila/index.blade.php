<option>Quilengues</option>
<option>Lubango</option>
<option>Humpata</option>
<option>Chibia</option>
<option>Quipungo</option>
<option>Caluquembe</option>
<option>Caconda</option>
<option>Chicomba</option>
<option>Matala</option>
<option>Jamba</option>
<option>Chipindo</option>
<option>Cuvango</option>
<option>Cacula</option>
<option>Gambos</option>


