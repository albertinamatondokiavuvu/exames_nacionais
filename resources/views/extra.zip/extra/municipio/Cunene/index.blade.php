<option>Cuanhama</option>
<option>Ombadja</option>
<option>Cuvelai</option>
<option>Curoca</option>
<option>Cahama</option>
<option>Namacunde</option>

