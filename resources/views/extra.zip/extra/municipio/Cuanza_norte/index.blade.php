<option>Cazengo</option>
<option>Lucala</option>
<option>Ambaca</option>
<option>Golungo Alto</option>
<option>Cambambe</option>
<option>Quiculungo</option>
<option>Bolongongo</option>
<option>Banga</option>
<option>Samba Cajú</option>
<option>Gonguembo</option>

