<option>Huambo</option>
<option>Londuimbali</option>
<option>Bailundo</option>
<option>Mungo</option>
<option>Chindjenje</option>
<option>Ucuma</option>
<option>Ecunha</option>
<option>Chicala-Choloanga</option>
<option>Cachiungo</option>
<option>Longonjo</option>
<option>Caála</option>

