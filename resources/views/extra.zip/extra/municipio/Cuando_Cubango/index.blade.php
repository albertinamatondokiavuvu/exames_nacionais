<option>Menongue</option>
<option>Cuito Cuanavale</option>
<option>Cuchi</option>
<option>Cuangar</option>
<option>Mavinga</option>
<option>Calai</option>
<option>Dirico</option>
<option>Rivungo</option>
<option>Nancova</option>











