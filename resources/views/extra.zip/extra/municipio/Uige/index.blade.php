<option>Ambuíla</option>
<option>Bembe</option>
<option>Buengas</option>
<option>Bungo</option>
<option>Alto Cauale</option>
<option>Damba</option>
<option>Dange-Quitexe</option>
<option>Maquela do Zombo</option>
<option>Milunga</option>
<option>Mucaba</option>
<option>Negage</option>
<option>Puri</option>
<option>Quimbele</option>
<option>Sanza Pombo</option>
<option>Songo</option>
<option>Uíge</option>

