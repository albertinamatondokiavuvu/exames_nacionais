<option>Camacuio</option>
<option>Bibala</option>
<option>Virei</option>
<option>Tômbwa</option>
<option>Moçâmedes</option>

