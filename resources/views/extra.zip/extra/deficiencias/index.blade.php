<option>Nenhum</option>
<option>Visual</option>
<option>Auditiva</option>