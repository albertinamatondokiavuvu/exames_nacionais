<option>Matemática</option>
<option>Língua Portuguesa</option>
<option>Estudo do Meio</option>
<option>Educação Manual e Plástica</option>
<option>Ciências da Natureza</option>
<option>Educção Moral e Cívica</option>
<option>Geografia</option>
<option>História</option>
<option>Educação Física</option>
