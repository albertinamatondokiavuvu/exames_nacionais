<option>Bengo</option>
<option>Benguela</option>
<option>Bié</option>
<option>Cabinda</option>
<option>Cuando-Cubango</option>
<option>Cunene</option>
<option>Huambo</option>
<option>Huíla</option>
<option>Cuanza Sul</option>
<option>Cuanza Norte</option>
<option>Luanda</option>
<option>Lunda Norte</option>
<option>Lunda Sul</option>
<option>Malanje</option>
<option>Moxico</option>
<option>Namibe</option>
<option>Uíge</option>
<option>Zaire</option>
