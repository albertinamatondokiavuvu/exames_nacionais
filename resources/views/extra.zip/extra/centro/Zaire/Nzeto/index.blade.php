<option>[EQT] ESCOLA PRIMÁRIA N. 174 - MBUEZU</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 285 - KIYEMBE</option>
<option>[EQT] COLÉGIO KITANA</option>
<option>[EQT] COLÉGIO DO KINDEGE - NZETO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 88 - KIDILO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 267 - TOCOÍSTA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 16 - KIMPAXI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 40 - KIMPAXI</option>
<option>[EQT] COLÉGIO KIMPAXI</option>
<option>[EQT] COLÉGIO DO KIBONGA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 261 - MISSÃO CATÓLICA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 139 - BONDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 112 - NSANDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 34 - KITANA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 22 - KIMPAXI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 265 - KIMBANGUISTA</option>
<option>[EQT] LICEU DO NZETO</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO NZETO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 149 - LONGE PEQUENO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 187 - DIADIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 10 - 1 DE MAIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 124 - KIMAKUKU</option>
<option>[EQT] COLÉGIO DA KIBALA DO NORTE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 106 - LOLO MBONDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 04 - KIBONGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 28 - MAMBU-MAMPA</option>
<option>[EQT] COLÉGIO DA MUSSERRA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 144 - MUSSERRA</option>
