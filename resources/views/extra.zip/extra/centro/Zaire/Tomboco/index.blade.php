<option>[EQT] LICEU COMANDANTE NZAZI - TOMBOCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 84 - DIAMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 42 - KINSIMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 24 - VILA</option>
<option>[EQT] COMPLEXO ESCOLAR DO KINSIMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 06 - KIMBENZA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 30 - KIOWA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 120 - KINZAU</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO TOMBOCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 90 - MUCULA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 262 - MISSÃO CATÓLICA -  TOMBOCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 12 - BENGO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 54 - KIAYA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 108 - KINGOMBO</option>
<option>[EQT] COLÉGIO COMANDANTE BULA - TOMBOCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 18 - TAGE</option>
