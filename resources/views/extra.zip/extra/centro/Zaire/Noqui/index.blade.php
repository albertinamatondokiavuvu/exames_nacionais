<option>[EQT] COMPLEXO ESCOLAR N. 35 - VOKE - NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 125 - LUFICO - NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 05 - NÓQUI</option>
<option>[EQT] COLÉGIO DO LUFICO - NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 23 - LUKALA - NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 71 - MPALA</option>
<option>[EQT] LICEU DO NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 294 - KITALA NTIMA - NÓQUI</option>
<option>[EQT] COLÉGIO DO MPALA - NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 89 - NSANZI - NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 77 - TOMBOCO - NÓQUI</option>
<option>[EQT] COMPLEXO ESCOLAR N. 11 - MINGIENGIE - NÓQUI</option>
<option>[EQT] COMPLEXO ESCOLAR N. 17 - NTONGUI - NÓQUI</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO NÓQUI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 150 - MBANZA KIUNGA - NÓQUI</option>
