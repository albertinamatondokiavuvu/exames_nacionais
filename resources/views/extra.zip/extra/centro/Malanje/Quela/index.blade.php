<option>[EQT] DIRECÇÃO  MUNICIPAL DA EDUCAÇÃO DE QUELA</option>
<option>[EQT] COLÉGIO Nº 1 - 4 DE JANEIRO - QUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 4 - CAMBAMBA - QUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 7 - QUELA </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 6 - MUFUMA - QUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 3 - COMANDANTE VALÓDIA - QUELA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE QUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 5 - NGOLA CABILA - QUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 2 - SANTA ISABEL - QUELA</option>
