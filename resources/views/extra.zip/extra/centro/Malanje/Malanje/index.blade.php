<option>[EQT] COMPLEXO ESCOLAR N. 25 - SANTO JERÓNIMO COSME</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 62 - CANGANDO</option>
<option>[EQT] COMPLEXO ESCOLAR N 93 - LUZIA INGLÊS VAN-DUNEM</option>
<option>[EQT] COMPLEXO ESCOLAR N. 198 - BISPO NDOSA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 81 - SÃO PEDRO - I.E.P.A</option>
<option>[EQT] COMPLEXO ESCOLAR N. 95 - REVERENDO FRANCISCO ARMANDO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 112 - MADRE ISABEL LARRAÑGA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 115 - DOM QUIXOTE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 167 - REVERENDO FERREIRA FRANCISCO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 91 - BOM DEUS</option>
<option>[EQT] COMPLEXO ESCOLAR N. 82 - I.E.I.A</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 170 - NOVA GALILEIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 159 - MASSACA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 137 - NAZARÉ 7º DIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 136 - CANAÃ DO 7º DIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. - 7º DIA DE LUZ</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 156 - CAZETA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 139 - COMISSÃO DA CANÂMBUA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 39 - SANTA TERESINHA </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 88 - NOVA JERUSALÉM</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 121 - HAVEMOS DE VOLTAR</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 117 - SÃO PEDRO DA QUIZANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 85 - CALEMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 111 - CAMBONDO DO CUIJI</option>
<option>[EQT] COLÉGIO Nº 1 - AMÍLCAR CABRAL</option>
<option>[EQT] LICEU N. 45 - OSVALDO SERRA VAN-DÚNEM</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 20 - MISSÃO DO QUÉSSUA</option>
<option>[EQT] MAGISTÉRIO SÃO JOÃO PAULO II, Nº 50</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 133 - SÃO FRANCISCO DE ASSIS</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 110 - NOSSA SENHORA DE FÁTIMA - MAXINDE</option>
<option>[EQT] COLÉGIO, Nº 79 - ESPERANÇA DE ÁFRICA</option>
<option>[EQT] LICEU Nº 41 - 4 DE ABRIL</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 114 - NOSSA SENHORA DE FÁTIMA - CATEPA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 172 - TERRA NOVA </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 169 - DAVID NAMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 164 - DIMBA NESSA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 158 - CAMBONDO DO CUIJI</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 129 - COMANDANTE KUENHA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 142 - MÃO AJUDADORA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 90 - KILAMBA KIAXE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 86 - GALILEIA DO 7º DIA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 69 - ESMIRNA DO 7º DIA </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 108 - COMANDANTE GIKA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 141 - CAHALA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 147 - QUIMBAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 176 - CATEPA DA FEIRA</option>
<option>[EQT] COLÉGIO Nº 2 - SAGRADA ESPERANÇA</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 118 - GAIATO</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 35 - MAMÃ MUXIMA</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 12 - ALICE</option>
<option>[EQT] LICEU Nº 42 - 4 DE JANEIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 161 - VULANGOMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 127 - MAJOR KANHANGULO</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 122 - NGOLA KILUANJE</option>
<option>[EQT] INSTITUTO TÉCNICO DE SAÚDE, Nº 55</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 87 - DEOLINDA RODRIGUES </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 71 - KULAMUXITO </option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 135 - RITONDO</option>
<option>[EQT] COLÉGIO, Nº 4 - UANHENGA XITU</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 130 - KUDYELELA</option>
<option>[EQT] COLÉGIO, Nº 125 - NJINGA MBANDE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 177 - SUINGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 173 - SÃO PAULO</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 157 - QUIZANGA DA BARRACA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 98 - PROGRESSO DA PAZ</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 126 - CAMPO DA VICTÓRIA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 120 - CAMOMA</option>
<option>[EQT] COLÉGIO, Nº 8 - 11 DE NOVEMBRO</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 128 - COMANDANTE GIKA 2 – AMIZADE CHINA ANGOLA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 109 - SÃO JOSÉ DE CLUNY</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 150 - CAMBONDO DE MALANJE</option>
<option>[EQT] MED- CURSO BASICO DE FORMACAO DE DOCENTES </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 99 - QUISSACO</option>
<option>[EQT] LICEU Nº 40 - NICOLAU GOMES SPENCER</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 163 - NGOLA LUIJI</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 155 -BUMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 123 - CABUABUATA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 140 - CANZAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 14 - NOSSA SENHORA DE FÁTIMA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 134 - PATRICE LUMUMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 149 - QUIZANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 78 - FILADÉLFIA DO 7º DIA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE MALANJE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 68 - DOM ALEXANDRE DO NASCIMENTO</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 29 - DR. ANTÓNIO AGOSTINHO NETO</option>
<option>[EQT] COLÉGIO, Nº 3 - HOJI YA HENDA - MALANJE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 17 - ESQUADRÃO BOMBOKO </option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 13 - COMANDANTE NZAGE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 94 - MISSIONÁRIA DA VILA MATILDE</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 131 - LAR NAZARÉ</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 144 - NOSSA SENHORA DE GUADALUPE</option>
<option>[EQT] LICEU Nº 44 - EIFFEL</option>
<option>[EQT] COMPLEXO ESCOLAR N. 31 - EBENEZER - MALANJE</option>
<option>[EQT] COLÉGIO, Nº 153 - ADVENTISTA CENTRAL</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 89 - HAVEMOS DE VOLTAR-LAU</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº75 - SAMBIZANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 124 - EDITH ALMEIDA DE SOUSA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 61 - BETEL DO 7º DIA</option>
<option>[EQT] MAGISTÉRIO Nº 48 - JERÓNIMO NETO</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 148 - QUISSOL</option>
<option>[EQT] MAGISTÉRIO Nº 47 - COMANDANTE CUIDADO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 11 - DORI-LOMBE</option>
<option>[EQT] MAGISTÉRIO Nº 49 - SÃO JOSÉ DE CLUNY,</option>
<option>[EQT] COLÉGIO, Nº 5 - DE INICIAÇÃO DESPORTIVA ESCOLAR ANGOLA E CUBA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 74 - COMANDANTE DANGEREUX</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 145 - DA PASSAGEM</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 76 - PIONEIRO ZECA </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 119 - 11 DE NOVEMBRO</option>
<option>[EQT] INSTITUTO TÉCNICO AGRÁRIO DO QUÉSSUA, Nº 51</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 165 - CAMBAXE</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 160 - QUIBINDA</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 27 - SAMORA MACHEL</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 19 - PAZ E AMOR</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 175 - EPISCOPAL AFRICANA (IMEIAS)</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 83 - COMANDANTE VALÓDIA</option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 77 - PALMEIRA  </option>
<option>[EQT] ESCOLA PRIMÁRIA, Nº 132 - MARIA MADALENA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 146 REV. NASCIMENTO DAVID</option>
<option>[EQT] COMPLEXO ESCOLAR, Nº 26 - SAGRADO CORAÇÃO DE JESUS</option>
<option>[EQT] GABINETE PROVINCIAL DA EDUCAÇÃO DE MALANJE</option>
