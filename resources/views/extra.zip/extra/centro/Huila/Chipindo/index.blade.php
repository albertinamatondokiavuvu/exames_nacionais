<option>[EQT] ESCOLA PRIMARIA N. 1434 - SAPI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1435 - UYAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 419 - CAQUELA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1447 - CENTRO CHIMOMA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 420 - SANGUEVE </option>
<option>[EQT] ESCOLA PRIMARIA  N. 1425 - CAPEMBE</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO CHIPINDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1808 - CAMASSISSA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1445 - MISSÃO IECA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1375 - CENTRO ESCOLAR LINO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1371 - CASSEMA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1424 - BULOTEQUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1432 - GUELENGUE </option>
<option>[EQT] ESCOLA PRIMARIA N. 1436 - CHILIVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1439 - CENTRO KAWANGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1427 - CENTRO CATCHUCO </option>
<option>[EQT] COLÉGIO N. 1437 - 22 DE NOVEMBRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1373 - NGUVULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1443 - SAPATO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1438 - BUNJEI </option>
<option>[EQT] ESCOLA PRIMARIA N. 1431 - CANHAWENGA</option>
<option>[EQT] ESCOLA PRIMARIA N. 1782 - 4 DE ABRIL </option>
<option>[EQT] ESCOLA PRIMARIA N. 421 - DOVALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1428 - CHITATA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1381 - KATCHAWA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 406 - NGALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 153</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1365 - BAMBI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1448 - CHILANDA </option>
<option>[EQT] COLÉGIO N. 1288 - CAMBUJEI</option>
<option>[EQT] LICEU N. 1832 - CHIPINDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1442 - SACALOMBO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1366 - BELÉCUA </option>
<option>[EQT] ESCOLA PRIMARIA N. 1429 - DINGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1385 - SONGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1426 - CAPUKA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1591 - CANDUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1430 - 19 DE MARÇO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1440 - CHUVICA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1441 - CHIVANDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1382 - MACONGUE </option>
