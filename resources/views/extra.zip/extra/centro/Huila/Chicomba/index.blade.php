<option>[EQT] ESCOLA PRIMÁRIA N. 677 -  BANGA - YELA</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1240 - CUTUTO BAIXO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 674 - CHICOMBA VELHA </option>
<option>[EQT] ESCOLA PRIMÁRIAN. 1640 -  LIBONGUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 672 - NDALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1201 - SANTANA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1062 - ULOLA WONGUNGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 664 - WAYOLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 911 - TALAMA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 658 - CHIMBALANDONGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 676</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1188 - MUHOLO HANGALO </option>
<option>[EQT] COLEGIO N.1213 - CHEREQUELA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 621 - NGOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 637 - CAMBANJE </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE CHICOMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 880 - 17 DE SETEMBRO </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 675 - CUTENDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 619 - CUCALA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 570 - CABIR REGEDORIA </option>
<option>[EQT] COMPLEXO ESCOLAR  N. 649 - MISSÃO CATÓLICA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 155</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 118 - CABIR COMERCIAL </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 662 - CAPUNGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 605 - BULO SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1644 - CHIVINDA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1156 - CACONGO CAFOIA </option>
<option>[EQT] COLÉGIO N. 684 - CHICOMBA SEDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 601 -  NUNCE </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 589 - CALIONGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1187 - CHITAPUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 643 - LUSSEQUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 644-  CHILUEIO CAPAMBA</option>
<option>[EQT] COMPEXO ESCOLAR N. 1328 - VIHOPIO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1209 - QUÉ </option>
<option>[EQT] LICEU N. 1642</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1585 - CAPUTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 650 - HULO MANICO </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 678 - KM 42</option>
<option>[EQT] COLÉGIO  N. 1643 - CUTENDA SEDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 640 - CAMUPA TCHIPIQUITA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1725 - CANDUNDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1119 -  COTELE BAMBI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 636 - CHICAMBI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1405 - CHAVINDILICA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 635 - NONDUMBO </option>
<option>[EQT] ESCOLA PRIMÁRIAN. 1559 -  NGOTI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 663 - PILIMBIMBI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 654 - CASSENGE - CHINDULULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 679 - BUMBA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 624 - VILA REAL</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 888 - COVONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 258 - I DE JUNHO DILINDINDA </option>
<option>[EQT] ESCOLA PRIMÁRIAN. 577 -  CHIVIMBI </option>
<option>[EQT] ESCOLA PRIMARIA N. 1673 - CHIPUPA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 815 -  MUNQUETE</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 640 - FAZENDA TOMBA</option>
<option>[EQT] COLÉGIO N. 1641 - LIBONGUE</option>
