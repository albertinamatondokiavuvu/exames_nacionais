<option>[EQT] ESCOLA PRIMÁRIA N. 668 - CAHEIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1805 - MATOME II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1376 - CHIVA BAIXO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 938 - CATANHA MAWELEQUESSE  </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 130 - MPHOMBO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 228 - MAMBONDUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1788 - MAMBANDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 44 - KM 100 </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 931 - CALIHENGUA </option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 942 - ECAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 966 - CAVINGOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1046 - CATANHA MBANDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1286 - CASSIMO </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 995 - CAMUCUIO II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 979 - CALONDAU </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 227</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 970 - MAHOLECO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 944 - MACALANGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 977 - CACUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N.940 - CATEPE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 939 -  CATANHA PONTE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 235 - LUCONDO NOMPHALANGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1018 - CAMUCUIO VITE VIVALI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 123 - CAVITCHAPI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 231 - TUNDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 882 - VITI VIVALI SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1418 - VISSASSA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1010 - VIMBAMBA </option>
<option>[EQT] LICEU N. 1706 - DA CACULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1684 - 16 DE AGOSTO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 7</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 994 - VILOLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 989 - NONGONGUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 955 - MUQUETE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 971 - MUNGONGO - A </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 961 - MUHAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1285 - TCHOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 988 - NOSSITE I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1721 - NONJAVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1184 - YAVULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1664 - CAMUCUIO II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 983 - CAVINGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1000</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 128 - MAWENGUE </option>
<option>[EQT] COMPLEXO ESCOLAR  N. 68 - DA VIAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1016 - YELA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 571 - CALOMALANGA RAINHA NANGOMBE </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DA CACULA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 129 - CAVISSI I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 333 - CAÚLE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1255 - MUCAMBA I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 969 - MUNKHUMBI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 976 - MUESSE </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1696 -  TCHICUAQUEIA SEDE</option>
<option>[EQT] COLÉGIO N. 963 - CACULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1005 - MUCONDO I </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 968 - HUPA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 987 - NANGOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 755 - SIMO YOMBIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 991 - TCHICOCOTI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 390 - CAVI POVOAÇÃO </option>
