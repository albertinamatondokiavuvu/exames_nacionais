<option>[EQT] LICEU N. 412 - DR. ANTÓNIO AGOSTINHO NETO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1455 - TCHONGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 383 - TCHIMUHOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 559- VIVO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 795- TAPI </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE QUIPUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1786-  MUCUIO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 629 - MAVINDA II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 335 - CHIVANDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1610-  MUQUEWA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 549 - MÃE MÃE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1459 - LYUMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 599-  CHICONCO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1619 - MUNPHANDA DO OMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1669-  KAWE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 341</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 373 - NOHOTE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 558 - NKHANGA NOHAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 425-  NKHANDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1057 - TCHITUNGUILA KUANZA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 377 - NOSSASSA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 557 - BEMBER TCHINGÃNGÃ </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1667-  KAHOKOLA </option>
<option>[EQT] COLÉGIO N. 414 - QUIPUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 97</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 550 - VIPUATA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1660-  VINDANGALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1081 - SAGRADA ESPERANÇA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1654-  NTHUNTHILUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 565 - TCHIHEIO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1404 - MULHENGUE B</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1710-  SÊNDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1653-  NOMPHETO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1053 - NGUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1666- TUNTUM </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1676-  NTYIMA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 898 - VITETA DA HANDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1607 - CAMUNHANDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 598-  DONDO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1680-  TYIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1670 - TCHITUNGUILA A</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 813- TCHISSELALELO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1679- TCHAWAFILI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1683-  CALUMBILO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 584 - CALEMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 687 - IESA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1720- MANUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 569- CHICUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1693 - MUNGONGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1709-  VINTHIAVA - PIONEIRO ZECA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 580- PEDREIRA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1717-  CATOLOTOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1396 - CAMULEMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1141 - MUCUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 410 - MACOCOMENA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1615 - MUPEMBATI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1070-  MUPALALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 359 - MULHENGUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 685 - DUCUTA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 125 - KANKHOVO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 907 - NOMBINDJI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 416 - TCHISSONDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1713-  BEMBER TCHIMBANGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 555 - HOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1101 - LEONARDO SICUFINDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 594 - EMBALA DO NGUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1652-  NONGALAFA B </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1058 - TCHINDJELO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1712-  BEMBER CAMUMAMÃO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 592-  GENERAL KUNDI PAIHAMA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1715-  CAMBANDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 357 - MAVINDA I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1810 - MASSUMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 556-  MUVONDE </option>
