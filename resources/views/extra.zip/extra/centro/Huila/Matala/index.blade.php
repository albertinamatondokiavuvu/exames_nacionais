<option>[EQT] ESCOLA PRIMÁRIA N. 934 - CAMUCUIO I</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1379 - MACUCO</option>
<option>[EQT] COLÉGIO N. 1272 - 14 DE ABRIL</option>
<option>[EQT] COLÉGIO N. 1329 - MULONDO</option>
<option>[EQT] MAGISTÉRIO N. 1843 - MATALA</option>
<option>[EQT] COLÉGIO N. 623 - IMACULADA CONCEIÇÃO</option>
<option>[EQT] COLÉGIO N. 964 - 4 DE ABRIL </option>
<option>[EQT] MAGISTÉRIO N. 1104 - CIÊNCIAS RELIGIOSAS DE ANGOLA - MATALA</option>
<option>[EQT] COLÉGIO N. 76 - MUKULA MPHINGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 210</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DA MATALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1267 - CALOMBINGA II</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1089 - MEVAYELA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 164 - KUVELAI SEDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1205</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 145 - KAPESSELA I</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1092 - KANGWENGWE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 94</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 860 VISSACA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 736 - VINDONDI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 141 - TCHINHANHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 144 - CAMULEMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1077 - CAHULULU</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 136 - MICOSSE SEDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 892 - KACONDJA </option>
<option>[EQT] ESCOLA PRIMARIA N. 138 - MUQUEQUETE I</option>
<option>[EQT] COMPLEXO ESCOLAR N. 326 - 17 DE SETEMBRO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 915</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 151 - TCHIPOPIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1079 - CAMUCUA</option>
<option>[EQT] ESCOLA: PRIMÁRIA N. 140 - MUCOLA CASTANHEIRA DE PERA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 120</option>
<option>[EQT] COMPLEXO ESCOLAR N. 871 - 17 DE DEZEMBRO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 154 - NGUENDJE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 163 - BENBER NGALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1262 - ALTO MUQUEQUETE KM 9</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1263 - MUQUEQUETE III</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1076 - KILAMBA</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 872 - MUVALE</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1563 - PROJECTO MELICA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 282 - PRODUÇÃO E LUTA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 861 CALUMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1266 - CALHETA NOVA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 436 - KAMUNHANDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 681 - CHIPEIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 142 - MACULUNGUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 322 - LUMANHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1080 - CHELA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1818 - KAVAVA</option>
<option>[EQT] COLÉGIO N. 960 - JOAQUIM KAUVI</option>
<option>[EQT] COLÉGIO N. 959 - 27 DE AGOSTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 430</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 320 - NGUEVEI II</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 143 - TCHIWACUSSE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 148 - TCHIPALANGUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 150 - KALOMBINGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 319 - KAHONGO II</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1268 - CDTE COW BOY</option>
<option>[EQT] ESCOLA PRIMÁRIA  MUKUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1094 - NDJANDJO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1082 - QUITEVE</option>
<option>[EQT] LICEU N. 1068 - MATALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1327 - ALSSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 435 - 1º DE MAIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1280 - KANDJANGUITI III</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1075 - FUFU I</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 133 - FREIXIEL</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1078 - SOMAFEL</option>
