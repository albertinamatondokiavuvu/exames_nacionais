<option>[EQT] LICEU N. 454</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 58 - LUCRÉCIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 451 - TYELA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 449 - LUÍS NUNES </option>
<option>[EQT] ESCOLA PRIMÁRIA LUNDO NONDONGO</option>
<option>[EQT] COLÉGIO Nº 694 - KAPUNDA KAVILONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1140 - NDJONDJO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 92</option>
<option>[EQT] COMPLEXO ESCOLAR N. 70 - EMÍLIO BRÁS </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 951 - TUA B </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 40 - YOBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 863 - MPHITI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 776 - MINGUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 43 - MUKUANDIMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 294 - TYAKAKA </option>
<option>[EQT] COLÉGIO N. 1423</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 167</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 80 - TYITAKA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 512 - NONGOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 667 - MINHANDI KAMPHULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 785 - MUKUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 547 - KATOLOTOTO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 232 - TYIPA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 101 - TYIKOVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 442 - RIO DA HUÍLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 909 - ASSOCIAÇÃO LUFINDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 42 - AMIZADE ANGOLA HOLANDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 833 - KALUMBILO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1298 - MANDUME </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 77 - PE. RYO </option>
<option>[EQT] COLÉGIO N. 457 - COMANDANTE GIKA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 440 - NOLATA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 779 - NOMBUANENO - QUIHITA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 704 - KAMANA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 85 - LUMBALAMBAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 83</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 104 - NONGALAFA </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DA CHIBIA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 91</option>
