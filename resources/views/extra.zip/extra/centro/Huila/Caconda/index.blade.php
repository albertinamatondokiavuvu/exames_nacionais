<option>[EQT] ESCOLA PRIMÁRIA N. 1356 - TCHINSANSA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 303 - LUMINGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1790 - 14 DE ABRIL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1625 - CARINGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1115 - CAISSOME</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1180 - CACOI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1176 - CUPACASSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1287- LONGURI </option>
<option>[EQT] COMPLEXO ESCOLAR N. 935</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1145 - SÃO PAULO</option>
<option>[EQT] LICEU N. 1152 - CACONDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1042 - CANATA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1211- CALUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1034 - CALONAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 930- CATOMBELA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1044 - COMOMA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1194 - MUNGUILA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1144 - LOSSILI</option>
<option>[EQT] COMPLEXO ESCOLAR N. 183</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1229 - NACANDUMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1357- SÃO JOSÉ DE CLUNY </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1348 - PALANCA I</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1055 - CACALO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 952- BANGE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 233 - BAIXO LOSSOLO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1157- CAMASSA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1234 - CALUNGANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1173 - DUMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 9</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 38</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DE CACONDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1178 - BAIXO VIONGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1135 - ALTO KUINAVO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1221- CALOVOMBOLO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1175 - CUPEPELA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 965 - CHINJENJE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1204 - HILA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 433</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 15 - SAHANDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 945 - TCHIWECA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1177- YUMBI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1143 - CASSOCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1232 - BOA VISTA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1183 - BISSAPA</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1346 - CALOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1153 - CALETE</option>
<option>[EQT] CONPLEXO ESCOLAR N. 1344 - MUSSICA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1162 - HOLONGUI</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1632 - CANDUCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1356 -TCHINSÃNSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1047- CAVAVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1151- CHICAMBI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 881- DR. ANTONIO A. NETO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1220 - 4 DE JANEIRO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1281- CANASSI </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1050 - TALAMANGOLO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1167- SANTIAGO II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1166 - CASSEQUE DONDI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1341- CASSENJE I</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1806 - BEMBUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1300 - BANDEIRA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 957- ALTO UABA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1158 - KALUNA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1237- JAMBA - YA - MINA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 937- SÃO MIGUEL DE ARCANJO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1109 - ELIAS LUCIANO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1027- ANTONIO ISAIAS</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1290 - PADRE ERNESTO LECONTH</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1148 - SÃO PEDRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 876 - 11 DE NOVEMBRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1179 - CAMUNGONDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1631- CALOSSUVA</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 947- NOVA MOÇÃO</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1160 - CUE II  CACONDA</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1235 - MIS. CATÓLICA S. PEDRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 885 - COMANDANTE DANGEREUX</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1218 - MUNDINDA</option>
<option>[EQT] COLÉGIO N. 1185 - WABA</option>
<option>[EQT] COLÉGIO N. 1149 - 22 DE NOVEMBRO</option>
