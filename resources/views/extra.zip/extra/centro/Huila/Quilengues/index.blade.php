<option>[EQT] ESCOLA PRIMÁRIA N. 207 - PIRA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 213 - TCHIPANGULA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 178 - MASSONDJO HEPE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 190 - CUTEMBO TCHIMBEU </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 218 - DOROMA CANHAMA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 251 - MUIVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 851 - TCHIPUPA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1813 - CATCHISSANDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1596 - CAMULEMBA BAIXO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 100</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 217 - DOROMA - TCHICUNDJO </option>
<option>[EQT] COMPLEXO ESCOLAR  N. 238 - MISSÃO DA CATALA</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 853 - TCHIVULO JONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1533 - YALA CUSSESSE </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE QUILENGUES</option>
<option>[EQT] LICEU N. 859 - QUILENGUES</option>
<option>[EQT] ESCOLA PRIMÁRIA MUXACA N. 179</option>
<option>[EQT] ESCOLA PRIMARIA N. 253 - QUICUCO </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 240 - VOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 247 - HOLE </option>
<option>[EQT] ESCOLA PRIMÁRIA MUMBA N. 770</option>
<option>[EQT] COLÉGIO N. 908</option>
<option>[EQT] COMPLEXO ESCOLAR N. 245 - DINDE </option>
<option>[EQT] COMPLEXO ESCOLAR N. 236 - CAMÚCUA </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 794 - TCHITAQUI BAIXO</option>
<option>[EQT] COLEGIO N. 225 - CAMULEMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 226 - UKALI MANDJATATA </option>
<option>[EQT] INSTITUTO TÉCNICO DE PECUÁRIA N. 1678 - QUILENGUES </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 254 - TCHALAWA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 822 - UKALI POVOAÇÃO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 212 - MUSSINDJA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1025 -  HECO </option>
<option>[EQT] COMPLEXO ESCOLAR  N. 172 - MULOI I</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 175 - MAYALA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 237</option>
<option>[EQT] COMPLEXO ESCOLAR N. 205 - BONGA QUILENGUES</option>
