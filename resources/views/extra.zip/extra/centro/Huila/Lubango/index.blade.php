<option>[EQT] ESCOLA PRIMÁRIA N. 730 - MATOMBOTI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1734</option>
<option>[EQT] COMPLEXO ESCOLAR N. 875 - NAZARENO SAMUEL MONTEIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 1854 - COSTA DUMBA NUMBI</option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 1855 - DOMINGOS GUSMÃO</option>
<option>[EQT] INSTITUTO POLITÉCNICO Nº 131</option>
<option>[EQT] COLÉGIO Nº 268 -   SEDE</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1849 - PAULA FRASSINETTI</option>
<option>[EQT] COLÉGIO N. 1850</option>
<option>[EQT] ESCOLA PRIMARIA N. 194</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 877 - MITCHOLE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 166 - TCHIKINDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 8 - TCHIMA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 787 - VIHANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 505</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 670 - 19 DE JANEIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 200</option>
<option>[EQT] GABINETE PROVINCIAL DA EDUCAÇÃO DA HUÍLA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 400</option>
<option>[EQT] LICEU N. 1677</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DO LUBANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 109 - CONJENJE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1060 - TCHITUNDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 117 - MUCUIO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 45 - CONVENÇÃO BAPTISTA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 797 - ENSINO ESPECIAL </option>
<option>[EQT] COLÉGIO N. 1778 - 7º DIA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1359 - NAZARIO VITAL</option>
<option>[EQT] COLÉGIO N. 121 - HOTELARIA E TURISMO </option>
<option>[EQT] LICEU N. 792 - LUBANGO</option>
<option>[EQT] MAGISTÉRIO SECUNDÁRIO N. 135  - COMANDANTE LIBERDADE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 98</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 60</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 34 - MAPUTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 33 - RIO NANGOMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 158 - MAMBOTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 752</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 24 - 2 DE MARÇO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1308 - LA SALETTE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1007</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 127 - MUNHINO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 114 - 4 DE ABRIL</option>
<option>[EQT] COLÉGIO N. 1830 - ESTRELA - HUILA</option>
<option>[EQT] COLÉGIO N. 1773 - IESA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 5</option>
<option>[EQT] COMPLEXO ESCOLAR N. 75</option>
<option>[EQT] COLÉGIO N. 1689 - NOSSA SENHORA DE FÁTIMA - NANGULUVE</option>
<option>[EQT] COLÉGIO N. 110 - 27 DE MARÇO</option>
<option>[EQT] COLÉGIO  N. 623 - MISSIONÁRIO CORAÇÃO DE MARIA</option>
<option>[EQT] COLÉGIO N. 1732 - NAMPHANDA</option>
<option>[EQT] COLÉGIO N. 67 - MANDUME </option>
<option>[EQT] MAGISTÉRIO N. 1099 - CIÊNCIAS RELIGIOSAS DE ANGOLA - LUBANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 193</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 873 - TCHALIPONDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 53</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 262 - KATE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 261 - CANHONGOLO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 782 - KATALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 26 - TCHAVOLA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 415</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 215</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 04 - MISSÃO FEMENINA</option>
<option>[EQT] COLÉGIO N. 1777 - ESTRELA D´ALVA</option>
<option>[EQT] COLÉGIO N. 1775 - IECA</option>
<option>[EQT] COLÉGIO N. 1774 -IEPA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1828 - EYVA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1776 - DOM SAMUEL</option>
<option>[EQT] COMPLEXO ESCOLAR N. 458 - CBA2</option>
<option>[EQT] COMPLEXO ESCOLAR N. 706 - 1 DE JUNHO - ADRA</option>
<option>[EQT] COLÉGIO N. 1320 - 14 DE ABRIL</option>
<option>[EQT] MAGISTÉRIO N. 137 - DO NAMBAMBI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 35 - SEDE</option>
<option>[EQT] ESCOLA PRIMARIA N. 1833</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 59</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 879 - POIARES</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1723 - MUHAHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 292</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 160 - TCHIMUCUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 717 - NOMBUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 428 - ERNESTO CHE GUEVARA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 219 - MUTICULA</option>
<option>[EQT] LICEU N. 134 - NAMBAMBI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1116 - BIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 11 -  PEDREIRA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 01 - CANGOLO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1261 - TCHOMBULO</option>
<option>[EQT] COLÉGIO N. 90 - MISSÃO CATÓLICA</option>
<option>[EQT] COLÉGIO N. 811 - 1º DE MAIO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 32 - LUYOVO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 808 - SOS</option>
<option>[EQT] COLÉGIO N. 1245 -  IELA</option>
<option>[EQT] COLÉGIO N. 1771 - NOSSA SRA F. LALULA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 814 - CÁCUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 801 - NTHENDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 51</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 14 - MBANDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 638 - TCHIPALACASSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 63</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1117 - CAMIHOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1013 - MUQUILENGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1199</option>
<option>[EQT] COLÉGIO N. 88 - 16 DE JUNHO</option>
<option>[EQT] COLÉGIO N. 712 - ARTES E OFICIO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 50</option>
<option>[EQT] COMPLEXO ESCOLAR N. 2 - NAMBAMBI</option>
<option>[EQT] COLÉGIO N. 176 - 10 DE DEZEMBRO</option>
<option>[EQT] MAGISTÉRIO N. 181 DA HUÍLA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 370</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 418</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1482 - CEPIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 147 - TAPY</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 371</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 108 - MUALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 107 - NAMPHANDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 105 - VIKENDJI</option>
<option>[EQT] ESCOLA PRIMARIA N. 10</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 115 - CHEM - CHEM</option>
<option>[EQT] COMPLEXO ECOLAR N. 1728 - 4 DE ABRIL</option>
<option>[EQT] COLÉGIO N. 852 - 11 DE NOVEMBRO</option>
<option>[EQT] COLÉGIO N. 1772 - NÚCLEO DE D. FÍSICOS </option>
<option>[EQT] COMPLEXO ESCOLAR N. 805 - VILA PAULA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 705  - 8 DE MARÇO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 99</option>
<option>[EQT] COMPLEXO ESCOLAR N. 116 - IMACULADA CONCEIÇÃO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1792 - MAMÃ MUXIMA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 12</option>
<option>[EQT] COLÉGIO N. 57 - 1º DE DEZEMBRO</option>
<option>[EQT] COLÉGIO N. 1730 - SEDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 369</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 61</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 3 - PADRE C. ESTERMAN</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 29</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1599 </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 771 - HOJI - YA - HENDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 255 - MINDJAMBI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 742 - MUKANKA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 220 - KAPUTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 64 - TCHILEVO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 41 - FIGUEIRA</option>
<option>[EQT] INSTITUTO TÉCNICO DE FORMAÇÃO DE SAÚDE N. 1831</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1002 - CAPEQUE</option>
<option>[EQT] COMPELXO ESCOLAR N. 187</option>
<option>[EQT] COMPLEXO ESCOLAR N. 990 </option>
<option>[EQT] COMPLEXO ESCOLAR N. 48 - IDA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 16 - KWAWA</option>
<option>[EQT] COLÉGIO N. 124 - TÉCNICO PROFISSIONAL DO CFM</option>
<option>[EQT] LICEU N. 257 - DA ARIMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 62</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 340</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1731 - NOSSA SRA ASSUNÇÃO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 55</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1690</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 806 - MUHOLI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 520 - NTHUVILI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 798 - CACULUVAR</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 796 - KM 14</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 208 - TCHIMPACA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 13</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1254 - KEWA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 113</option>
<option>[EQT] COLÉGIO N. 256</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1846 - BOM DEUS</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1841 - MADRE TRINDADE</option>
<option>[EQT] COLÉGIO N. 1701 - BAKHITA</option>
<option>[EQT] COLÉGIO N. 1226 - CANTEIRO DO PEDAGOGO </option>
