<option>[EQT] ESCOLA PRIMÁRIA N. 1528 - POPULAR </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO CUVANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1603 - KAMBOLE </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 767 - KAYOCO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1574 - CUVANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1609 - VICUNGO SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1509 - TYIMPEMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1575 - LINGOMBE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1545 - EMBALA YA NDUMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1491 - KANHANA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1500 - COLUI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1019 - CUVANGO</option>
<option>[EQT] COLÉGIO N. 1554</option>
<option>[EQT] COLÉGIO N. 1485 - LAR</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1600 - TUVULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1530 - ZONA 2 </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1601 - EPOMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1567 - KAPOCO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1538 - MUENE TYIHUAKU </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1551 - ANHARA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1480 - TCHITUNDO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1543 - AUNJE </option>
<option>[EQT] COMPLEXO ESCOLAR N. 763 - KATOCO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1532 - INDUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1503 - NGUMBE TYIVIMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1545 - TYISSOI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1473 - TYIHUNGO II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1550 - TYICUNHO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1476 - KUANDO KATIVA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1583 - 4 DE ABRIL </option>
<option>[EQT] COMPLEXO ESCOLAR N. 132 - MISSÃO </option>
<option>[EQT] COLÉGIO N. 1608</option>
<option>[EQT] COLÉGIO N. 1484</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1542 - TCHISSITO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1752 - KANDJOLE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 926 - MPALANGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1015 - KALINDI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1618 - MIHIMPO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1804 - MUMBA ALDEIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1557 - NDJILANDEMBE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1589 - TYINDJANDJANGUI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1757 - TCHINDOVI </option>
<option>[EQT] LICEU N. 1483 - CUVANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1498 - CALUNDUNGO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1489 - KASSANGUI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1525 - SETE CASA MISSOMBO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1614 - TYUMBA NGOMBE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1510 - TYIHUAKU </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1469 - KAVANDJE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1597 - KATENDA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1807 - KATALA</option>
