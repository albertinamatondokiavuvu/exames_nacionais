<option>[EQT] ESCOLA PRIMÁRIA N. 519 - CATEIA </option>
<option>[EQT] ESCOLA PRIMÁRIA ALEMANHA N.</option>
<option>[EQT] COLÉGIO ELISEU SIMEÃO</option>
<option>[EQT] MAGISTÉRIO N. 1279 - SÃO TIAGO CALUQUEMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 408 - ÚKUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1312 - CATCHISSOME III </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1795 - BOMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1387 - BABAYELA II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 374 - CAMBULUNGU </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 567 - CALONEVA NGOLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 387 - CALOFIUFIU </option>
<option>[EQT] COMPLEXO ESCOLAR N. 447 - VILA BRANCA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 724 - TCHAUNJE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 506 - JOLE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1301 - HAVEMOS DE VOLTAR </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 460 - CHICATULA II</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 363 - CHICATULA CAMOTA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 304 - CUSSUCA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 342 - COMANDANTE CASSANJE</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1265 - CAMUNDA EX. LEPROSARIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1337 - VIONGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 485 - VILEMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1486 - VATO VATO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1305 - TCHITUPI II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 382 - PENIEL </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1392 - CACHILALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 366 - BUPO VIALAVI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1801 - CAMBALA </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1256 - CALEPI II</option>
<option>[EQT] COMPLEXO ESCOLAR N. 325 - VATUCO SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 353 - CACHINIENGUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 522 - CHAVOLA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 498 - GANDO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 446 - TIÃI TIÃI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 375 - CAMUHOLO I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 773 - CALUPELE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 524 - CALOMANDA CHAVOLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 507 - CALOHOMBO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 229 - CAISSACA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1401- CHIVULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1377- MASSOLALI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1277 - CHILUNDA LUPALE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 542 - LUEPANDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 379 - CHICOLE CAMUNDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 497 - CUTUTO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 388 - CUSSESSE PONTE </option>
<option>[EQT] COMPLEXO ESCOLAR N. 264 - CUILO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1296 - ETONGA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 399 - MISSÃO CATÓLICA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 286 - GIRAUL </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 289 - SÃO PEDRO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1331 - TCHITECULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 536 - YUVO SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 307 - WAMBOA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1391- ALTO TCHASSI </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE CALUQUEMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1303 - CALANDA SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 334 - CAFULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 456 - CACHIPIPA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 297 - CUCALA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 199 - ENGOLONGA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 513 - COLA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 279 - CAMUNDA VIONGA </option>
<option>[EQT] COMPLEXO ESCOLAR  N. 502 - CALEPI SEDE</option>
<option>[EQT] COMPLEXO ESCOLAR N. 280 - LOMBA ALTO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 296 - SÃO TIAGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 508 - SAMBONGO </option>
<option>[EQT] INSTITUTO POLITÉCNICO N. 1825 - CALUQUEMBE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 347 - CATALA VATUCO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 269 - WAIA SEDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 270 - HONDEQUE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1276 - CHILUNDA I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1360 - CHAUNJE </option>
<option>[EQT] COLÉGIO N. 1628 - AURÉLIO FIRMINO DOS SANTOS </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1334 - VANDONGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 437 - CATALA CAPELE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 323 - CAFIFI COLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1657 - CUE III </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 339 - CHITULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 924 - CHITONGO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1799 - SIMO </option>
<option>[EQT] MAGISTÉRIO N. 1842 - ABEL PEDRO CALUQUEMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 401- CALUQUEMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 275 - SACALESSO I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 405 - QUELA PONTE </option>
<option>[EQT] INSTITUTO TÉCNICO DE FORMAÇÃO DE SAÚDE N.1283 - CALUQUEMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1270 - CASAS NOVAS HOSPITAL </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1264 - CAMPO DE AVIAÇÃO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1306 - CALONEVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 488 - CAVINGA I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1407 - JAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 528 - CHISSUA II </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1297 - ETUNDA </option>
<option>[EQT] COMPLEXO ESCOLAR N. 331 - CUE I</option>
<option>[EQT] COMPLEXO ESCOLAR N. 1202 - CORNÉLIO JESSE </option>
<option>[EQT] COMPLEXO ESCOLAR N. 511 - CAISSOMBO </option>
<option>[EQT] COLÉGIO N. 1299 - FADÁRIO FAUSTINO MUTECA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 409 - VISSASSA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1384 - VINGALIPI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 260 - SÃO JOSÉ </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 368 - CAPICA I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 517 - CANELUNGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 365 - AMILCAR CABRAL </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 411 - ALTO CHIVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 463 - CALONGULUVE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1292 - 4 DE FEVEREIRO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 295 - CACOMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1049 - CACHIMANO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 737 - COMANDANTE NGONGA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 461 - CHIVULO ALTO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1802 - LUPALE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 482 - EMBALA TCHIVEIO </option>
<option>[EQT] COMPLEXO ESCOLAR N. 317 - DENDE </option>
<option>[EQT] COMPLEXO ESCOLAR N. 1393 - CAMPUENA </option>
