<option>[EQT] ESCOLA PRIMÁRIA KANHANDI I N. 759</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 729 - NDUMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 953 - 21 DE JANEIRO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 749 - 1º DE MAIO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 602 - LUCUNGA C </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 1475 - LIAPUPA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 727- NGANGULA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 343</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 831 - CAPUNDA </option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 832 - CUSSAVA</option>
<option>[EQT] ESCOLA PRIMÁRIA  - MATOME </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 738 - KUANDJA - A </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 743 - KANHANGUE GRANDE </option>
<option>[EQT] COLÉGIO N. 943</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 645 - TCHACAIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 751 - 11 DE NOVEMBRO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 609 - CAMPULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1740 - CAMBISSA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1466 - MBEU </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 633 HOJI - YA - HENDA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1096 - MUTIAPULO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 614 - MALAVI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 810 - LUQUENE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 630 - KASSINGA </option>
<option>[EQT] INSTITUTO POLITÉCNICO N. 1826 - JAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 616 - VALODIA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 765 - POPULAR </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 816 - CANTINAS </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 821 - CANTINAS N. 4 DE ABRIL </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1741 - LIAPECA I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 775 - KILAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 608 - VIHONGUE </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DA JAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 432 - CACOLA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 603 - MORRO I </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 627 - MATOTI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1474 - MUPOPO </option>
<option>[EQT] COLÉGIO N. 1737 -  CASSINGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1736 - NGOSSI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 745 - OPERARIO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 631 - KAHUICA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 827 - KABANAS </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 622 - IRENE KANGUMBE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 28 - LUCUNGA - A </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 417</option>
<option>[EQT] LICEU N. 1477 - JAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 561 - SASSI - A </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 761 - VINCAVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 719 - YAMBO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 722 - BOA ESPERANCA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 625 - CALILILA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 613 - EYELA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 732 - CENTRO ACADÉMICO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 728 - KANHANGUE PEQUENO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 610 - DEOLINDA RODRIGUES </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 823 - CACUNGO-NGUTI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 486 - COLUI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 756 - EX. MEDICO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1738 - NOVA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 735 - KASSONGUE </option>
