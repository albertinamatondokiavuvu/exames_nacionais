<option>[EQT] ESCOLA  PRIMÁRIA Nº 11 CCR-LUIANA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 05 CCR - MUYAU</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO RIVUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 09 - CCR - LUIANA</option>
<option>[EQT] COLÉGIO N. 02 CCR- 28 DE AGOSTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 08 CCR - CHIPUNDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 07 CCR - CHIFUAKO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 03 CCR - SAMATAMO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 12 CCR - NERIQUINHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 01 CCR - RIVUNGO</option>
