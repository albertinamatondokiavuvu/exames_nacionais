<option>[EQT] ESCOLA PRIMÁRIA N. 225 - MUCUSSUEJI</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 79 - MISSÃO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 224 - NGOANA</option>
<option>[EQT] COLEGIO N. 584 - LUAU</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 74- LUAU</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 25 - MARCO 25 </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DO LUAU</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 587- CHISSOMBO</option>
<option>[EQT] COMPEXO ESCOLAR  N. 586 - CHITAZO</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 221 - LUHEMBA</option>
<option>[EQT] COLÉGIO N. 75 LUAU</option>
<option>[EQT] LICEU N. 219- LUAU</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 585 - RETORNADO</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 220 - CANENDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 72 - CHINHEMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 68 - CATOMBI</option>
<option>[EQT] INSTITUTO TÉCNICO AGRÁRIO N. 244 LUAU </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 70 - CHIENA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 60 - KAPANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 227- LUANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 54 - LUAU</option>
