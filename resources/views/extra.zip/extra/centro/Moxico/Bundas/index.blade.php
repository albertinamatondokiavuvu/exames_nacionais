<option>[EQT] ESCOLA PRIMÁRIA N. 417 - LUCULA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 110 - AUGUSTO NGANGULA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 44 - NENGO</option>
<option>[EQT] LICEU N. 123 - BUNDAS</option>
<option>[EQT] COLÉGIO N. 186 - BUNDAS</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 101 - NINDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 117 - MUSSUMA MITETE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 116 - CHIÚME</option>
<option>[EQT] COLÉGIO N. 36 - NINDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 114 - LUTEMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 121 - SESSA</option>
<option>[EQT] COLÉGIO N. 203 - LUTEMBO</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DOS BUNDAS</option>
<option>[EQT] COLÉGIO N. 245 – COMANDANTE NGOLA </option>
<option>[EQT] COLÉGIO N. 204 - LUVUEI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 115 - LUVUEI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 111 - 04 DE ABRIL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 113 - LUANGUINGA</option>
