<option>[EQT] ESCOLA PRIMÁRIA N. 19 </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 25 KAMULEQUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 21 CAMBOA</option>
<option>[EQT] LICEU N. 205 CAMANONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 99 - CAMANONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 248 MUCOLONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 22 CHIUAIA</option>
<option>[EQT] COLÉGIO N. 231 - DR. ANTÓNIO A. NETO - CAMANONGUE </option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE CAMANONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 23 MAZEMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 85 CAMANONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 249 NACAVUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N.19 - KALUNDUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 32 CALIATA</option>
<option>[EQT] ESCOLA PRIMÁRIA  N. 29 SAMBAVO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 34 MUMANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 28 SAPOMBO - VELHO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 27 MUSSERINGINGE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 26 MUAPEZO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 230 CAWEJI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 20 CHINANAMATA</option>
<option>[EQT] COLÉGIO N. 100 - CAMANONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 30 CAMANONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 24 MISSÃO CATÓLICA SANTA ANA</option>
