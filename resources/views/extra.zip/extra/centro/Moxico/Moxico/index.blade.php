<option>[EQT] ESCOLA  PRIMÁRIA N.143 IRMAS TERESIANA</option>
<option>[EQT] ESCOLA DO ENSINO PRIMÁRIO N. 144 - KAPANGO</option>
<option>[EQT] COMPLEXO ESCOLAR DOM BOSCO</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO - MOXICO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 199 - 4 DE FEVEREIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 162 - 4 DE FEVEREIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 141 BAIRRO KWENHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 170  ALTO - LUENA</option>
<option>[EQT] ESCOLA PRIMÁRIA  SANTA MARGARIDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 88  LUCUSSE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 247 - LUCOCUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 151 LUXIA </option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 147 MX</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 147 LUCUSSE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 187 - CATUNGA</option>
<option>[EQT] COLÉGIO N. 178 ALTO - CAMPO</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 94 - MOXICO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 89 - CANGUMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 850 LUCUSSE</option>
<option>[EQT] COMPLEXO ESCOLAR N. 338 - CAMARADA TCHIFUCHI </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 50 VILA LUSO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 182 - SINAI NOVO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 181 POPULAR</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 176 – 1º DE MAIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 174 PASSA - FOME</option>
<option>[EQT] LICEU N.160 - 4 DE FEVEREIRO</option>
<option>[EQT] LICEU N. 157 KAPANGO </option>
<option>[EQT] LICEU 250 11 DE NOVEMBRO</option>
<option>[EQT] COLÉGIO N.159 - BAIRRO KWENHA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 47 - SATCHIFUNGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 180 - KWENHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 51 VILA LUSO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 335 COMANDANTE NGOLA</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 80 - CANGONGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 63 KAPANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 41- B. LUCIVI 1</option>
<option>[EQT] ESCOLA  PRIMÁRIA N. 154 - SACALUMBO</option>
<option>[EQT] COMPLEXO ESCOLAR MARIA AUXILIADORA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 52 MANDEMBUÉ</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 90 B. CALAPO</option>
<option>[EQT] COMPLEXO ESCOLAR  N. 326 ENSINO ESPECIAL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 202 LUCIVI II</option>
<option>[EQT] INSTITUTO POLÍTÉCNICO DE ADMINISTRAÇÃO E GESTÃO DO LUENA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 341 SÃO JOSÉ</option>
<option>[EQT] COLÉGIO N. 156 BAIRRO 4 DE FEVEREIRO</option>
<option>[EQT] COLÉGIO N. 148 SINAI NOVO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 155 MOXICO - VELHO  </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 149 LUPACHI</option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 141 BAIRRO KWENHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 328 PADRE PEDRO LEONARDI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 309 NOSSA SENHORA DE ASSUNÇÃO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 177 - ALTO LUENA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 175 - MANGUXI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 142 B. SOCIAL DA JUVENTUDE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 88 LUCUSSE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 173 - VALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 590 - LUANDO</option>
<option>[EQT] MAGISTERIO 4 DE ABRIL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 200 - CANHENGUE</option>
<option>[EQT] COLÉGIO N. 98 BAIRRO MANDEMBUÉ</option>
<option>[EQT] COLÉGIO N. 97 BAIRRO KAPANGO</option>
<option>[EQT] COLÉGIO N. 95 B. VIEIRA </option>
<option>[EQT] ESCOLA PRIMÁRIA  N.140 MOXICO</option>
<option>[EQT] INSTITUTO TÉCNICO N. 243 - ARTE E OFICIOS - LUENA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 198 ALTO CAMPO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 153 ALTO - LUENA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 280 – KAPANGO</option>
<option>[EQT] COMPELXO ESCOLAR  N.179 BAIRRO TCHIFUCHI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 139 B. KAPANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 172- SINAI NOVO</option>
<option>[EQT] GABINETE PROVINCIAL DE EDUCAÇÃO DO MOXICO</option>
<option>[EQT] COLÉGIO N. 158 SANGONDO</option>
<option>[EQT] INSTITUTO TÉCNICO DE SAÚDE DO MOXICO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 185 - CANGUMBE </option>
<option>[EQT] ESCOLA  PRIMÁRIA N. 135 ALTO -LUENA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 171 - ALTO LUENA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 165 - SACHILOMBO</option>
<option>[EQT] LICEU N.195  ALTO - CAMPO</option>
<option>[EQT] LICEU N. 192 SINAI - NOVO</option>
<option>[EQT] INSTITUTO POLITÉCNICO DO MOXICO N. 96 KAPANGO</option>
<option>[EQT] COLÉGIO N. 92 LUCUSSE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 201 - CAJAMBA</option>
<option>[EQT] COLÉGIO N. 91 BAIRRO SOCIAL DA JUNENTUDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 160 MULANGUELO</option>
<option>[EQT] COMPELXO ESCOLAR  N. 53 - COMANDANTE KWENHA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 183 - ALTO CAMPO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 122 - TCHAFINDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 327 - SINAI VELHO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 247 B. LUCÓCUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 246 - B. LUCHAZE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 241 SANTO AMARO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 64 - ALTO CAMPO</option>
<option>[EQT] COLÉGIO N. 152 ALTO - LUENA</option>
<option>[EQT] COLÉGIO N. 145 - BAIRRO KAPANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 337 – 17 DE SETEMBRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 185 - CANGUMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 333 – SÃO BENTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 184 - SAMALESSO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 169 – SANGONDO</option>
