<option>[EQT] ESCOLA PRIMÁRIA N. 198 LÉUA </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 126 - LÉUA</option>
<option>[EQT] ESCOLA PRIMÁRIA Nº 39 PASSAGEM DE NÍVEL</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO LÉUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 333 DIOCESANA LÉUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 131 NHALINGOMBE</option>
<option>[EQT] COLÉGIO N. 216 LIANGONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N.130 MUAXIAVA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 128 LUCULO</option>
<option>[EQT] COLÉGIO N. 214 LÉUA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 217 - CALUMBALA</option>
<option>[EQT] LICEU N. 215 SEDE FRANCISCO</option>
