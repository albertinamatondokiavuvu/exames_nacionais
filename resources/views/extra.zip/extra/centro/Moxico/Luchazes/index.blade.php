<option>[EQT] ESCOLA PRIMÁRIA N.108 LUCHAZES</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 106 CASSAMBA</option>
<option>[EQT] ESC PRIM N. 103 COMANDANTE NGOLA</option>
<option>[EQT] ESCOLA PRIMÁRIA N.102 LUZI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 199 LUCHAZES</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 104  TEMBUÉ</option>
<option>[EQT] COLÉGIO N. 103 - C.NGOLA</option>
<option>[EQT] LICEU N.109 LUCHAZES</option>
<option>[EQT] ESCOLA PRIMÁRIA MISSIONÁRIA N. 252 - SÃO FILIPE NERI</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DE LUCHAZES</option>
