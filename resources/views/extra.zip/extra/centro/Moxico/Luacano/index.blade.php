<option>[EQT] ESCOLA PRIMÁRIA N. 56 - LAGO DILOLO CDAT LUMBUMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 48 - LUACANO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 213 - LUACANO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 61 - CAXITA</option>
<option>[EQT] DIRECCAO MUNICIPAL DE EDUCACAO DO LUACANO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 59 - 1º DE MAIO</option>
<option>[EQT] COLÉGIO N. 210 - 4 DE ABRIL/LUACANO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 589 - CAIFUCHE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 588 - 17 DE SETEMBRO</option>
<option>[EQT] COLEGIO N. 212 LAGO DILOLO</option>
<option>[EQT] LICEU N. 42 LUACANO</option>
