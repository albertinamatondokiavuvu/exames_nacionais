<option>[EQT] COLEGIO N. 227 - ALTO ZAMBEZE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 562 - LÓVUA</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 13 - ALTO ZAMBEZE</option>
<option>[EQT] COMPLEXO ESCOLAR N. 236 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 17- ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 539 - ALTO ZAMBEZE</option>
<option>[EQT] COLÉGIO  N. 229 - ALTO ZAMBEZE </option>
<option>[EQT] ESCOLA PRIMÁRIO N. 234 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 592 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 573 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N.  532 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 538 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 238 - ALTO ZAMBEZE</option>
<option>[EQT] LICEU N. 07  ALTO - ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 5 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 569 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 6- ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 292 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 12 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 235 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 529 - ALTO ZAMBEZE</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DE EDUCAÇÃO DO ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 594 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 237- ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 18 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 536 - ALTO ZAMBEZE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 3  ALTO ZAMBEZE </option>
<option>[EQT] ESCOLA PRIMÁRIO N. 2 - ALTO ZAMBEZE </option>
<option>[EQT] COLÉGIO N. 579 - 22 DE NOVEMBRO - CAZOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 191- ALTO ZAMBEZE</option>
