<option>[EQT] COLÉGIO N. 42 REGEDOR CASSAGE</option>
<option>[EQT] COLÉGIO N. 39 SAICAXILO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 43 KHONDE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 41 BANDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 40 MUATXIAVA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 38 CDTE DANGEREAUX</option>
<option>[EQT] COMPLEXO ESCOLAR N. 37 RAIMUNDO LOLOJI</option>
<option>[EQT] ESCOLA PRIMÁRIA MOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 7 LUACHIMO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 15 CAZOA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 21 BIÚLA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 5 NAKATHENGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 12 MISSÃO DE LUZ</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 34 NHAMBACA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 25 LUMA CASSAI</option>
<option>[EQT] MAGISTÉRIO N. 36 16 DE AGOSTO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 33 NICOLAU GOMES SPENCER</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO DALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 1 ANGOLA CUBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 28 MISSÃO IEIA</option>
<option>[EQT] MAGISTÉRIO ADPP DA LUNDA - SUL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 23 CHICUZA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 3 MISSÃO CATÓLICA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 9 LUELE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 18 11 DE NOVEMBRO</option>
<option>[EQT] COLÉGIO N. 35 14 DE ABRIL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 31 NGUA</option>
