<option>[EQT] ESCOLA PRIMÁRIA DE MB.NDAMBA N. 55</option>
<option>[EQT] ESCOLA PRIMÁRIA DE BIQUESSO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE LULA</option>
<option>[EQT] ESCOLA PRIMÁRIA S.PAULO</option>
<option>[EQT] COLÉGIO QUIMUSSECO N. 062</option>
<option>[EQT] COLÉGIO QUIMONGO N. 059</option>
<option>[EQT] COLÉGIO N. 69 MASSAU</option>
<option>[EQT] ESCOLA PRIMÁRIA NGUVO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE VILA - NOVA </option>
<option>[EQT] ESCOLA PRIMÁRIA DE SANTA - NORTE N. 014</option>
<option>[EQT] ESCOLA PRIMÁRIA QUISSOSSO</option>
<option>[EQT] ESCOLA PRIMÁRIA QUINDAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA QUINDACA</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIMBUBI N. 003</option>
<option>[EQT] COLÉGIO MBEMBE N. 060</option>
<option>[EQT] ESCOLA PRIMÁRIA DE SINTRA (A)</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 31 QUIMUSSECO</option>
<option>[EQT] LICEU DE MASSAU N. 61</option>
<option>[EQT] COLÉGIO DE MACOLO N. 064</option>
<option>[EQT] ESCOLA PRIMÁRIA 357 DE MACOCOLA</option>
<option>[EQT] ESCOLA PRIMÁRIA ENCONTRO</option>
<option>[EQT] ESCOLA PRIMÁRIA BRAGA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE BOM - JESUS N. 011</option>
<option>[EQT] ESCOLA PRIMÁRIA QUISSANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA QUINZEVO</option>
<option>[EQT] ESCOLA PRIMÁRIA SINTRA (B)</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIMUANZA N. 021</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIMONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MAZANGAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MAFUANI </option>
<option>[EQT] ESCOLA PRIMÁRIA QUIBENGUI N. 008</option>
<option>[EQT] ESCOLA PRIMÁRIA TENGO N. 029</option>
<option>[EQT] ESCOLA PRIMÁRIA QUILONDA N. 34</option>
<option>[EQT] ESCOLA PRIMÁRIA MATURI</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIMUCUENO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE CAMUNGO N. 047</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 01</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIMBUANGI</option>
<option>[EQT] ESCOLA PRIMÁRIA VIANA N. 024</option>
<option>[EQT] COLÉGIO QUIMUCUENO N. 066</option>
<option>[EQT] COLÉGIO QUISSANGO N. 063</option>
<option>[EQT] LICEU DE MACOLO - MILUNGA N. 068</option>
<option>[EQT] ESCOLA PRIMÁRIA DE SANTO - ANTÓNIO N. 046</option>
<option>[EQT] ESCOLA PRIMÁRIA DE QUIZASSALA</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIVUNDA N. 036</option>
<option>[EQT] LICEU DE MILUNGA N. 57</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MANDAMBA </option>
<option>[EQT] ESCOLA PRIMÁRIA QUIBENGUI TECA</option>
<option>[EQT] ESCOLA PRIMÁRIA MACOLO N. 39</option>
<option>[EQT] ESCOLA PRIMÁRIA MANGUMBO N. 030</option>
<option>[EQT] ESCOLA PRIMÁRIA MUGINGA N. 019</option>
<option>[EQT] COLÉGIO DE MACOCOLA N. 058</option>
<option>[EQT] ESCOLA PRIMÁRIA DE QUITECA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE QUISSACO N. 54</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE MILUNGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 27 QUIMBUCO</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIMUCANDI N. 042</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MARIOCO</option>
<option>[EQT] COLÉGIO DE MILUNGA N. 067</option>
<option>[EQT] ESCOLA PRIMÁRIA QUICUBIXI N. 017</option>
<option>[EQT] ESCOLA PRIMÁRIA MORRO N. 018</option>
<option>[EQT] ESCOLA PRIMÁRIA KIKUA N. 049</option>
<option>[EQT] COLÉGIO QUIMBUANGE N. 065</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TSAMBA NDELEZI </option>
<option>[EQT] ESCOLA PRIMÁRIA QUINDALA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE QUISSEQUELE </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 26 MASSAU</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MBEMBE N. 71</option>
