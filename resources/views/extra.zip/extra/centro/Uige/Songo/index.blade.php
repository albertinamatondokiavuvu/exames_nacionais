<option>[EQT] ESCOLA PRIMÁRIA DO KIVUENGA</option>
<option>[EQT] LICEU DO KIMALALO</option>
<option>[EQT] LICEU DO KIVUENGA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO NDUNDA</option>
<option>[EQT] COLÉGIO DO KIMALALO</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO SONGO</option>
<option>[EQT] LICEU DO SONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA DO MACALE</option>
<option>[EQT] ESCOLA PRIMÁRIA DO DENGA</option>
<option>[EQT] ESCOLA PRIMÁRIA 117 DE AUGUSTO NGANGUNLA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO 1º DE MAIO DO SONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA DO ZULOMONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA QUIANGALA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO MBAU II</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KIRIAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO DEMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KIMUSSUNGO</option>
<option>[EQT] ESCOLA PRIMÁRIA DO BANZA LUANDA II</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KINGONGA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KIFUATA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO TOCOISTA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KITALA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 662 DO TEMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KINIOMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO PENDA</option>
<option>[EQT] ESCOLA PRIMÁRIA 305 DIBALA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO 4 DE FEVEREIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE GOMBE</option>
<option>[EQT] COLÉGIO DO KIVUENGA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KIMALALO</option>
<option>[EQT] ESCOLA PRIMÁRIA DO CAVUNGA</option>
<option>[EQT] ESCOLA PRIMÁRIA DO KICUVA</option>
<option>[EQT] ESCOLA PRIMÁRIA 279 QUIBALA</option>
<option>[EQT] COLÉGIO DO SONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA DO MBANZA LUANDA Iº</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIMINONGO</option>
<option>[EQT] ESCOLA PRIMÁRIA 299 QUIPUMBA LOÉ</option>
<option>[EQT] ESCOLA PRIMÁRIA DO BANZA LENDI</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIMACUNA</option>
<option>[EQT] ESCOLA PRIMÁRIA 280 POMBO</option>
