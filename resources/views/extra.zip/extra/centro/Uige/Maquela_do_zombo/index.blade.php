<option>[EQT] COLÉGIO DE KIMBUALAU</option>
<option>[EQT] LICEU DE KIBOCOLO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE NGUABI</option>
<option>[EQT] ESCOLA PRIMÁRIA LUNKULO PEDRO</option>
<option>[EQT] ESCOLA PRIMÁRIA MISSÃO CATÓLICA</option>
<option>[EQT] COLÉGIO DE KINGALA</option>
<option>[EQT] COLÉGIO DE KIMBATA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE NKASU</option>
<option>[EQT] ESCOLA PRIMÁRIA DE AUGUSTO NGANGULA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MASSEQUE</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIMBATA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINKUNGA</option>
<option>[EQT] LICEU DE SACANDICA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIPAXE</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINGALA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KITALA</option>
<option>[EQT] COLÉGIO DO BÉU</option>
<option>[EQT] COLÉGIO DE CUILO FUTA</option>
<option>[EQT] COMPLEXO ESCOLAR SANTO ANTÓNIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 144 DE NDOMBA TADILA</option>
<option>[EQT] ESCOLA PRIMÁRIA KITURI</option>
<option>[EQT] LICEU DE MAQUELA DO ZOMBO</option>
<option>[EQT] LICEU DO BÉU</option>
<option>[EQT] ESCOLA PRIMÁRIA 4 DE FEVEREIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE SOLE</option>
<option>[EQT] ESCOLA PRIMÁRIA MPASSA PALAVALA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE METIAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINZAU</option>
<option>[EQT] ESCOLA PRIMÁRIA KIMBUALAU</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KOMBO</option>
<option>[EQT] COLÉGIO SACANDICA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINSUKA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 27 DE LUKOLO</option>
<option>[EQT] ESCOLA PRIMÁRIA CUXIMANA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINHETA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE VALÓDIA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINTINO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIDIA</option>
<option>[EQT] ESCOLA PRIMÁRIA SACANDICA</option>
<option>[EQT] ESCOLA PRIMÁRIA NSAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINDOMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA DE BENGA</option>
<option>[EQT] ESCOLA PRIMÁRIA BACA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE MAQUELA DO ZOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINFUIDI</option>
<option>[EQT] ESCOLA PRIMÁRIA DE VUANDABA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 121 DE TAIA</option>
<option>[EQT] ESCOLA PRIMÁRIA COMANDANTE GIKA</option>
<option>[EQT] COMPLEXO ESCOLAR IEBA - KINTINO</option>
<option>[EQT] LICEU DO CUILO FUTA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINGUNDO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIMUINZA NZADI</option>
<option>[EQT] ESCOLA PRIMÁRIA NOVA APOSTÓLICA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE PUMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA BÉU</option>
<option>[EQT] ESCOLA PRIMÁRIA MISSÃO IEBA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINLAU</option>
<option>[EQT] COLÉGIO 4 DE FEVEREIRO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 03</option>
<option>[EQT] ESCOLA PRIMÁRIA DO CUILO FUTA</option>
<option>[EQT] ESCOLA PRIMÁRIA EXÉRCITO DE SALVAÇÃO</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KINDUNDA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KIVEMBA</option>
<option>[EQT] COLÉGIO DO KIBOKOLO</option>
