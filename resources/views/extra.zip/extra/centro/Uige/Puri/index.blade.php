<option>[EQT] ESCOLA PRIMÁRIA N. 612 DO 1º MAIO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 592 QUIBABA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 588 QUIMALUNDO</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 609 - QUINVUTA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 606 Q. LULOVO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 599 QUIFUTILA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 590 QUISSASSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 359 DO PÚRI</option>
<option>[EQT] LICEU DO PURI</option>
<option>[EQT] COLÉGIO DO PÚRI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 595 VISTA ALEGRE</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 578 - BENDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 616 CALUMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 586 QUIMBUNGALAU</option>
<option>[EQT] ESCOLA PRIMÁRIA 579 - QUISSEQUE BENDO</option>
<option>[EQT] ESCOLA PRIMÁRIO N. 577 - QUIMUSSANDI</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO PÚRI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 610 - MALUNDO CASSUMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA 613 ZUNGA</option>
<option>[EQT] ESCOLA PRIMÁRIA SÃO FRANCISCO XAVIER</option>
<option>[EQT] COMPLEXO ESCOLAR MADRE PÁSCOA SANDRINI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 607 BENGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 603 QUIZEMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 583 QUIMZAMBI</option>
<option>[EQT] ESCOLA PRIMÁRIA 11 DE NOVEMBRO DO PÚRI</option>
<option>[EQT] ESCOLA PRIMÁRIO DO QUILAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 617 QUINGOZOLO</option>
