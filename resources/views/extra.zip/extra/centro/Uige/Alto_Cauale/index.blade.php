<option>[EQT] COLÉGIO N. 031 SOBA NZAGE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 018 MARINDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 015 QUINDAMBA</option>
<option>[EQT] COLÉGIO N. 030 ZINGA ZULO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 7 HOJI - YA - HENDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 6 QUIZAÚCA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 4 SÃO JOÃO QUIANGA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 10 QUINGUZO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 023 QUIQUELA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 11 BASSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 021 MIGUEL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 019 TEMA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 022 KAKA LUITI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 020 ALTO CAUALE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 014 QUISSARI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 025 TANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 026 TANGAMO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 028 DUMBE - YANGULO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 2 CUMBISSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 01 DE CANGOLA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DE CANGOLA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 017 QUIMBUNGA MUZOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 05 CAÚCA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 8 QUILENDUCA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 027 CAUESSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 013 CAIONGO</option>
<option>[EQT] COLÉGIO DE ALTO CAUALE N. 029</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 033 - CAIOMBO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 3 UEMITA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 024 BENGO </option>
<option>[EQT] ESCOLA PRIMÁRIA N. 016 QUIOCULO</option>
<option>[EQT] LICEU DE ALTO CAUALE N. 032</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 12 DANDE - GUIRRI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 9 GUNZA</option>
