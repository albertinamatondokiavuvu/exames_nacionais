<option>[EQT] ESCOLA PRIMÁRIA N. 103 - MUACHIMBUNDO - 1</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 113 - SAUATXIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 99 - TXICOCA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 109 - NAMESSO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 104 - CANGUINDO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 102 - CAMBA - NGUINZA</option>
<option>[EQT] COLÉGIO N. 114 - 17 DE SETEMBRO - CUILO</option>
<option>[EQT] LICEU DO CUÍLO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 101 - MUAMULOMBE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 100 DO CUÍLO - VELHO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 115 - 14 DE ABRIL</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 97 - CALUANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 116 - MUAMONGUE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 111 - CASSASSA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 108 - SALUCUNDA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 98 - CAMONO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 105 - SACAQUEMA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO CUILO</option>
<option>[EQT] COLÉGIO 4 DE FEVEREIRO - CALUANGO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 106 - SEDE</option>
