<option>[EQT] ESCOLA PRIMÁRIA DO NGANGULA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 227 - CALUATA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 215 - QUELELE</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 195 - CAPOIA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 150 - CALOLA</option>
<option>[EQT] ESCOLA PRIMÁRIA MUXI</option>
<option>[EQT] COMPLEXO ESCOLAR CDTE CELESTINO TXIZAINGA DO MUVULENGE</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO LUBALO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 158 - SALUIMBI</option>
<option>[EQT] LICEU DO LUBALO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 222 SAITARI</option>
<option>[EQT] ESCOLA PRIMÁRIA CAINGA</option>
<option>[EQT] COLÉGIO 4 ABRIL N. 229</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 220 - CAMBA - QUEJI</option>
<option>[EQT] COMPLEXO ESCOLAR 17 DE SETEMBRO DO LUANGUE</option>
