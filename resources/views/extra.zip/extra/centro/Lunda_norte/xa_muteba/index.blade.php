<option>[EQT] ESCOLA PRIMÁRIA N. 90 - MULO</option>
<option>[EQT] COMPLEXO ESCOLAR N. 98 DOMINGOS VAZ</option>
<option>[EQT] COMPLEXO ESCOLAR N. 86 XÁ - MUTEBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 97 - SÃO PAULO</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 89 - KITAMBA - KIA - KETA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 92 C. CALUCALA</option>
<option>[EQT] COMPLEXO ESCOLAR N. 83 DO SAMBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 82 MONGUA QUINGURI</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 80 - XÁ - MUTEBA</option>
<option>[EQT] ESCOLA PRIMÁRIA N. 94 BOTE</option>
<option>[EQT] MAGISTÉRIO DO XÁ - MUTEBA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO</option>
<option>[EQT] COMPLEXO ESCOLAR 4 DE FEVEREIRO - QUIMBULAGE</option>
