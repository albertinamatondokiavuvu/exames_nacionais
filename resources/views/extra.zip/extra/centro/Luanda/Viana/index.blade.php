<option>Colégio N. 5026 - 500 Casas - Viana</option>
<option>Colégio N. 5030 - Regedoria - Viana</option>
<option>Colégio N. 5037 - P.C.V Loy - Viana</option>
<option>Colégio N. 5061 - Caop A - Viana</option>
<option>Colégio N. 5071 - Viana</option>
<option>Colégio N. 5085 - Zango Ii - Viana</option>
<option>Colégio N. 5093 - Boa Fé - Viana</option>
<option>Colégio N. 5095 - Zango I - Viana</option>
<option>Colégio N. 5113 - Viana</option>
<option>Colégio N. 5124 - Viana</option>
<option>Colégio N. 5131 - Zango 3 - Viana</option>
<option>Complexo Escolar N. 5005 - Caop A - Viana</option> 
<option>Complexo Escolar N. 5007 - Regedoria - Viana</option>
<option>Complexo Escolar N. 5009 - Km9 A - Viana</option>
<option>Complexo Escolar N. 5011 - Zango III</option>
<option>Complexo Escolar N. 5012 - Calumbo - Viana</option>
<option>Complexo Escolar N. 5016 - Viana</option>
<option>Complexo Escolar N. 5018 - Viana</option>
<option>Complexo Escolar N. 5019 - Km14 B - Viana</option>
<option>Complexo Escolar N. 5022 - Viana</option>
<option>Complexo Escolar N. 5024 - Viana</option>
<option>Complexo Escolar N. 5025 - Bita Progresso - Viana</option>
<option>Complexo Escolar N. 5029 - Km30 - Viana</option>
<option>Complexo Escolar N. 5033 - Zango I - Viana</option>
<option>Complexo Escolar N. 5050 - Km 14 A - Viana</option>
<option>Complexo Escolar N. 5054 - Km9 A - Viana</option>
<option>Complexo Escolar N. 5055 Teresianas - Viana</option>
<option>Complexo Escolar N. 5056 Escolinha Da Paz - Viana</option>
<option>Complexo Escolar N. 5057 Sagrado C. De Jesus - Viana</option>
<option>Complexo Escolar N. 5059 - Km 14 A - Viana</option>
<option>Complexo Escolar N. 5060 - Iera Viana</option>
<option>Complexo Escolar N. 5062 - I.Ec.A. - Km 14 B - Viana</option>
<option>Complexo Escolar N. 5064 - Km9 A - Viana</option>
<option>Complexo Escolar N. 5068 - Elbenezer</option>
<option>Complexo Escolar N. 5070 - General Ngueto</option>
<option>Complexo Escolar N. 5074 Pequeno Principe - Viana</option>
<option>Complexo Escolar N. 5076 Viana</option>
<option>Complexo Escolar N. 5078 - Km14 B - Viana</option>
<option>Complexo Escolar N. 5079 - Km9 A - Viana</option>
<option>Complexo Escolar N. 5080 Boa Fé </option>
<option>Complexo Escolar N. 5081 - Regedoria - Viana</option>
<option>Complexo Escolar N. 5084 - Viana</option>
<option>Complexo Escolar N. 5086 11 De Novembro - Km9 A - Viana</option>
<option>Complexo Escolar N. 5087 Beata Liduina - Mulenvos - Viana</option>
<option>Complexo Escolar N. 5089 - Viana</option>
<option>Complexo Escolar N. 5092 - Capalanga - Viana</option>
<option>Complexo Escolar N. 5105 - Viana</option>
<option>Complexo Escolar N. 5107 - Viana</option>
<option>Complexo Escolar N. 5110 - Santa Maria De Guadalupe - Viana</option>
<option>Complexo Escolar N. 5120 - Viana</option>
<option>Complexo Escolar N. 5121 Beata Ana Mª Javouhei</option>
<option>Complexo Escolar N. 5123 - Monte Hermon</option>
<option>Complexo Escolar N. 5129 Centro Betania</option>
<option>Complexo Escolar N. 5136 - Zango 4</option>
<option>Direcção Municipal De Educação De Viana</option>
<option>Direcção Municipal De Educação De Viana Segurança</option>
<option>Escola Do Ensino Primário Nº 5042 - Capalanga - Viana</option> 
<option>Escola Do Ensino Primario Nº 5117 Ambiental - Viana</option> 
<option>Escola Do Ensino Primario Nº5097 - Viana</option> 
<option>Escola Do Ensino Primário Nr 5042 - Capalanga - Viana</option> 
<option>Escola Do Ensino Primario, I E Ii Ciclo Nº 5088 Amor De Deus- Km14 B - Viana</option> 
<option>Escola Ens.Geral N.º 961 - Viana</option> 
<option>Escola Primária E I Ciclo Nº 2019 - Belas</option>
<option>Escola Primária E I Ciclo Nº 2073 - Belas</option>
<option>Escola Primaria E Iº Ciclo Nº 5122 - Viana</option>
<option>Escola Primária N. 5001 - Viana</option>
<option>Escola Primária N. 5003 - Cdt. Paiva - Viana</option>
<option>Escola Primária N. 5004 24 De Outubro - Viana</option>
<option>Escola Primária N. 5006 - Regedoria - Viana</option>
<option>Escola Primária N. 5008 - Km 12 A - Viana</option>
<option>Escola Primária N. 5010 - Km30 - Viana</option>
<option>Escola Primária N. 5013 - Cassaca - Calumbo - Viana</option>
<option>Escola Primária N. 5014 - Mateia Calumbo - Viana</option>
<option>Escola Primária N. 5015 - Viana</option>
<option>Escola Primária N. 5017 - Km12 B - Viana</option>
<option>Escola Primária N. 5020 - - Viana</option>
<option>Escola Primária N. 5021 - Rei Mandume</option>
<option>Escola Primária N. 5023 Km12 B - Viana</option>
<option>Escola Primária N. 5027 Norma Victor Lanvo - Viana</option>
<option>Escola Primária N. 5028 - Caop A - Viana</option>
<option>Escola Primária N. 5031 - Vai Volta Km30 - Viana</option>
<option>Escola Primária N. 5032 - Viana</option>
<option>Escola Primária N. 5034 - Km9 B - Viana</option>
<option>Escola Primária N. 5035 - Kikuxi - Viana</option>
<option>Escola Primária N. 5036 - Mussende - Viana</option>
<option>Escola Primária N. 5038 - Caquila Calumbo - Viana</option>
<option>Escola Primária N. 5039 - 4 De Abril - Viana</option>
<option>Escola Primária N. 5040 - Kikuxi 2 - Viana</option>
<option>Escola Primária N. 5041 - Caop B - Viana</option>
<option>Escola Primária N. 5043 - Mulenvo - Viana</option>
<option>Escola Primária N. 5044 - Km40 - Calumbo - Zango Iv - Viana</option>
<option>Escola Primária N. 5045 - Caop - Viana</option>
<option>Escola Primária N. 5046 - Viana II Rainha Nhacatolo</option>
<option>Escola Primária N. 5047 - Km30 Dimba - Viana</option>
<option>Escola Primária N. 5048 Calumbo - Viana</option>
<option>Escola Primária N. 5049 - Caop B - Viana</option>
<option>Escola Primária N. 5051 - Zango Ii - Viana</option>
<option>Escola Primária N. 5052 - Capalanga - Viana</option>
<option>Escola Primária N. 5053 - Morro Da Areia - Viana</option>
<option>Escola Primária N. 5058 - Regedoria - Viana</option>
<option>Escola Primária N. 5063 - Caop A - Viana</option>
<option>Escola Primária N. 5065 - 500 Casas - Viana</option>
<option>Escola Primária N. 5066 - Boa - Fé - Viana</option>
<option>Escola Primária N. 5067 - Km9 A - Viana</option>
<option>Escola Primária N. 5069 - Boa - Fé - Viana</option>
<option>Escola Primária N. 5072 - Horizonte Azul - Viana</option>
<option>Escola Primária N. 5073 - Km9 B - Viana</option>
<option>Escola Primária N. 5075 - Viana</option>
<option>Escola Primária N. 5077 - Km40 Zango Iv - Viana</option>
<option>Escola Primária N. 5082 - Mbanza Calumbo - Viana</option>
<option>Escola Primária N. 5083 - Calumbo - Viana</option>
<option>Escola Primária N. 5090 - Viana</option>
<option>Escola Primária N. 5091 - Caop B - Viana</option>
<option>Escola Primária N. 5096 - Capalanga - Viana</option>
<option>Escola Primária N. 5097 Ana Nguengue - Calumbo - Viana</option>
<option>Escola Primária N. 5098 - Regedoria - Viana</option>
<option>Escola Primária N. 5100 - Km30 - Viana</option>
<option>Escola Primária N. 5102 - Viana</option>
<option>Escola Primária N. 5115 - Viana</option>
<option>Escola Primária N. 5117 - Papa Francisco - Viana - Zango III</option>
<option>Escola Primária N. 5118 - Viana</option>
<option>Escola Primária N. 5119 - Capalanga - Viana</option>
<option>Escola Primária N. 5132 - Zango 4</option>
<option>Escola Primária N. 5133 - Zango Iv</option>
<option>Escola Primária N. 5139 - Viana</option>
<option>Escola Primária N. 5140</option>
<option>Escola Primaria Nº 2056 - Belas </option>
<option>Escola Primario Nº 2055 - Belas</option>
<option>Liceu N. 5135 - Zango Iv Viana</option>
<option>Colégio N. 5108 - Viana</option>
<option>Colégio N. 5111 - Viana</option>
<option>Complexo Escolar N. 5109 - Viana</option>
<option>Escola De Formação De Técnicos Da Saúde Do Kilamba 2010</option>
<option>Escola Do Ensino Primário Nº 5139Zango</option>
<option>Escola Do I Ciclo Nº 5105 Calumbo - Viana</option>
<option>Escola Do I Ciclo Nº 5113 - Viana</option>
<option>Escola Do I Ciclo Nº 8047 Ex 1256Zango</option>
<option>Escola Primária E I Ciclo Do Sec.Nº4099-Bened.Sta Escolática</option>
<option>Escola Primária E Iº Ciclo Do Ensino Secundário Nº 4074 - Cacuaco </option> 
<option>Instituto Politécnico De Adm E Serviço N. 5144 - Zango</option>
<option>Instituto Técnico De Saúde Nº 3119 Kalawenda.</option>
<option>Liceu N. 5104 - Joao Beirao - Viana</option>
<option>Liceu N. 5112 - Viana</option>
<option>Liceu N. 5114 - Viana</option>
