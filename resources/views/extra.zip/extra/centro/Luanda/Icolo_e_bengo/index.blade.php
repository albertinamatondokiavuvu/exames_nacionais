<option>Complexo Escolar N. 6001 - Gaspar De Almeida</option>
<option>Complexo Escolar N. 6002 - Dungo</option>
<option>Complexo Escolar N. 6003 - Calumbuze</option>
<option>Complexo Escolar N. 6010 - Mazozo</option>
<option>Complexo Escolar N. 6011 - Bairro Augusto</option>
<option>Complexo Escolar N. 6012 - Guimbe</option>
<option>Complexo Escolar N. 6018 - Bom Jesus</option>
<option>Complexo Escolar N. 6021 - Ngolome</option>
<option>Complexo Escolar N. 6023 - Sacrifício</option>
<option>Complexo Escolar N. 6025 - Km 36</option>
<option>Complexo Escolar N. 6028 - Cabiri</option>
<option>Complexo Escolar N. 6031 - Foto Sacala</option>
<option>Complexo Escolar N. 6034 - Mabuia</option>
<option>Complexo Escolar N. 6039 - Calomboloca</option>
<option>Complexo Escolar N. 6050 - Maria Teresa</option>
<option>Complexo Escolar N. 6052 - Macesso
<option>Complexo Escolar N. 6055 - Zenza Do Gulungo
<option>Complexo Escolar N. 6058 - Kaquengue</option>
<option>Complexo Escolar N. 6064 - Caxicane</option>
<option>Complexo Escolar N. 6065 - São José</option>
<option>Complexo Escolar N. 6066 - Jambondo</option>
<option>Complexo Escolar N. 6067 - João Paulo Iiº</option>
<option>Complexo Escolar N. 6070 - Metodista</option>
<option>Complexo Escolar N. 6072 - Chevron</option>
<option>Complexo Escolar N. 6073 - Metodista</option>
<option>Complexo Escolar N. 6074 - Aldeia Solar</option>
<option>Complexo Escolar N. 6076 - Centralidade Do Km 44</option>
<option>Direcção Municipal Da Educ.De Icolo E Bengo - Segurança</option>
<option>Direcção Municipal Da Educação Do Icolo E Bengo</option>
<option>Escola Primária N. 6004 - Domingos João</option>
<option>Escola Primária N. 6013 - Kiminha</option>
<option>Escola Primária N. 6024 - Wala</option>
<option>Escola Primária N. 6042 - Kaluco Cazongo</option>
<option>Escola Primária Nº  6016 - Km 38</option>
<option>Escola Primária Nº  6032 - Cassanzo</option>
<option>Escola Primária Nº  6051- Cabala</option>
<option>Escola Primária Nº 6015  - Km 44</option>
<option>Escola Primária Nº 6022 - Cassenda</option>
<option>Escola Primária Nº 6041- Nganga-Nzunze</option>
<option>Escola Primária Nº 6046- Cabembeia</option>
<option>Escola Primária Nº 6060 - Kaculo Kahango</option>
<option>Escola Primária Nº 6062-  Anduri</option>
<option>Escola Primária Nº 6063 - Kala Kala</option>
<option>Escola Primária Nº 6068 - Ilha Negala</option>
<option>Escola Primária Nº 6069 - Km 44 - Estação</option>
<option>Escola Primária Nº 6077 - C .Cadeia</option>
<option>Escola Primárianº 6029 - Banza Quitell</option>
<option>Liceu N. 6026 - Catete Sede</option>
<option>Liceu N. 6075 - Km 44</option>
