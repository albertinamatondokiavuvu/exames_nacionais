<option>Colégio Público 11 De Julho N. 2005 - Belas</option>
<option>Colégio Público Lucrécia Paim N. 2007 - Belas</option>
<option>Colégio Público Polivalente E Profissional N. 2033</option>
<option>Colégio Público Sagrada Esperança N. 2001 - Belas</option>
<option>Colégio Público Zimbo N. 2014 - Belas</option>
<option>Complexo Escolar Bita Canaã N. 2018 - Belas</option>
<option>Complexo Escolar Carlos Kitongo N. 2029 - Belas</option>
<option>Complexo Escolar Cateba N. 2034 - Belas</option>
<option>Complexo Escolar Chacal N. 2037 - Belas</option>
<option>Complexo Escolar José Eduardo Dos Santos N. 2017 - Belas</option>
<option>Complexo Escolar Mártires Do Ugando N. 9010 - Talatona</option>
<option>Complexo Escolar Morro Do Moco N. 2013 - Belas</option>
<option>Complexo Escolar N. 2027 - Belas</option>
<option>Complexo Escolar N. 2028 - Belas</option>
<option>Complexo Escolar N. 2031 - Belas</option>
<option>Complexo Escolar N. 2046 - Belas</option>
<option>Complexo Escolar N. 2054 - Belas</option>
<option>Complexo Escolar U.G.P N. 2038 - Belas</option>
<option>Direcção Da Educação De Belas - Segurança </option>
<option>Direcção Municipal Da Educação De Belas </option>
<option>Dmesamba, Esc.119</option>
<option>Escola Primária 16 De Junho N. 2002 - Belas</option>
<option>Escola Primária Grutas Do Nzenzo N. 2015 - Belas</option>
<option>Escola Primária Lueji Á Nkonde N. 2004 - Belas</option>
<option>Escola Primária Mamá Kudilé N. 2040 - Belas</option>
<option>Escola Primária N. 2023 - Belas</option>
<option>Escola Primária N. 2024 - Belas</option>
<option>Escola Primária N. 2025 - Belas</option>
<option>Escola Primária N. 2026 - Belas</option>
<option>Escola Primária N. 2030 - Belas</option>
<option>Escola Primária N. 2035 - Belas</option>
<option>Escola Primária N. 2043 - Belas</option>
<option>Escola Primária N. 2044 - Belas</option>
<option>Escola Primária N. 2045 - Belas</option>
<option>Escola Primária N. 2047 - Belas</option>
<option>Escola Primária N. 2049 - Belas </option>
<option>Escola Primária N. 2050 - Belas</option>
<option>Escola Primária N. 8058 - Kilamba Kiaxi</option>
<option>Escola Primária Nº 1017-Samba </option>
<option>Escola Primaria Nr. 2053 - Belas</option>
<option>Escola Primária Nzinga Nkuvu N. 2011 - Belas</option>
<option>Escola Primária Welwitschia Mirábilis N. 2008 - Belas</option>
<option>Escola Primaria, I E Ii Ciclo N.º 2050 - Filadelfia</option>
<option>Escolar Primária N. 2019 - Belas</option>
<option>Escolar Primária N. 2020 - Belas</option>
<option>Instituto Administração Gestão N. 2012 - Belas</option>
<option>Instituto Politécnico 30 De Setembro 2039 - Belas</option>
<option>Instituto Técnico De Hotelária E Turismo Terra Do Ngola N. 2009 - Belas</option>
<option>Liceu 14 De Abril N. 2003</option>
<option>Liceu N. 2032 - Belas </option>
<option>Magistério Adpp N. 2042 - Belas</option>
<option>Repartição Da Educação Do Distrito Urbano Da Samba</option>
<option>Repartição Da Educação Do Distrito Urbano Da Samba-Segurança</option>
<option>Escola Primária Quedas de Kalandula Nº 2055</option>
<option>Complexo Escolar Negra Nº 2062</option>
