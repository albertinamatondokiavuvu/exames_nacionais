<option>Colégio Ana Paula N. 8039 - Kilamba Kiaxi</option>
<option>Colégio Angola E Cuba N. 8002 - Kilamba Kiaxi</option>
<option>Colégio N. 8024 - Kilamba Kiaxi</option>
<option>Colégio Nova Vida N. 8057 - Kilamba Kiaxi</option> 
<option>Complexo Escolar Backhita N. 8049 - Kilamba Kiaxi</option>
<option>Complexo Escolar Cutendana João N. 8048 - Kilamba Kiaxi</option>
<option>Complexo Escolar Do Ensino Especial N. 8001 - Kilamba Kiaxi</option>
<option>Complexo Escolar Emaus N. 8034 - Kilamba Kiaxi</option>
<option>Complexo Escolar Esmirna N. 8050 - Kilamba Kiaxi</option>
<option>Complexo Escolar Ieba Golf 2 N. 8016 - Kilamba Kiaxi</option>
<option>Complexo Escolar Irmão Carlos Tesche N. 8010 - Kilamba Kiaxi</option>
<option>Complexo Escolar João Piamarta N. 8015 - Kilamba Kiaxi</option>
<option>Complexo Escolar N. 8023 - Kilamba Kiaxi</option>
<option>Complexo Escolar N. 8046 - Kilamba Kiaxi</option>
<option>Complexo Escolar N. 8051 - Kilamba Kiaxi</option>
<option>Complexo Escolar N. 8052 - Kilamba Kiaxi</option>
<option>Complexo Escolar Paz E Bem N. 8022 - Kilamba Kiaxi</option>
<option>Complexo Escolar Rasta N. 8014 - Kilamba Kiaxi</option>
<option>Complexo Escolar Sagrada Família N. 8017 - Kilamba Kiaxi</option>
<option>Complexo Escolar Santa Teresa N. 8018 - Kilamba Kiaxi</option>
<option>Complexo Escolar São Marcos N. 8032 - Kilamba Kiaxi</option>
<option>Complexo Escolar Sede De Sabedoria N. 8044 - Kilamba Kiaxi</option>
<option>Complexo São João Baptista N. 8053 - Kilamba Kiaxi</option>
<option>Escola Primária Ana Paula N. 8040 - Kilamba Kiaxi</option>
<option>Escola Primária Chitaca N. 8003 - Kilamba Kiaxi</option>
<option>Escola Primária Da Comissão N. 8035 - Kilamba Kiaxi</option>
<option>Escola Primária Ieba I N. 8019 - Kilamba Kiaxi</option>
<option>Escola Primária Ieba Ii N. 8026 - Kilamba Kiaxi</option>
<option>Escola Primária Iera N. 8009 - Kilamba Kiaxi</option>
<option>Escola Primária Loló N. 8013 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8005 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8006 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8008 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8020 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8021 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8043 - Kilamba Kiaxi</option>
<option>Escola Primária N. 8045 - Kilamba Kiaxi</option> 
<option>Escola Primária N. 8059 - Kilamba Kiaxi</option>
<option>Escola Primária Nº 1239 - Humberto Negrini Kilamba Kiaxi</option>
<option>Instituto Poliitécnico De Administração E Gestão Do Nova Vida N. 8055 - Kilamba Kiaxi</option>
<option>Instituto Politécnico Do Nova Vida N. 8056 - Kilamba Kiaxi</option>
<option>Instituto Politécnico Pascoal Luvualu N. 8025 - Kilamba Kiaxi</option>
<option>Liceu Ana Paula N. 8042 - Kilamba Kiaxi</option>
<option>Liceu Divina Providência N. 8038 - Kilamba Kiaxi</option> 
<option>Liceu Kapolo I N. 8027 - Kilamba Kiaxi</option>
<option>Liceu Kapolo Ii N. 8033 - Kilamba Kiaxi</option>
<option>Liceu Nova Vida N. 8054 - Kilamba Kiaxi</option>








