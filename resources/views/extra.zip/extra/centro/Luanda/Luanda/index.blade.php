<option>Centro De Diagnóstico E Orientação Psicopedagógico Nº 1532 - Rangel</option>
<option>Cmplexo Escolar São João Eudes Nr.1410 - Ngola Kiluanje</option>
<option>Colégio 1º De Maio Nº 1140 - Maianga</option></option>
<option>Colégio Catambor Nº 1129 - Maianga</option>
<option>Colégio Juventude Em Luta Nº 1139 - Maianga</option>
<option>Colégio Kassequel Nº 1158 - Maianga</option>
<option>Colégio Luísa Anda Luz Nº 1109 - Maianga</option>
<option>Colégio N. 1004 Camuchiba- Samba</option>
<option>Colégio N. 1008 "Povo Em Luta"- Samba</option>
<option>Colégio N. 1109 - Maianga</option>
<option>Colégio N. 1304 - Sambizanga</option>
<option>Colégio N. 3107 - Maianga</option>
<option>Colégio N. 3113 - Maianga</option>
<option>Colégio N. 4018 - Cacuaco</option>
<option>Colégio N. 5002 - Viana</option>
<option>Colégio Ngola Kanini Nº 1137 - Maianga</option>
<option>Colégio Nº 1600 - Chê Guevara - N. Bendinha</option>
<option>Colégio Nr. 1304 - Sambizanga</option>
<option>Colégio Nr. 1305 - Sambizanga</option>
<option>Colégio Nr.1404 - Margarita - Ngola Kiluanje
<option>Colégio Público Nº 1201 - Ingombota</option></option>
<option>Colégio Público Nº 1203 - Ingombota</option></option>
<option>Colégio Público Nº 1222 Bº Azul - Ingombota</option></option>
<option>Colégio Público Nº 1224 Nzinga Mbande - Ingombota</option></option>
<option>Colégio Público Nº 1226 Ngola Nzinga - Ingombota</option></option>
<option>Colégio Público Nº 1227 - Ingombota</option></option>
<option>Colégio Público Nº 1513 - Escola Grande - Rangel</option>
<option>Colégio Público Nº 1526 - Ngola Mbandi - Rangel</option>
<option>Colégio Público Nº 1528 - Nimi - Ya - Lukeni - Rangel</option>
<option>Colégio Público Nº 1529 - Ekuikui Ii - Rangel</option>
<option>Colégio Público Nº 1530 - Sagrada Esperança - Rangel</option>
<option>Colégio Público Nº 1536 - 147 - Rangel</option>
<option>Colégio Uat Nº 1101 - Maianga</option>
<option>Complexo Escolar Bom Conselho Nº 1216 - Ingombota</option></option>
<option>Complexo Escolar Catintom Nº 1160 - Maianga</option>
<option>Complexo Escolar Monte Sinai Nº 1108 - Maianga</option>
<option>Complexo Escolar N. 1001 - Samba</option>
<option>Complexo Escolar N. 1003 I.E.B.A - Samba</option>
<option>Complexo Escolar N. 1007 "17 De Setembro"- Samba</option>
<option>Complexo Escolar N. 1010 "Mãe De Deus"- Samba</option>
<option>Complexo Escolar N. 1011 " Amós Comenius" Samba</option>
<option>Complexo Escolar N. 1013 Morro Bento-Samba</option>
<option>Complexo Escolar N. 1014 Bereira Samba</option>
<option>Complexo Escolar N. 1601 - Neves Bendinha</option>
<option>Complexo Escolar N. 1609 - Jango Da Inteligência - N Bendinha</option>
<option>Complexo Escolar N. 5130 - Zango 3</option>
<option>Complexo Escolar Nº 1204 - Ingombota</option></option>
<option>Complexo Escolar Nº 1232 S. José Cluny - Ingombota</option>
<option>Complexo Escolar Nº 1506 - São Domingos - Rangel</option>
<option>Complexo Escolar Nº 1509 - Menino Neco - Rangel</option>
<option>Complexo Escolar Nº 1531 - Ensino Especial - Rangel</option>
<option>Complexo Escolar Nº 1601 - N Bendinha</option>
<option>Complexo Escolar Nº 1604 - N Bendinha</option>
<option>Complexo Escolar Nº 1606 - Santa Ana - N Bendinha A)</option>
<option>Complexo Escolar Nº 1608 - Icolo E Bengo - N Bendinha</option>
<option>Complexo Escolar Nr. 1312 - Dom Bosco - Sambizanga</option>
<option>Complexo Escolar Óscar Ribas Nº 1133 - Maianga</option>
<option>Complexo Escolar Padre Pedro Leonardo N. 1149 - Maianga</option>
<option>Complexo Escolar Redentor Nº 1117 - Maianga</option>
<option>Complexo Escolar S. Pedro Nr.1406 - Ngola Kiluanje</option>
<option>Complexo Escolar Simão Toco N. 8036 - Kilamba Kiaxi</option>
<option>Complexo Escolar Songue Dianguxi N. 2036 - Belas</option>
<option>Complexo Escolar Trabalho E Luta N. 1115 - Maianga</option>
<option>Complexo Escolar Venancio De Moura Nr.1408 - Ngola Kiluanje</option>
<option>Complexo Escolar Victoria Do Povo Nº 1146 - Maianga</option>
<option>Deleg. Prov. De Educacao De Luanda</option>
<option>Delegaçao Provincial Luanda -E. Adultos</option>
<option>Direcção Municipal Da Educação Do Kilamba Kiaxi</option>
<option>Direcção Municipal De Educação De Luanda </option>
<option>Escola De Formação De Professores De Educação Física Nº 2006</option>
<option>Escola De Formacao De Tecnicos De Saude De Luanda</option>
<option>Escola Do Ensino Primario N.º 8090 - Cacuaco</option>
<option>Escola Do I Ciclo Do Ens. Sec. Nr 1143-Sambizanga</option>
<option>Escola Do I Ciclo N.º 1143 - Sambizanga</option>
<option>Escola Do I E Ii Do Ens. Sec. N.º1026 - Belas</option>
<option>Es</option>cola Do Ii Ciclo Do Ensino Secundário Nº 5135 - Zango Iv - Viana</option>
<option>Escola Do Ii E Iii N. 17 De Setembro</option>
<option>Escola Do Iii Nivel Do Golf</option>
<option>Escola Do Iiº Ciclo Do Ensino Secundário Nº 4057-101ª Brigada Cacuaco</option>
<option>Escola Do Iiº Ciclo Puniv-Ingombota</option>
<option>Escola Primáriacola Do Ingombota 83 - Nº 1500 - Rangel</option>
<option>Escola Primária - Beiral - Nº 1514 - Rangel</option>
<option>Es</option>cola Primária - Dom Moisés - Nº 1501 - Rangel</option>
<option>Escola Primária - Magistério - Nº 1503 - Rangel</option>
<option>Escola Primária - Nª Senhora Da Luz - Nº 1505 - Rangel</option>
<option>Escola Primária 1º De Agosto N. 1131 - Maianga</option>
<option>Escola Primária António Rocha N. 8011 - Kilamba Kiaxi</option>
<option>Escola Primáriacola Prim</option> Aplicação E Ensaio N. 1135 - Maianga</option>
<option>Escola Primária Augusto Gangula N. 1118 - Maianga</option>
<option>Escola Primária Bethelem Nº 1533 - Rangel</option>
<option>Escola Primária Bom Saber N. 1154 - Maianga</option>
<option>Escola Primária Cdte Imperial Santana Nº 1523 - Rangel</option>
<option>Escola Primaria E I Ciclo N.º 2009 - Bita</option>
<option>Escola Primaria E I Ciclo N.º 2031- Bondo Chapeu</option>
<option>Escola Primária E Iº Ciclo Nº 1004 I.E.B.A-Samba</option>
<option>Escola Primária E Iº Ciclo Nº 2104</option>
<option>Escola Primária Emanuel Nº 1520 - Rangel</option>
<option>Escola Primária I E Ii Ciclo Nº 6021 </option>
<option>Escola Primaria Ieba N.1106 - Maianga</option>
<option>Escola Primária Iera N. 1107 - Maianga</option>
<option>Escola Primária José Marti N. 1136 - Maianga</option>
<option>Escola Primária N. 1000- Samba</option>
<option>Escola Primária N. 1002- Samba</option>
<option>Escola Primaria N. 1005- Samba</option>
<option>Escola Primária N. 1006 Santa Terezinha- Samba</option>
<option>Escola Primária N. 1009 - Samba</option>
<option>Escola Primária N. 1012 "Madre Rita"- Samba</option>
<option>Escola Primária N. 1100 - Maianga</option>
<option>Escola Primária N. 1102 - Maianga</option>
<option>Escola Primária N. 1110 - Maianga</option>
<option>Escola Primária N. 1113 - Maianga</option>
<option>Escola Primária N. 1114 - Maianga</option>
<option>Escola Primária N. 1123 - Maianga</option>
<option>Escola Primária N. 1124 - Maianga</option>
<option>Escola Primaria N. 1126 - Maianga</option>
<option>Escola Primária N. 1128 - Maianga</option>
<option>Escola Primária N. 1130 - Maianga</option>
<option>Escola Primária N. 1132 - Maianga</option>
<option>Escola Primária N. 1134 - Maianga</option>
<option>Escola Primária N. 1138 - Maianga</option>
<option>Escola Primária N. 1150 - Maianga</option>
<option>Escola Primária N. 1151 - Maianga</option>
<option>Escola Primária N. 1152 - Maianga</option>
<option>Escola Primária N. 1153 - Maianga</option>
<option>Escola Primária N. 1156 - Maianga</option>
<option>Escola Primária N. 1159 - Maianga</option>
<option>Escola Primária N. 1161 - Maianga</option>
<option>Escola Primária N. 1200 - Ingombota</option>
<option>Escola Primária N. 1202 - Africa Amiga - Ingombota</option>
<option>Escola Primária N. 1205 - Ingombota</option>
<option>Escola Primária N. 1206 - Ingombota</option>
<option>Escola Primária N. 1207 - Ingombota</option>
<option>Escola Primária N. 1208 - Ingombota</option>
<option>Escola Primária N. 1209 - Ingombota</option>
<option>Escola Primária N. 1211 Liga Africana - Ingombota</option>
<option>Escola Primária N. 1214 - Ingombota</option>
<option>Escola Primária N. 1215 - Ingombota</option>
<option>Escola Primária N. 1218 - Ingombota</option>
<option>Escola Primária N. 1219 - Ingombota</option>
<option>Escola Primária N. 1220 - Ingombota</option>
<option>Escola Primária N. 1221 - Ingombota</option>
<option>Escola Primaria N. 1300 - Sambizanga</option>
<option>Escola Primaria N. 1301 - Sambizanga</option>
<option>Escola Primaria N. 1302 - Sambizanga</option>
<option>Escola Primaria N. 1303 - Sambizanga</option>
<option>Escola Primaria N. 1306 - Sambizanga</option>
<option>Escola Primaria N. 1307 - Sambizanga</option>
<option>Escola Primaria N. 1308 - Sambizanga</option>
<option>Escola Primaria N. 1309 - Sambizanga</option>
<option>Escola Primaria N. 1310 - Sambizanga</option>
<option>Escola Primaria N. 1311 - Sambizanga</option>
<option>Escola Primaria N. 1409 - Ngola Kiluanje</option>
<option>Escola Primária N. 1537 - Rangel</option>
<option>Escola Primaria N. 1602 - N Bendinha</option>
<option>Escola Primaria N. 1603 - N Bendinha</option>
<option>Escola Primaria N. 1607 - N Bendinha</option>
<option>Escola Primaria N.1111 - Maianga</option>
<option>Escola Primaria N.1400 - B.Esperança - Ngola Kiluanje</option>
<option>Escola Primaria N.1401 - Ngola Kiluanje</option>
<option>Escola Primaria N.1402 - Ngola Kiluanje</option>
<option>Escola Primaria N.1403 - Iera - Ngola Kiluanje</option>
<option>Escola Primária Nª Senhora Da Guadalupe Nº 1510 - Rangel</option>
<option>Escola Primária Nº 1040 - Maianga</option>
<option>Escola Primária Nº 1073 - Maianga</option>
<option>Escola Primária Nº 1108-Ingombota</option>
<option>Escola Primaria Nº 1112-Ingombota</option>
<option>Escola Primária Nº 1122-Ingombota</option>
<option>Escola Primária Nº 1511 - Rangel</option>
<option>Escola Primária Nº 1512 - Rangel</option>
<option>Escola Primária Nº 1515 - Rangel</option>
<option>Escola Primária Nº 1516 - Rangel</option>
<option>Escola Primária Nº 1517 - Rangel</option>
<option>Escola Primária Nº 1518 - Rangel - Agrupada Com 398313Rangel</option>
<option>Escola Primária Nº 1521 - Rangel</option>
<option>Escola Primária Nº 1522 - Rangel</option>
<option>Escola Primária Nº 1525 - Rangel</option>
<option>Escola Primaria Nr. 1145  -  Sambizanga</option>
<option>Escola Primária Pica - Pau Nº 1519 - Rangel</option>
<option>Escola Primária Posto Quinze N. 1121 - Maianga</option>
<option>Escola Primária Rainha Ginga N. 1116 - Maianga</option>
<option>Escola Primária Rainha Lueji Nº 1508 - Rangel</option>
<option>Escola Primária São Tiago N. 1120 - Maianga</option>
<option>Escola Primária Soeiro Nº 1524 - Rangel</option><option>Escola Primária Sonangol N. 1157 - Maianga</option>
<option>Escola Primaria Virgem Milagrosa N. 1127 - Maianga</option>
<option>Escola Primária Yasa N. 1112 - Maianga</option>
<option>Escola Primária, Iº E Iiº  Nº 1243 Apocalipse I.E.I.A-Samba</option>
<option>Escola Primário Kapipa N. 1104 - Maianga</option>
<option>Escola Primário N. 1103 - Maianga</option>
<option>Escola Primário Nossa Senhora De Fatima N. 1105 - Maianga</option>
<option>Inst.Med.Polivalente Do Reg.Policia Militar</option>
<option>Inst.Medio Industrial De Luanda-P.Quadro</option>
<option>Instituto Médio De Gestão Do Kicolo Nº 4031 Cacuaco</option>
<option>Instituto Médio Técnico Imel Nº 1142 - Maianga</option></option>
<option>Instituto Normal De Educação Garcia Neto</option>
<option>Instituto Politécnica - Alda Lara Nº 1225</option>
<option>In</option>stituto Politécnico De Adm E Gestão - Eliada N. 5099</option>
<option>Instituto Politécnico De Adm E Gestão N. 5101 - Viana</option>
<option>Instituto Politécnico De Adm E Serviço N. 5144 - Estalagem</option>
<option>Instituto Politecnico Do Ngola Kiluanje N. 1405</option>
<option>Instituto Politécnico Industrial N. 5147 - 17 De Dez - Viana</option>
<option>Instituto Politécnicostituto P</option> Simione Mucune Nº 1119 - Maianga</option>
<option>Instituto Técnico Comercial Nº 1141 - Maianga</option>
<option>Instituto Tecnico De Economia Nº 1605</option>
<option>Liceu 21 De Janeiro Nº 1162 - Maianga</option>
<option>Liceu 22 De Novembro - Ingombota</option> Nº 1230</option>
<option>Liceu N. 3114 - Sambizanga</option>
<option>Liceu N. 5094 - Ciências Prisionais - Viana</option>
<option>Liceu N. 5106 - Neves E Sousa - Viana</option>
<option>Liceu N. 5127 - Domingos Arsenio - Viana</option>
<option>Liceu N. 5128 - Estevao Sandor - Viana</option>
<option>Liceu Ngola Kiluanje Nº 1145 - Maianga</option>
<option>Liceu Nº 1504 - Rei Mandume - Rangel</option><option>Liceu Nº 1507 - Papa João Xxiii - Rangel</option><option>Liceu Papa João Xxiii N. 1507 - Rangel</option><option>Liceu Pir Nº 1147 - Maianga</option>
<option>Magistério - Marista N. 1143 - Maianga</option>
<option>Magistério De Ciências Religiosas 1144</option>
<option>Repartição Da Educação Do Distrito Urbano Da   Ingombota</option>
<option>Repartição Da Educação Do Distrito Urbano Da  Ingombota</option>
<option>Repartição Da Educação Do Distrito Urbano Da Maianga</option>
<option>Repartição Da Educação Do Distrito Urbano Da Maianga Admitidos</option>
<option>Repartição Da Educação Do Distrito Urbano Da Maianga Segurança</option>
<option>Repartição Da Educacao Do Distrito Urbano Do Kilamba Kiaxi-Segurança </option>
<option>Repartição Da Educação Do Distrito Urbano Do Rangel</option>
<option>Repartição Da Educação Do Distrito Urbano Do Rangel Segurança </option>
<option>Repartição Da Educacao Do Kilamba Kiaxi </option>
<option>Repartição De Educação Do Distrito Urbano Do Sambizanga </option>
<option>Repartição De Educação Do Distrito Urbano Do Sambizang - Seguranga </option>
<option>Repartição De Educação Do Distrito Utbano Do Ngola Kiluanje</option>
<option>Repartição De Educacao De K.Kiaxi </option>
<option>Sec.Mun. Do Cacuaco - Admitidos Out. - 05</option>
