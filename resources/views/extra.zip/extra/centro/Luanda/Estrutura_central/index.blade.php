<option>Cuito</option>
<option>Andulo</option>
<option>Nharêa</option>
<option>Cuemba</option>
<option>Cunhinga</option>
<option>Catabola</option>
<option>Camacupa</option>
<option>Chinguar</option>
<option>Chitembo</option>









