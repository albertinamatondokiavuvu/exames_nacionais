<option>Colegio De Otchinjau</option>
<option>Colégio Heróis Da Cahama</option>
<option>Escola Primária Da Uia</option>
<option>Escola Primária De Cahama Velha</option>
<option>Escola Primária De Chilau</option>
<option>Escola Primária De Ediva</option>
<option>Escola Primária De Enkhondo</option>
<option>Escola Primária De Jangada</option>
<option>Escola Primária De Kakuio</option>
<option>Escola Primária De Kaluvango</option>
<option>Escola Primária De Kandeva</option>
<option>Escola Primária De Kanhimei</option>
<option>Escola Primária De Kapale</option>
<option>Escola Primária De Kavalawa </option>
<option>Escola Primária De Kei</option>
<option>Escola Primária De Liambinga</option>
<option>Escola Primária De Luifi</option>
<option>Escola Primária De Lundo</option>
<option>Escola Primária De Mafuefué</option>
<option>Escola Primária De Mauta Malengue</option>
<option>Escola Primária De Mbanho</option>
<option>Escola Primária De Mbome</option>
<option>Escola Primária De Mbúyatchivonga</option>
<option>Escola Primária De Miyumba</option>
<option>Escola Primária De Muana</option>
<option>Escola Primária De Muholo</option>
<option>Escola Primária De Mulolatchipo</option>
<option>Escola Primária De Ndjundo</option>
<option>Escola Primária De Ngandu</option>
<option>Escola Primária De Nongundji</option>
<option>Escola Primária De Ompupa</option>
<option>Escola Primária De Otchinjau Sede</option>
<option>Escola Primária De Quaque</option>
<option>Escola Primária De Tapaila</option>
<option>Escola Primária De Tchalanga</option>
<option>Escola Primária De Tchicusse</option>
<option>Escola Primária De Tchifitu</option>
<option>Escola Primária De Tchikwa</option>
<option>Escola Primária De Tchipelongo</option>
<option>Escola Primária De Tyayombo</option>
<option>Escola Primária De Tyitoto</option>
<option>Escola Primário General Simione Mukume</option>
<option>Escolas Do Ensino Primário Agro - Sol - Cahama</option>
<option>Escolas Do Ensino Primário Eheke - Cahama</option>
<option>Escolas Do Ensino Primário Ekundju - Cahama</option>
<option>Escolas Do Ensino Primário Embumba - Cahama</option>
<option>Escolas Do Ensino Primário Epalanga - Cahama</option>
<option>Escolas Do Ensino Primário Etotó - Mapupu - Cahama</option>
<option>Escolas Do Ensino Primário Eulu - Cahama</option>
<option>Escolas Do Ensino Primário Evole - Cahama</option>
<option>Escolas Do Ensino Primário Hakavamba - Cahama</option>
<option>Escolas Do Ensino Primário Handja - Cahama</option>
<option>Escolas Do Ensino Primário Hapundo - Cahama</option>
<option>Escolas Do Ensino Primário Hatchivandje - Cahama</option>
<option>Escolas Do Ensino Primário Hete - Cahama</option>
<option>Escolas Do Ensino Primário Kalongo - Cahama</option>
<option>Escolas Do Ensino Primário Kambulungo - Cahama</option>
<option>Escolas Do Ensino Primário Kaunambandje - Cahama</option>
<option>Escolas Do Ensino Primário Liomatipa - Cahama</option>
<option>Escolas Do Ensino Primário Luano - Cahama</option>
<option>Escolas Do Ensino Primário Luvotua - Cahama</option>
<option>Escolas Do Ensino Primário Matundu - Cahama</option>
<option>Escolas Do Ensino Primário Mavilahito - Cahama</option>
<option>Escolas Do Ensino Primário Mavovo - Cahama</option>
<option>Escolas Do Ensino Primário Mbalela - Cahama</option>
<option>Escolas Do Ensino Primário Mbulutwe - Cahama</option>
<option>Escolas Do Ensino Primário Mikalati - Cahama</option>
<option>Escolas Do Ensino P<option>[EQT] ESCOLA PRIMÁRIA DE TYITOTO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE LUNDO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TCHALANGA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA CAHAMA-VELHA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE CACUIO - CAHAMA</option>
<option>[EQT] COLÉGIO DE OTCHINJAU - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TCHINDJUMBA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE NGANDU - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE CAVALAWA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA UIA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KAPALE - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TCHIFITU - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TYAYOMBO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TAPAILA - CAHAMA</option>
<option>[EQT] DIRECÇÃO MUNICIPAL DA EDUCAÇÃO DO CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KAMBULUNGO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE CANDEVA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE LIAMBIGA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA MIYUMBA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MAFUEFUÉ - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TCHICUSSE - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MUANA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MBÚ-YA-TCHIVONGA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MBOME - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MAUTA-MALENGA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE TCHIPELONGO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE OMPUPA - CAHAMA</option>
<option>[EQT] INSTITUTO POLITÉCNICO DA CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE ENKHONDO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MBANHO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MUHOLO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MAVOVO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA GENERAL SIMIONE MUKUME - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA TCHICUA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE MULOLA-TCHIPO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA EDIVA - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE CANHIMEI - CAHAMA</option>
<option>[EQT] COLÉGIO HERÓIS DA CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA EULU - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE NONGUNDI - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KEI - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE OTCHINJAU-SEDE - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE QUAQUE - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE CHILAU - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DE KALUVANGO - CAHAMA</option>
<option>[EQT] ESCOLA PRIMÁRIA DA JANGADA - CAHAMA</option>
rimário Mulola - Cahama</option>
<option>Escolas Do Ensino Primário Nandjimba - Cahama</option>
<option>Escolas Do Ensino Primário Nombunda - Cahama</option>
<option>Escolas Do Ensino Primário Ompepo - Kalwa - Cahama</option>
<option>Escolas Do Ensino Primário Onkhana - Cahama</option>
<option>Escolas Do Ensino Primário Tchilenga - Cahama</option>
<option>Escolas Do Ensino Primário Tchimewa - Cahama</option>
<option>Escolas Do Ensino Primário Tchindjumba - Cahama</option>
<option>Escolas Do Ensino Primário Tchinenga - Cahama</option>
<option>Escolas Do Ensino Primário Tchipemba - Cahama</option>
<option>Escolas Do Ensino Primário Tchiundje - Cahama</option>
<option>Escolas Do Ensino Primário Tyihaluveya - Cahama</option>
<option>Liceu Da Cahama</option>
<option>Repartição Municipal Da Educação Da Cahama  - Cahama</option>
